<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated, getCurrentInstance } from "vue";
import getData from '@/services/index.js'
import mapboxgl from "mapbox-gl";
import turf from 'turf'
import MapboxDraw from "@mapbox/mapbox-gl-draw"
import { RulerControl, CompassControl, StylesControl, ZoomControl, InspectControl } from 'mapbox-gl-controls'
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import $ from 'jquery'

const inforStore = useInforStore()

// 地图相关设置
let map
let draw
let selPointList = []

let sel_sets = ref(['train', 'val', 'test'])

let space_infor = ref({})
let time_infor = ref({})
// let feature_infor = ref({})

let sel_start_time = ref("")
let sel_end_time = ref("")


onMounted(() => {
  // draw_th_sketch()
  
})


const onSelSetsChange = () => {
  if (sel_sets.value.includes('train')) { 
    sel_start_time.value = inforStore.cur_data_infor.time.train[0]
  } else if (sel_sets.value.includes('val')) {
    sel_start_time.value = inforStore.cur_data_infor.time.val[0]
  } else {
    sel_start_time.value = inforStore.cur_data_infor.time.test[0]
  }

  if (sel_sets.value.includes('test')) {
    sel_end_time.value = inforStore.cur_data_infor.time.test[1]
  } else if (sel_sets.value.includes('val')) {
    sel_end_time.value = inforStore.cur_data_infor.time.val[1]
  } else {
    sel_end_time.value = inforStore.cur_data_infor.time.train[1]
  }
}

const onStartTimeChange = () => {
  let datatime_start = new Date(sel_start_time.value)
  let train_start = new Date(inforStore.cur_data_infor.time.train[0])
  let val_start = new Date(inforStore.cur_data_infor.time.val[0])
  let test_start = new Date(inforStore.cur_data_infor.time.test[0])

  let datatime_end = new Date(sel_end_time.value)
  let train_end = new Date(inforStore.cur_data_infor.time.train[1])
  let val_end = new Date(inforStore.cur_data_infor.time.val[1])
  let test_end = new Date(inforStore.cur_data_infor.time.test[1])

  let updated_sel_sets = []
  let indeterminate_sets = []

  if (datatime_start.getTime() === train_start.getTime()) {
    if (datatime_end < train_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end.getTime() === train_end.getTime()) {
      updated_sel_sets = ['train']
      indeterminate_sets = []
    } else if (datatime_end > train_end && datatime_end < val_end) {
      updated_sel_sets = ['train']
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['train', 'val']
      indeterminate_sets = []
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['train', 'val']
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['train', 'val', 'test']
      indeterminate_sets = []
    }
  } else if (datatime_start > train_start && datatime_start < val_start) {
    if (datatime_end < train_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end.getTime() === train_end.getTime()) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end > train_end && datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train', 'val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['train']
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['train', 'test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['val', 'test']
      indeterminate_sets = ['train']
    }
  } else if (datatime_start.getTime() === val_start.getTime()) {
    if (datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['val']
      indeterminate_sets = []
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['val', 'test']
      indeterminate_sets = []
    }
  } else if (datatime_start > val_start && datatime_start < test_start) {
    if (datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val', 'test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['test']
      indeterminate_sets = ['val']
    } 
  } else if (datatime_start.getTime() === test_start.getTime()) {
    if (datatime_end < test_end) {
      updated_sel_sets = []
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['test']
      indeterminate_sets = []
    } 
  } else if (datatime_start > test_start) {
    updated_sel_sets = []
    indeterminate_sets = ['test']
  }
  sel_sets.value = updated_sel_sets
  // console.log(updated_sel_sets, indeterminate_sets)
  for (let i = 0; i < indeterminate_sets.length; i++) {
    let id_txt = '#' + indeterminate_sets[i] + '-check'
    // $(id_txt).css('font-size', '20px')
    document.querySelectorAll(id_txt).forEach(checkbox => {
      checkbox.indeterminate = true
    })
  }
  state.cur_sel_time = {
    start: sel_start_time.value,
    end: sel_end_time.value
  }
}

const onEndTimeChange = () => {
  let datatime_start = new Date(sel_start_time.value)
  let train_start = new Date(inforStore.cur_data_infor.time.train[0])
  let val_start = new Date(inforStore.cur_data_infor.time.val[0])
  let test_start = new Date(inforStore.cur_data_infor.time.test[0])

  let datatime_end = new Date(sel_end_time.value)
  let train_end = new Date(inforStore.cur_data_infor.time.train[1])
  let val_end = new Date(inforStore.cur_data_infor.time.val[1])
  let test_end = new Date(inforStore.cur_data_infor.time.test[1])

  let updated_sel_sets = []
  let indeterminate_sets = []

  if (datatime_start.getTime() === train_start.getTime()) {
    if (datatime_end < train_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end.getTime() === train_end.getTime()) {
      updated_sel_sets = ['train']
      indeterminate_sets = []
    } else if (datatime_end > train_end && datatime_end < val_end) {
      updated_sel_sets = ['train']
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['train', 'val']
      indeterminate_sets = []
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['train', 'val']
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['train', 'val', 'test']
      indeterminate_sets = []
    }
  } else if (datatime_start > train_start && datatime_start < val_start) {
    if (datatime_end < train_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end.getTime() === train_end.getTime()) {
      updated_sel_sets = []
      indeterminate_sets = ['train']
    } else if (datatime_end > train_end && datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['train', 'val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['train']
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['train', 'test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['val', 'test']
      indeterminate_sets = ['train']
    }
  } else if (datatime_start.getTime() === val_start.getTime()) {
    if (datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = ['val']
      indeterminate_sets = []
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = ['val']
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['val', 'test']
      indeterminate_sets = []
    }
  } else if (datatime_start > val_start && datatime_start < test_start) {
    if (datatime_end < val_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end.getTime() === val_end.getTime()) {
      updated_sel_sets = []
      indeterminate_sets = ['val']
    } else if (datatime_end > val_end && datatime_end < test_end) {
      updated_sel_sets = []
      indeterminate_sets = ['val', 'test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['test']
      indeterminate_sets = ['val']
    } 
  } else if (datatime_start.getTime() === test_start.getTime()) {
    if (datatime_end < test_end) {
      updated_sel_sets = []
      indeterminate_sets = ['test']
    } else if (datatime_end.getTime() === test_end.getTime()) {
      updated_sel_sets = ['test']
      indeterminate_sets = []
    } 
  } else if (datatime_start > test_start) {
    updated_sel_sets = []
    indeterminate_sets = ['test']
  }
  sel_sets.value = updated_sel_sets
  // console.log(updated_sel_sets, indeterminate_sets)
  for (let i = 0; i < indeterminate_sets.length; i++) {
    let id_txt = '#' + indeterminate_sets[i] + '-check'
    // $(id_txt).css('font-size', '20px')
    document.querySelectorAll(id_txt).forEach(checkbox => {
      checkbox.indeterminate = true
    })
  }
  state.cur_sel_time = {
    start: sel_start_time.value,
    end: sel_end_time.value
  }
}

mapboxgl.accessToken = 'pk.eyJ1IjoiZGV6aGFudmlzIiwiYSI6ImNraThnYWoxcDA1aXkycnMzMGxhcDcxeGgifQ.pbnOr8oKR894OJ3seHIayg'

const initDraw = () => {
    draw = new MapboxDraw()
    // let navigation = new mapboxgl.NavigationControl()
    // let scale_ctl =  new mapboxgl.ScaleControl({
    //     maxWidth: 80,
    //     unit: 'imperial'
    // })
    let full_screen_ctl = new mapboxgl.FullscreenControl()
    // map.addControl(navigation, 'bottom-right')
    map.addControl(full_screen_ctl, 'bottom-left')
    // map.addControl(scale_ctl, 'bottom-right')

    map.addControl(draw, 'bottom-left')

    map.on('draw.create', updateArea)
    map.on('draw.update', updateArea)
    map.on('draw.delete', updateArea)
}

watch (() => inforStore.cur_sel_task, (oldVlaue, newValue) => {
  cur_error_configs.value = inforStore.error_configs[inforStore.cur_sel_task]
})

watch (() => inforStore.cur_data_infor, (oldVlaue, newValue) => {
  inforStore.attrs_bins[inforStore.cur_data_infor.features.output[0]] = [0, 35, 75, 115, 150, 250, 350, 500, 2000]
  getData(inforStore, 'attr_distributions', inforStore.cur_sel_data, JSON.stringify(inforStore.attrs_bins))
  space_infor.value.loc_num = inforStore.cur_data_infor.space.loc_list.length
  space_infor.value.type = inforStore.cur_data_infor.space.loc_list[0].properties.type + 's'
  time_infor.value.time_num = inforStore.cur_data_infor.time.time_num
  time_infor.value.train = inforStore.cur_data_infor.time.train[0] + ' ~ ' + inforStore.cur_data_infor.time.train[1]
  time_infor.value.val = inforStore.cur_data_infor.time.val[0] + ' ~ ' + inforStore.cur_data_infor.time.val[1]
  time_infor.value.test = inforStore.cur_data_infor.time.test[0] + ' ~ ' + inforStore.cur_data_infor.time.test[1]
  time_infor.value.input_window = inforStore.cur_data_infor.time.input_window
  time_infor.value.output_window = inforStore.cur_data_infor.time.output_window
  time_infor.value.start_time = inforStore.dataset_infor[inforStore.cur_sel_data].Duration.start
  time_infor.value.end_time = inforStore.dataset_infor[inforStore.cur_sel_data].Duration.end
  let range_num = inforStore.dataset_infor[inforStore.cur_sel_data].Duration.length
  time_infor.value.time_range = inforStore.dataset_infor[inforStore.cur_sel_data].Duration.join(', ')
  time_infor.value.train_range = inforStore.dataset_infor[inforStore.cur_sel_data].Duration.slice(0, range_num-2).join(', ')
  time_infor.value.valid_range = inforStore.dataset_infor[inforStore.cur_sel_data].Duration[range_num-2]
  time_infor.value.test_range = inforStore.dataset_infor[inforStore.cur_sel_data].Duration[range_num-1]
  inforStore.cur_sel_time = {
    start: time_infor.value.start_time,
    end: time_infor.value.end_time
  }
  sel_start_time.value = time_infor.value.start_time
  sel_end_time.value = time_infor.value.end_time
  // console.log(inforStore.dataset_infor[inforStore.cur_sel_data].Duration.start);
  // console.log(inforStore.dataset_infor[inforStore.cur_sel_data].Duration.end);
  // console.log(time_infor.value)
  inforStore.feature_infor.num = inforStore.cur_data_infor.features.num
  inforStore.feature_infor.input = inforStore.cur_data_infor.features.input.join(', ')
  inforStore.feature_infor.output = inforStore.cur_data_infor.features.output.join(', ')

  map = new mapboxgl.Map({
      container: 'map-container',
      // style: 'mapbox://styles/dezhanvis/ckmcv57z60gjd17rq1jvowlcr',
      center: inforStore.cur_data_infor.space.loc_center,
      // pitch: 80,
      // bearing: 41,
      'zoom': 6,
      style: 'mapbox://styles/mapbox/satellite-streets-v10',
      zoomControl: true
    })
  map._logoControl && map.removeControl(map._logoControl);  // 去除mapbox标志
  map.on('style.load', () => {
    map.addSource('mapbox-dem', {
      'type': 'raster-dem',
      'url': 'mapbox://mapbox.mapbox-terrain-dem-v1',
      'tileSize': 256,
      'maxzoom': 14
      });
    map.setTerrain({ 'source': 'mapbox-dem', 'exaggeration': 4 });

    map.addSource("points", {
      "type": "geojson",
      "data": {
        "type": "FeatureCollection",
        "features": inforStore.cur_data_infor.space.loc_list
      }
    })

    map.addSource("grid_borders", {
      "type": "geojson",
      "data": {
        "type": "FeatureCollection",
        "features": inforStore.cur_data_infor.space.grid_border_geojson
      }
    })

    map.addLayer({
      "id": "points",
      "type": "circle",
      "source": "points",
      "paint": {
        'circle-radius': 4.5,
        'circle-color': '#ffc107'
      }
    });

    map.addLayer({
      "id": "points-selected",
      "type": "circle",
      "source": "points",
      "paint": {
        'circle-radius': 4.5,
        'circle-color': '#eb6877'
      },
      "filter": ["in", "loc_id", '']  /* 过滤器，名字为空的数据才显示，也就是默认不使用该layer  */
    });

    map.addLayer({
      "id": "grids",
      "type": "line",   /* symbol类型layer，一般用来绘制点*/
      "source": "grid_borders",
      paint: {
        'line-color': "#ffffff",
        "line-width": 1.5
      }
    })
  });

  initDraw()

  map.on('click', 'points', function(e) {
    let coordinates = e.features[0].geometry.coordinates.slice();
    
    // 在这里你可以使用 coordinates 进行你的操作，比如显示在页面上
    console.log('Hovered Coordinates:', coordinates);
});

  getData(inforStore, 'st_phase_events', inforStore.cur_sel_data, inforStore.phase_params.focus_th, inforStore.phase_params.min_length, JSON.stringify(inforStore.cur_val_bins), JSON.stringify(inforStore.event_params))
  // $('.attr-value').css('font-weight', 700)
  // console.log(inforStore.cur_data_infor);
})

const updateArea = (e) => {
    //   map.setFilter("points-selected", ["==", "group", ""]);
  if (e.type === 'draw.delete') {
    map.setFilter("points-selected", ["in", "loc_id", ""]);
    // map.setFilter("points-selected", ["==", "group", ""]);
    selPointList = []
    // store.commit('setData', {
    //   field: 'select_point',
    //   data: pointList
    // })
    return
  }

  let data = draw.getAll()
  if (data.features.length > 0) {
    let userPolygon = e.features[0];
    let polygonBoundingBox = turf.bbox(userPolygon);
    let southWest = [polygonBoundingBox[0], polygonBoundingBox[1]];
    let northEast = [polygonBoundingBox[2], polygonBoundingBox[3]];
    let northEastPointPixel = map.project(northEast);
    let southWestPointPixel = map.project(southWest);
    let features = map.queryRenderedFeatures([southWestPointPixel, northEastPointPixel], { layers: ['points'] });
    let filter = features.reduce(function(memo, feature) {
      if (! (undefined === turf.intersect(feature, userPolygon))) {
        // only add the property, if the feature intersects with the polygon drawn by the user
        // memo.push(feature.properties.title);
        memo.push(feature.properties.loc_id);
      }
      return memo;
    }, []);
    // sel_filter = ["in", "loc_id", ...filter]
    selPointList = filter
    // store.commit('setData', {
    //   field: 'select_point',
    //   data: pointList
    // })
    map.setFilter("points-selected", ["in", "loc_id", ...filter]);
  } else {
    // answer.innerHTML = '';
  }
}
</script>

<template>
  <div class="data_infor_title">
    <div><span class="attr-title">Space</span>: {{ space_infor.loc_num }} {{ space_infor.type }}</div>
  </div>
  <div class="map-container" id="map-container"></div>
  <div class="data_infor_title">
    <div><span class="attr-title">Time</span>: {{ time_infor.time_num }} timestamps</div>  
    
  </div>

  <div class="data_infor_block">
    <div class="data-infor-row">
      <!-- <div class="form-check">
        <input class="form-check-input" id="train-check" type="checkbox" value="train" v-model="sel_sets" @change="onSelSetsChange">
        <label class="form-check-label" for="train-check">
          Train
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" id="val-check" type="checkbox" value="val" v-model="sel_sets" @change="onSelSetsChange">
        <label class="form-check-label" for="val-check">
          Validation
        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" id="test-check" type="checkbox" value="test" v-model="sel_sets" @change="onSelSetsChange">
        <label class="form-check-label" for="test-check">
          Test
        </label>
      </div> -->
    </div>
    <!-- <div class="form-row">
      <span class="time-pre-text">Start:</span>
      <input type="date" name="startTime" id="startTime" class="form-control time-select" :max="time_infor.end_time" :min="time_infor.start_time" v-model="sel_start_time" @change="onStartTimeChange()">
    </div>
    <div class="form-row">
      <span class="time-pre-text">End:</span>
      <input type="date" name="endTime" id="endTime" class="form-control time-select" :max="time_infor.end_time" :min="time_infor.start_time" v-model="sel_end_time" @change="onEndTimeChange()">
    </div> -->

    <div class="data-infor-row">
      <!-- <div>Input window: <span class="attr-value">{{ time_infor.input_window }}</span></div>
      <div>Output window: <span class="attr-value">{{ time_infor.output_window }}</span></div> -->
      <!-- 这里放时间范围更合理些 -->
      <div>Train: <span class="attr-value">{{ time_infor.train_range }}</span></div>
      <div style="display: flex;">
        <div style="margin-right: 16px;">Valid: <span class="attr-value">{{ time_infor.valid_range }}</span></div>
        <div>Test: <span class="attr-value">{{ time_infor.test_range }}</span></div>
      </div>
    </div>
  </div>
  <div class="data_infor_title">
    <div><span class="attr-title">Feature</span>: {{ inforStore.feature_infor.num }} features</div>
  </div>
  <div class="data_infor_block">
    <div>Input: <span class="attr-value">{{ inforStore.feature_infor.input }}</span></div>
    <div>Output: <span class="attr-value">{{ inforStore.feature_infor.output }}</span></div>
  </div>
  <div class="config-seg-line"></div>
</template>

<style scoped>
@import url("https://api.tiles.mapbox.com/mapbox-gl-js/v2.14.1/mapbox-gl.css");
@import url("https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.3.0/mapbox-gl-draw.css");

.mapboxgl-ctrl-fullscreen {
    /* background-color: #000 !important; */
    background-image: url("/src/assets/MapIcons/mapboxgl-ctrl-fullscreen.svg") !important;
}
.map-container {
  /* margin: 0 auto; */
  /* left: 300; */
  /* display: flex; */
  width: 274px;
  height: 236px;
  margin-left: 10px;
  margin-top: 3px;
  border: solid 1px #cecece;
}

.data_infor_title {
  margin-top: 3px;
  margin-left: 10px;
  font-size: 14px;
  width: 272px;
  display: flex;
  justify-content: space-between;
}

.data_infor_block {
  /* display: flex; */
  /* justify-content: space-between; */
  margin-left: 10px;
  font-size: 14px;
  font-weight: 400;
  margin-top: 1px;
}

.data-infor-row {
  width: 276px;
  /* display: flex; */
  /* justify-content: space-between; */
  padding-right: 12px;
}

.attr-value {
  color: #1a73e8;
}
.attr-title {
  font-weight: 700;
}

.form-row {
  display: flex;
  /* margin-left: 10px; */
  align-items: center;
  margin-bottom: 6px;
  /* width: 280px; */
  /* justify-content: space-between; */
}

.time-pre-text {
  width: 46px;
  text-align: left;
}

#startTime,
#endTime {
  width: 220px;
  height: 24px;
  padding: 0px 2px 0 4px !important;
  border-width: 0;
  border-bottom: solid 1px #9c9c9c !important;
  border-radius: 0;
  font-size: 14px;
  margin-top: 0;
  /* margin-bottom: 2px; */
}

.th-form-row,
.config-load-row {
  width: 276px;
  height: 26px;
  margin-left: 10px;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  font-size: 14px;
  justify-content: space-between;
  align-items: center;
}

.time-scope-control {
  width: 180px;
  height: 24px;
  display: flex;
  align-items: center;
}
.config-load-row .form-control {
  width: 168px;
  height: 22px !important;
  /* width: 120px; */
  padding: 2px 4px !important;
  margin-left: 4px;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
  color:#1a73e8;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.time-scope-control .form-control {
  width: 32px;
  height: 20px !important;
  /* width: 120px; */
  padding: 0px 0px !important;
  margin-left: 4px;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
  color:#1a73e8;
  /* text-align: left; */
  /* overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis; */
}

.failure_rule {
  width: 276px;
  font-size: 14px;
  text-align: center;
  padding: 4px !important;
  margin: 0 auto;
}

.failure_rule tr {
  display: flex !important;
  justify-content: space-between;
}

.failure_rule th, 
.failure_rule td {
  /* display: inline-block; */
  padding: 3px !important;
}

.failure_rule td {
  border-bottom-width: 0;
  height: 34px;
}

.failure_rule th:first-child,
.failure_rule td:first-child {
  width: 130px;
}
.failure_rule th:nth-child(2),
.failure_rule td:nth-child(2) {
  width: 84px;
}

.failure_rule th:nth-child(3),
.failure_rule td:nth-child(3) {
  width: 62px;
}

.rule-range {
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.err_th {
  display: flex;
  justify-content: center;
  align-items: center;
  /* margin: 0 auto; */
}

.rule-range .form-control,
.err_th .form-control {
  width: 48px;
  /* height: 18px; */
  font-size: 14px;
  padding: 2px 6px;
  text-align: center;
}

.add_rule {
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.add_rule .add_button,
.add_rule .sub_button {
  font-size: 20px;
  cursor: pointer;
}

.add_rule .add_button:hover,
.add_rule .sub_button:hover {
  color: #1a73e8;
}

/* .add_rule .sub_button:first-of-type:hover {
  color: #212529;
  cursor: auto;
} */

.th-form-row label {
  margin-top: 8px;
  display: block;
}

.focus-type-dropdown .dropdown-toggle {
  width: 130px !important;
  height: 30px;
  /* width: 120px; */
  margin-top: -6px;
  padding: 6px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* .dropdown-menu,
.dropdown-item {
  font-size: 14px;
  width: 130px !important;
  cursor: pointer;
  white-space: normal;
} */


.config-seg-line {
  height: 1px;
  width: 274px;
  background-color: #bcbcbc;
  margin: 0 auto;
  margin-top: 8px;
  margin-bottom: 8px;
}

#save-cur-config {
  
  font-size: 14px;
  font-weight: 700;
  color: #777;
  text-decoration: underline;
}
#save-cur-config:hover {
  color: #1a73e8;
  cursor: pointer;
}

#get-model-button {
  margin: 0 auto;
  margin-top: 1px;
  width: 220px;
  height: 32px;
  padding: 2px 0px;
  font-size: 14px;
  font-weight: 700;
  border: solid 1px #9a9a9a;
  border-radius: 16px;
  color: #333;
  background-color: #fff;
}

#get-model-button:hover {
  border-color: #1a73e8;
  color: #1a73e8;
}

.config-dropdown {
  /* margin-right: 20px !important; */
}

.config-dropdown .dropdown-toggle {
  width: 220px !important;
  height: 28px;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.config-dropdown .dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.config-dropdown .dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  width: 268px;
  cursor: pointer;
  white-space: normal;
}

.config-dropdown .dropdown-item:hover {
  background-color: #cecece;
}

.error-config-title {
  display: flex;
  /* justify-content: space-between; */
  align-items: center;
}

.error-config-title span:first-child {
  margin-right: 6px;
}

.save-config-description {
  font-size: 14px;
}

.li-config-description {
  font-size: 12px;
  color: #777;
}
.save-config-name {
  font-size: 14px;
  display: flex;
  align-items: center;
  margin-bottom: 6px;
}

.save-config-name .form-control {
  width: 190px !important;
  height: 22px;
  /* width: 120px; */
  margin-left: 4px;
  padding: 0px 2px 0 4px !important;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
}

.save-config-row {
  margin-top: 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.save-config-state {  
  font-size: 14px;
  /* font-weight: 700; */
  color: #157347;
}

#save-config-btn {
  font-size: 14px;
  padding: 3px 6px !important;
}
</style>