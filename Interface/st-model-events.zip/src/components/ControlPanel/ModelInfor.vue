<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'
import getData from '@/services/index.js'
import $ from 'jquery'
import "ion-rangeslider/css/ion.rangeSlider.min.css"; // 引入样式
import "ion-rangeslider/js/ion.rangeSlider.min.js"; // 引入脚本
import { distance } from "turf"
import ModelCard from './ModelCard.vue'

const inforStore = useInforStore()

const tmp_focused_scope = ref('')
watch (() => inforStore.cur_sel_window_size, (oldVlaue, newValue) => {
  tmp_focused_scope.value = `1-${inforStore.cur_sel_window_size['Forecast Steps']}`
})


watch (() => inforStore.model_parameters, (oldVlaue, newValue) => {
  getData(inforStore, 'phases_indicators',  inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), JSON.stringify(inforStore.cur_val_bins), JSON.stringify(inforStore.event_params), JSON.stringify(inforStore.cur_focused_scope))
  getData(inforStore, 'multi_step_err_infor',  inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), inforStore.range_params.step_len)
})

watch (() => inforStore.cur_focused_scope, (oldVlaue, newValue) => {
  // 改变关注scope后，需要重新计算phases_indicators
  getData(inforStore, 'phases_indicators',  inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), JSON.stringify(inforStore.cur_val_bins), JSON.stringify(inforStore.event_params), JSON.stringify(inforStore.cur_focused_scope))
  getData(inforStore, 'phase_ins_subsets', inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), inforStore.cur_sel_model, inforStore.cur_phase_sorted_id, JSON.stringify(inforStore.cur_st_attrs), inforStore.cur_sel_fore_step, inforStore.cur_range_mode, JSON.stringify(inforStore.range_params), JSON.stringify(inforStore.subset_params), JSON.stringify(inforStore.organize_params), JSON.stringify(inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins), JSON.stringify(inforStore.cur_focused_scope))
  // 需要重新计算phase_details
  getData(inforStore, 'phase_details', inforStore.cur_sel_model, inforStore.cur_phase_sorted_id, JSON.stringify(inforStore.cur_val_bins), inforStore.phase_params.focus_th, JSON.stringify(inforStore.cur_focused_scope))
})

watch (() => inforStore.multi_step_err_infor, (oldVlaue, newValue) => {
  // console.log(inforStore.multi_step_err_infor);
})

onMounted(() => {
  
})

const onForeStepSel = (index) => {
  inforStore.cur_sel_window_size = inforStore.cur_window_sizes[index]
  let cur_key = Object.keys(inforStore.existed_task_data_model[inforStore.cur_sel_task][inforStore.cur_sel_data].forecast_steps)[index]
  inforStore.cur_model_names = inforStore.existed_task_data_model[inforStore.cur_sel_task][inforStore.cur_sel_data].forecast_steps[cur_key]

  // console.log(inforStore.cur_model_names);
  getData(inforStore, 'input_output_data', inforStore.cur_sel_data, inforStore.cur_sel_window_size['Input Steps'], inforStore.cur_sel_window_size['Forecast Steps'])
  getData(inforStore, 'model_parameters', inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), inforStore.phase_params.focus_th, JSON.stringify(inforStore.cur_val_bins))
}

const parseForecastSteps = (window_obj) => {
  if (window_obj == 'Choose Forecast Steps') return window_obj
  else return `Input: ${window_obj['Input Steps']};  Forecast: ${window_obj['Forecast Steps']}`
}

const getModelType = model_name => model_name.split('-')[0]
const onModelCardClick = model_name => {
  if (inforStore.cur_sel_model != model_name) {
    // 清楚旧选中框
    $('.model-card-block').removeClass('model-selected')
    // 添加新选中框
    $(`#model-card_${model_name}`).addClass('model-selected')
    inforStore.cur_sel_model = model_name
    inforStore.cur_phase_indicators = inforStore.phases_indicators[model_name]
  }
  
  // inforStore.phases_indicators = inforStore.error_indicators.phases_indicators[inforStore.cur_sel_model]
  // getData(inforStore, 'event_subsets', JSON.stringify(inforStore.cur_model_names), inforStore.cur_sel_model, inforStore.cur_sel_fore_step, inforStore.cur_range_mode, JSON.stringify(inforStore.range_params)) 
}

const onFocusedScopeChange = () => {
  let scope_start = parseInt(tmp_focused_scope.value.split('-')[0])
  let scope_end = parseInt(tmp_focused_scope.value.split('-')[1])
  inforStore.cur_focused_scope = [scope_start, scope_end]
}
</script>

<template>
  <div class="select-block">
    <span class="iconfont model-icon select-icon">&#xe6b5;</span>
    <div class="data-dropdown">
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ parseForecastSteps(inforStore.cur_sel_window_size) }}</button>
      <ul class="dropdown-menu">
        <li v-for="(item, index) in inforStore.cur_window_sizes" :value="item" @click="onForeStepSel(index)" class='dropdown-item' :key="index">
          <div class="li-data-name"><span>Input Steps: {{item['Input Steps']}}</span>; <span>Forecast Steps: {{item['Forecast Steps']}}</span></div>
        </li>
      </ul>
    </div>
  </div>
  <div class="params-control">
    <label class="form-label"><span class="attr-title">Focus_Target_TH: </span></label>
    <input class="form-control" id="form-target-th" type="text" v-model="inforStore.phase_params.focus_th">
  </div>
  <div class="params-control">
    <label class="form-label"><span class="attr-title">Multi_Levels: </span></label>
    <input class="form-control" id="form-multi-level" type="text" v-model="inforStore.cur_val_bins">
  </div>
  <div class="params-control">
    <label class="form-label"><span class="attr-title">Focused_Scope: </span></label>
    <input class="form-control" id="form-focused-scope" type="text" v-model="tmp_focused_scope" @change="onFocusedScopeChange()">
  </div>
  <!-- <div class="err-plot-title">
    <span>Focused Scope</span>
  </div> -->
  <!-- <div @click="onModelCardClick('compare')">Compare Models</div> -->
  <div v-if=" Object.keys(inforStore.phases_indicators).length > 0">
    <ModelCard v-for="(value, key, index) in inforStore.multi_step_err_infor" :key="index" :model_name="key" :model_type="getModelType(key)" :step_error="value" :model_parameters="inforStore.model_parameters[key]" @click="onModelCardClick(key)" />
  </div>
</template>

<style scoped>
.select-block {
  display: flex;
  margin-left: 10px;
}

.model-icon {
  font-size: 26px;
  margin-right: 6px;
}

.select-icon {
  display: flex;
  width: 24px;
  justify-content: center;
}

.params-control {
  display: flex;
  margin-left: 10px;
  margin-bottom: 8px;
}

.params-control .form-control {
  width: 120px;
  height: 20px !important;
  /* width: 120px; */
  padding: 0px 0px !important;
  margin-left: 8px;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
  color:#1a73e8;
  /* text-align: left; */
  /* overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis; */
}

.form-label {
  margin-bottom: 0;
  font-weight: 700;
}

#form-multi-level {
  width: 182px;
}
#form-target-th {
  width: 80px;
}
#form-focused-scope {
  width: 80px;
}

.data-dropdown .dropdown-toggle {
  width: 240px !important;
  height: 30px;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

.li-data-name {
    font-size: 14px;
}

.li-data-description {
    font-size: 12px;
    color: #777;
}

#err-dis {
  display: block;
  margin-left: 10px;
}

.err-plot-title {
  margin-left: 10px;
  margin-right: 10px;
  font-weight: 700;
  display: flex;
  justify-content: space-between;
}

.focus-span {
  color: #1a73e8;
  font-weight: 400;
}

.axis text {
  transform: rotate(-45deg);
  /* text-anchor: end; */
}
</style>