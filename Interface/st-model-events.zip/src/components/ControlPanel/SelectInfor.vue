<script setup>
import { ref, onMounted, watch } from "vue"
import getData from '@/services/index.js'
import { useInforStore } from '@/stores/infor.js'
import DataInfor from './DataInfor.vue'
import ModelInfor from './ModelInfor.vue'
// import SubsetConfig from "./SubsetConfig.vue";

const inforStore = useInforStore()
getData(inforStore, 'existed_task_data_model')

// inforStore.$subscribe((mutation, state) => {
//   console.log(mutation);
//   console.log(state.existed_task_data_model);
// })

let sel_task_name = ref('air_quality_pred')
let sel_task_id = ref(-1)

let sel_data_name = ref('Choose Data')
let cur_data_names = ref([])
let sel_data_id = ref(-1)

onMounted(() => {
  
})

const onTaskCardClick = card_index => {
  if (card_index == -1) {
    sel_task_id.value = -1
    sel_task_name.value = "Choose Task"
    cur_data_names.value = []
    inforStore.cur_sel_task = ""
  }
  else {
    if (sel_task_id.value != -1) {
      sel_data_id.value = -1
      sel_data_name = ref('Choose Data')
      sel_model_id.value = -1
      sel_model_names = ref('Choose Models')
    }
    sel_task_id.value = card_index
    sel_task_name.value = Object.keys(inforStore.existed_task_data_model)[card_index]
    inforStore.cur_sel_task = sel_task_name.value
    cur_data_names.value = Object.keys(inforStore.existed_task_data_model[sel_task_name.value])
  }
}

const onDataCardClick = card_index => {
  if (card_index == -1) {
    sel_data_id.value = -1
    sel_data_name.value = "Choose Data"
    // inforStore.cur_model_names = []
    inforStore.cur_window_sizes = []
    inforStore.cur_sel_model = 'Choose Model'
    inforStore.cur_sel_data = ""
  }
  else {
    sel_data_id.value = card_index
    sel_data_name.value = cur_data_names.value[card_index]
    // inforStore.cur_model_names = inforStore.existed_task_data_model[sel_task_name.value][sel_data_name.value].models
    let window_strs = Object.keys(inforStore.existed_task_data_model[sel_task_name.value][sel_data_name.value].forecast_steps)
    let window_objs = []
    for (let i = 0; i < window_strs.length; ++i) {
      let split_windows = window_strs[i].split('-')
      let window_obj = {"Input Steps": split_windows[0], "Forecast Steps": split_windows[1]}
      window_objs.push(window_obj)
    }
    inforStore.cur_window_sizes = window_objs
    inforStore.cur_sel_data = sel_data_name.value

    getData(inforStore, 'cur_data_infor', sel_task_name.value, sel_data_name.value)
  }
}

watch (() => inforStore.existed_task_data_model, (oldVlaue, newValue) => {
  cur_data_names.value = Object.keys(inforStore.existed_task_data_model[sel_task_name.value])
})

// watch (() => inforStore.cur_model_parameters, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_model_parameters);
// })



// watch (() => inforStore.cur_sel_time, (oldVlaue, newValue) => {
//   getData(inforStore, 'cur_model_infor', sel_task_name.value, sel_data_name.value, JSON.stringify(inforStore.cur_sel_time), JSON.stringify(cur_model_names.value), inforStore.cur_sel_err_th)
// })

// watch (() => inforStore.cur_sel_err_th, (oldVlaue, newValue) => {
//   getData(inforStore, 'cur_model_infor', sel_task_name.value, sel_data_name.value, JSON.stringify(inforStore.cur_sel_time), JSON.stringify(cur_model_names.value), inforStore.cur_sel_err_th)
// })



// watch (() => cur_model_names.value, (oldVlaue, newValue) => {
//   getData(inforStore, 'cur_model_infor', sel_task_name.value, sel_data_name.value, JSON.stringify(inforStore.cur_sel_time), JSON.stringify(cur_model_names.value))
// })

</script>

<template>
  <div class='outer-container'>
    <div class="title-layer">Control Panel</div>
    <!-- <div class="select-block">
      <span class="iconfont task-icon select-icon">&#xe63f;</span>
      <div class="task-dropdown">
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ sel_task_name }}</button>
        <ul class="dropdown-menu" id="dropdown-choose-task">
          <li v-for="(key, index) in Object.keys(inforStore.existed_task_data_model)" :value="key" @click="onTaskCardClick(index)" class='dropdown-item'>
            <div class="li-task-name">{{ key }}</div>
          </li>
        </ul>
      </div>
    </div> -->
    
    <div class="select-block">
      <span class="iconfont data-icon select-icon">&#xe603;</span>
      <div class="data-dropdown">
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ sel_data_name }}</button>
        <ul class="dropdown-menu" id="dropdown-choose-task">
          <li v-for="(item, index) in cur_data_names" :value="item" @click="onDataCardClick(index)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }} - {{ inforStore.dataset_infor[item].Data_type }}</div>
            <div class="li-data-description">{{ inforStore.dataset_infor[item].Description }}</div>
          </li>
        </ul>
      </div>
    </div>

    <div class="data-infor">
      <DataInfor />
    </div>

    <ModelInfor />

    <!-- <ErrorConfig /> -->
    <!-- <SubsetConfig /> -->
    
  </div>
</template>

<style scoped>
.outer-container {
  width: 300px;
  height: 1072px;
  /* height: 1372px; */
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 2px;
  overflow-y: auto;
}

.select-block {
  display: flex;
  margin-left: 10px;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 188px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 9px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
}

.task-dropdown,
.data-dropdown {
  /* margin-right: 20px !important; */
}

.data-dropdown .dropdown-toggle,
.task-dropdown .dropdown-toggle {
  width: 240px !important;
  max-width: 240px;
  height: 30px;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

.select-icon {
  display: flex;
  width: 24px;
  justify-content: center;
}

.sub-title {
  display: flex;
  /* font-size: 14px; */
  align-items: center;
}


.task-icon {
  margin-top: 0;
  margin-right: 6px;
  font-size: 24px;
  font-weight: 500;
}
.data-icon {
  margin-top: 4px;
  margin-right: 6px;
  font-size: 20px;
  font-weight: 600;
}

.model-icon {
  font-size: 26px;
  margin-right: 6px;
}

.li-model-name,
.li-data-name {
    font-size: 14px;
}

.li-model-description,
.li-data-description {
    font-size: 12px;
    color: #777;
}

.data-infor {
  margin: 0 auto;
}

.model-infor {
  margin-left: 10px;
}

.model_infor_title {
  width: 276px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* padding-right: 12px; */
}

</style>