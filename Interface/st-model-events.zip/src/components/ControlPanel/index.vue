<script setup>
import SelectInfor from './SelectInfor.vue'

</script>

<template>
  <SelectInfor />
  
</template>

<style scoped>

</style>