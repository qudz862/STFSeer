<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'

const inforStore = useInforStore()

const hist_view_id = (type, attr) => `hist-${type}-${attr}`

watch (() => inforStore.cur_phase_sorted_id, (oldVlaue, newValue) => {
  // drawEventsScatterPlot()
})

function drawEventsHist(event_type, event_attr) {
  // let 

  let svg_id = hist_view_id(event_type, event_attr)
  d3.select(`#${svg_id}`).selectAll('*').remove()
  let margin_left = 0, margin_right = 0, margin_top = 0, margin_bottom = 0
  let main_w = 300, main_h = 300
  const main_width = width - margin.left - margin.right
  const main_height = height - margin.top - margin.bottom
  let svg = d3.select(`#${svg_id}`)
    .attr('width', main_width)
    .attr('height', main_height)
  
}

function drawEventsScatterPlot() {
  d3.select('#events-svg').selectAll('*').remove()
  let margin_left = 70, margin_right = 70, margin_top = 18, margin_bottom = 10
  let main_w = 300, main_h = 300
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let svg = d3.select('#events-svg')
    .attr('width', svg_w)
    .attr('height', svg_h)
    .append("g")
    .attr("transform", `translate(${margin_left},${margin_top})`)
  let cur_phase_id = inforStore.cur_phase_sorted_id
  let phase_events = inforStore.st_phase_events.phases_list[cur_phase_id].evolution_events
  let phase_events_indicators = inforStore.cur_phase_indicators[cur_phase_id].events_indicators
  // let events = inforStore.st_phase_events.phases_list[cur_phase_id].events_list
  // let events_indicators = inforStore.cur_phase_indicators[cur_phase_id].phases_indicators
  let change_grids_arr = phase_events.map(item => item.area_event.change_grid_num)
  let change_vals_arr = phase_events.map(item => item.intensity_event.total_change_abs)
  let x_scale = d3.scaleLinear().domain([0, d3.max(change_grids_arr)]).range([0, main_w])
  let y_scale = d3.scaleLinear().domain([0, d3.max(change_vals_arr)]).range([main_h, 0])

  // .ticks(inforStore.model_parameters.output_window)
  //   .tickFormat(d => d)
  let union_residual_abs = phase_events_indicators.map(item => item[0]['union_residual_abs'])
  // let clean_union_residual_abs = phase_events_indicators.map(item => item[0]['union_residual_abs'])
  let x_axis = d3.axisBottom(x_scale)
  let y_axis = d3.axisLeft(y_scale)
  let errScale = d3.scaleLinear()
    .domain(d3.extent(union_residual_abs))
    .range(valColorScheme_red)
  svg.append("g")
    .attr("class", "x-axis")
    .attr("transform", `translate(0,${main_h})`)
    .call(x_axis)
  svg.append("g")
    .attr("class", "y-axis")
    .call(y_axis)
  let event_points = svg.append('g')
    .attr('class', 'clean_event_points')
  event_points.selectAll('circle')
    .data(phase_events)
    .join('circle')
    .attr('cx', (d, i) => x_scale(d.change_grid_num))
    .attr('cy', d => y_scale(d.total_change_abs))
    .attr('r', 3)
    .attr('fill', (d,i) => errScale(union_residual_abs[i]))
    .attr('stroke', 'none')
    .attr('opacity', 0.6)
}

</script>

<template>
  <div class="events-container">
    <div class="title-layer">
      <div class="title">Events View</div>
    </div>
    <div>
      <table v-if="inforStore.filtered_subsets.length > 0" class="table table-fixed-header">
        <thead>
          <tr>
            <th scope="col">Event Type</th>
            <th scope="col">Current Area</th>
            <th scope="col">Area Change</th>
            <th scope="col">Area Error</th>
            <th scope="col">Current Intensity</th>
            <th scope="col">Intensity Change</th>
            <th scope="col">Intensity Error</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in inforStore.event_types" :key="index" class="event-infor-row">
            <td>{{ item }}</td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'cur_grid_num')"></svg> </td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'change_grid_num')"></svg></td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'area_error')"></svg></td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'cur_val')"></svg></td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'mean_change_val')"></svg></td>
            <td><svg class="event-attr-hist" :id="hist_view_id(item, 'intensity_error')"></svg></td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- <svg id="events-svg"></svg> -->

  </div>

</template>

<style scoped>
.events-container {
  /* width: 1600px; */
  width: 1610px !important;
  height: 622px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 0;
  /* overflow-y: auto; */
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 700px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  /* font: 700 20px "Arial"; */
  /* letter-spacing: 1px; */
  /* color: #333; */
  display: flex;
  align-items: center;
  /* justify-content: space-between; */
}

.title {
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
}

.table-fixed-header thead {
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 1000;
}

.event-attr-hist {
  width: 70px;
  height: 20px;
}
</style>