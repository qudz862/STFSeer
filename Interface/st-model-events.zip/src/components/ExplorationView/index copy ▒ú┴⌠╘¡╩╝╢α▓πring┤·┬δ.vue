<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'

const inforStore = useInforStore()
let global_time_id = ref(0)
let cur_sel_step = ref(0)
let cur_hover_loc = ref(-1)

const axis_attrs = ref(['Ground Truth', 'Prediction', 'Residual', 'target_val', 'temporal_state_vals', 'space_diff_state_vals', 'space_comp_state_vals'])
// let cur_x_attr = ref('Ground Truth')
// let cur_y_attr = ref('Prediction')
let bin_color_types = ref(['Count', 'Ground Truth', 'Prediction', 'Residual', 'target_val', 'temporal_state_vals', 'space_diff_state_vals', 'space_comp_state_vals'])
// let cur_bin_color = ref('Count')
// let cur_x_bin_edges = inforStore.cur_val_bins
// let cur_y_bin_edges = inforStore.cur_val_bins

function generateArray(n) {
    var result = [];
    for (var i = 1; i <= n; i++) {
        result.push(i);
    }
    return result;
}

let intervalId_phase
let intervalId_subset

let inspect_modes = ['error', 'prediction']
let cur_inspect_mode = ref('prediction')
let pred_infors = ['']
let err_indicators = ['multi_indicators', 'residual', 'binary', 'level']
let cur_err_indicators = ref('multi_indicators')
// let focus_fore_steps = ref([1,1])
let cur_event_start = 0
let cur_sel_event_step = 0

// watch (() => inforStore.cur_data_infor, (oldVlaue, newValue) => {
//   focus_fore_steps.value = [1, inforStore.cur_data_infor.time.output_window]
// })

function askForDrawPhase() {
    // 检查是否存在目标元素
    const targetElement = document.getElementById('st-layout-phase');

    if (targetElement) {
        // 目标元素存在，执行特定语句
        drawSTLayout_Phase()
        // 停止轮询
        clearInterval(intervalId_phase);
    } else {
        // 目标元素不存在，继续轮询
        // console.log('目标元素未找到，继续轮询');
    }
}

function askForDrawSubset(subset_details) {
    // 检查是否存在目标元素
    const targetElement = document.getElementById('join-dist-space');

    if (targetElement) {
        // 目标元素存在，执行特定语句
        drawSubsetDetails(subset_details)
        // 停止轮询
        clearInterval(intervalId_subset);
    } else {
        // 目标元素不存在，继续轮询
        // console.log('目标元素未找到，继续轮询');
    }
}

onUpdated(() => {
  if ((inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)) {
    // drawSTLayout_Phase()
  }
  else if (inforStore.cur_detail_type == 'subset') drawSubsetDetails(inforStore.sel_subset_details)
})

watch (() => inforStore.sel_phase_details, (oldVlaue, newValue) => {
  inforStore.cur_detail_type = 'phase'
  cur_sel_step.value = 0
  cur_event_start = 0
  cur_sel_event_step = 0
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  global_time_id.value = parseInt(cur_sel_step.value) + parseInt(phase_infor.start)
  // 启动轮询，每隔一定时间调用一次轮询函数
  // intervalId_phase = setInterval(askForDrawPhase, 100);
  if (document.getElementById('st-layout-phase')){
    drawSTLayout_Phase()
    drawTimeEventBar()
  }
  // drawLevelConfusionSpace(inforStore.sel_phase_details)
  // console.log(inforStore.sel_phase_details)
})

let other_indicators = ref(['POD/FAR', 'Multi_accuracy'])
let other_focused_indicators = ref([])
watch (() => inforStore.cur_timeline_indicator, (oldVlaue, newValue) => {
  if (inforStore.cur_timeline_indicator == 'Residual_abs') other_indicators.value = ['POD/FAR', 'Multi_accuracy']
  if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') other_indicators.value = ['Multi_accuracy', 'Residual_abs']
  if (inforStore.cur_timeline_indicator == 'Multi_accuracy') other_indicators.value = ['POD/FAR', 'Residual_abs']
  other_focused_indicators.value = []
  drawSTLayout_Phase()
  drawTimeEventBar()
})

watch (() => other_focused_indicators.value, (oldVlaue, newValue) => {
  console.log(other_focused_indicators.value);
  drawSTLayout_Phase()
  // drawTimeEventBar()
})

watch (() => inforStore.cur_grid_indicator, (oldVlaue, newValue) => {
  drawSTLayout_Phase()
})

watch (() => inforStore.sel_subset_details, (oldVlaue, newValue) => {
  inforStore.cur_detail_type = 'subset'
  // intervalId_subset = setInterval(() => askForDrawSubset(inforStore.sel_subset_details), 100);
  if (document.getElementById('join-dist-space'))
    drawSubsetDetails(inforStore.sel_subset_details)
  // console.log(inforStore.sel_subset_details)
})

watch (() => cur_sel_step.value, (oldVlaue, newValue) => {
  console.log(cur_sel_step.value);
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  global_time_id.value = parseInt(cur_sel_step.value) + parseInt(phase_infor.start)
  console.log(global_time_id.value);
  drawSTLayout_Phase()
})

let cur_transform_state = {k: 1, x: 0, y: 0}
let cur_phase_time_str = ref('')
function drawSTLayout_Phase() {
  let phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_list = inforStore.st_phase_events.phases_list
  let stamp_id = phase_list[phase_id].start + Number(cur_sel_step.value)
  let stamp_strs = inforStore.st_phase_events.time_strs
  cur_phase_time_str.value = stamp_strs[stamp_id]
  d3.select('#st-layout-phase').selectAll('*').remove()
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let space_layout_w = 780, space_layout_h = 780, time_bar_h = 10
  let margin_left = 50, margin_right = 10
  let st_layout_w = space_layout_w + margin_left + margin_right
  let st_layout_h = space_layout_h - 5

  let st_layout_svg = d3.select('#st-layout-phase')
    .attr('width', st_layout_w)
    .attr('height', st_layout_h)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let grid_borders = inforStore.cur_data_infor.space.grid_borders
  // console.log(grid_borders);
  let grid_points = grid_borders.map(item => item['border_points'])
  // let grid_points_end = grid_borders.map(item => item['border_points'].slice(1, 5))
  let grid_points_x = grid_points.map(item => item.map(e => e[0])).flat()
  let grid_points_y = grid_points.map(item => item.map(e => e[1])).flat()
  
  let white_rate = 0.05
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...grid_points_x), Math.max(...grid_points_x)])
        .range([space_layout_w*white_rate, space_layout_w*(1-white_rate)])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...grid_points_y), Math.max(...grid_points_y)])
        .range([space_layout_h*(1-white_rate), space_layout_h*white_rate])
  let space_layout_g = st_layout_svg.append('g')
    // .attr('transform', `translate(${margin_left}, -30)`)
    .attr('transform', cur_transform_state)
  let grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+50}, 10) scale(0.96)`)
  let pollu_grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+50}, 10) scale(0.96)`)

  let line = d3.line()
    .x(d => loc_x_scale(d[0])) // x 坐标映射
    .y(d => loc_y_scale(d[1])); // y 坐标映射
  let level_id_list = []
  for (let i = 0; i < inforStore.cur_val_bins.length-1; ++i) {
    level_id_list.push(i)
  }
  // console.log(level_id_list);
  // console.log(inforStore.sel_phase_details.phase_raw_level);
  let boxColorLevel = d3.scaleOrdinal()
    .domain(level_id_list)
    .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])
  let boxColorPOD = d3.scaleOrdinal()
    .domain([-2, -1, 1, 2])
    .range([valColorScheme_blue[3], '#cecece', '#333', valColorScheme_fire[3]])
  let boxColorFAR = d3.scaleOrdinal()
    .domain([-1, 0, 1])
    .range([valColorScheme_blue[3], '#cecece', valColorScheme_fire[3]])
  grid_borders_g.selectAll('path')
    .data(grid_points)
    .join('path')
      .attr('id', (d,i) => `loc-${i}`)
      .attr("d", line) // 应用生成器
      .attr("fill", (d, i) => boxColorLevel(inforStore.sel_phase_details.phase_raw_level[cur_sel_step.value][i]))
      // .attr("fill", (d, i) => {
      //   if (inforStore.cur_grid_indicator == 'residual')
      //     return boxColorLevel(inforStore.sel_phase_details.phase_raw_level[cur_sel_step.value][i])
      //   else if (inforStore.cur_grid_indicator == 'POD')
      //     return boxColorPOD(inforStore.sel_phase_details.phase_raw_level[cur_sel_step.value][i])
      //   else if (inforStore.cur_grid_indicator == 'FAR')
      //     return boxColorFAR(inforStore.sel_phase_details.phase_raw_level[cur_sel_step.value][i])
      // })
      .attr("stroke", "#999")
      .attr("stroke-width", 1)
      .attr("opacity", 0.9)
      .on('mouseover', (e) => {
        // console.log(e);
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        cur_hover_loc.value = target_id
      })
      .on('mouseout', (e) => {
        cur_hover_loc.value = -1
      })
  let pollu_grid_points = grid_points.filter(function(value, index) {
    let cur_level = inforStore.sel_phase_details.phase_raw_level[cur_sel_step.value][index]
    let cur_th = inforStore.cur_val_bins[cur_level]
    return (cur_th >= inforStore.phase_params.focus_th)
  });
  pollu_grid_borders_g.selectAll('path')
    .data(pollu_grid_points)
    .join('path')
      .attr('id', (d,i) => `loc-${i}`)
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", (d,i) => '#000')
      .attr("stroke-width", 2)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
      .attr("opacity", 0.9)

  let glyphs_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+50}, 10) scale(0.96)`)
  let binary_labels = inforStore.sel_phase_details.st_binary_label[cur_sel_step.value]
  let multi_labels = inforStore.sel_phase_details.st_multi_label[cur_sel_step.value]
  let residuals = inforStore.sel_phase_details.st_residuals[cur_sel_step.value]
  let binary_pred = inforStore.sel_phase_details.phase_pred_flag[cur_sel_step.value]
  let level_pred = inforStore.sel_phase_details.phase_pred_level[cur_sel_step.value]
  let val_pred = inforStore.sel_phase_details.phase_pred_val[cur_sel_step.value]

  let cur_focus_indicator
  if (inforStore.cur_timeline_indicator == 'Residual_abs') {
    cur_focus_indicator = residuals
  } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
    cur_focus_indicator = binary_pred
  } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
    cur_focus_indicator = multi_labels
  }
  
  let pie = d3.pie();
  pie.sort(null);
  let forecast_step_num = residuals[0].length
  let arcData = pie(Array(forecast_step_num).fill(1))
  let local_err_max = d3.max(residuals.map(item => d3.max(item)))
  let local_err_min = d3.min(residuals.map(item => d3.min(item)))
  let local_err_abs_max = d3.max([-local_err_min, local_err_max])
  let local_err_range = [-local_err_abs_max.toFixed(2), local_err_abs_max.toFixed(2)]
  // console.log(local_err_range);
  let residualsColorScale = d3.scaleSequential(d3.interpolateRdBu)
  // let residualsColorScale = d3.scaleSequential(d3.interpolateBrBG)
    // .domain(inforStore.global_err_range)
    .domain(local_err_range)
  if (other_focused_indicators.value.length == 0) {
    let singleIndicatorArc = d3.arc()
      .innerRadius(0)
      .outerRadius(20)
    for (let i = 0; i < residuals.length; ++i) {
      let single_glyphs_g = glyphs_g.append('g')
      let single_ring = single_glyphs_g.append('g')
        .attr('class', '.binary-pred-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', singleIndicatorArc)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        single_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        single_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#eee'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        single_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }

  if (other_focused_indicators.value.length == 1) {
    let other_indicator
    if (other_focused_indicators.value[0] == 'POD/FAR') other_indicator = binary_pred
    if (other_focused_indicators.value[0] == 'Multi_accuracy') other_indicator = multi_labels
    if (other_focused_indicators.value[0] == 'Residual_abs') other_indicator = residuals
    
    let doubleIndicatorArc_1 = d3.arc()
      .innerRadius(0)
      .outerRadius(12)
    let doubleIndicatorArc_2 = d3.arc()
      .innerRadius(16)
      .outerRadius(24)
    for (let i = 0; i < residuals.length; ++i) {
      let glyphs_1_g = glyphs_g.append('g')
      let glyphs_1_ring = glyphs_1_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_1)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        glyphs_1_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#eee'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_2_g = glyphs_g.append('g')
      let glyphs_2_ring = glyphs_2_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_2)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[0] == 'Residual_abs') {
        glyphs_2_ring.attr('fill', (d,j) => residualsColorScale(other_indicator[i][j]))
      } else if (other_focused_indicators.value[0] == 'POD/FAR') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator[i][j] == 1) return '#333'
          else if (other_indicator[i][j] == 0) return '#eee'
        })
      } else if (other_focused_indicators.value[0] == 'Multi_accuracy') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator[i][j] == 0) return '#cecece'
          else if (other_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }

  if (other_focused_indicators.value.length == 2) {
    let other_indicator_1, other_indicator_2
    if (other_focused_indicators.value[0] == 'POD/FAR') other_indicator_1 = binary_pred
    if (other_focused_indicators.value[0] == 'Multi_accuracy') other_indicator_1 = multi_labels
    if (other_focused_indicators.value[0] == 'Residual_abs') other_indicator_1 = residuals
    if (other_focused_indicators.value[1] == 'POD/FAR') other_indicator_2 = binary_pred
    if (other_focused_indicators.value[1] == 'Multi_accuracy') other_indicator_2 = multi_labels
    if (other_focused_indicators.value[1] == 'Residual_abs') other_indicator_2 = residuals
    
    let doubleIndicatorArc_1 = d3.arc()
      .innerRadius(0)
      .outerRadius(8)
    let doubleIndicatorArc_2 = d3.arc()
      .innerRadius(10)
      .outerRadius(16)
    let doubleIndicatorArc_3 = d3.arc()
      .innerRadius(18)
      .outerRadius(24)
    
    for (let i = 0; i < residuals.length; ++i) {
      let glyphs_1_g = glyphs_g.append('g')
      let glyphs_1_ring = glyphs_1_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_1)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        glyphs_1_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#eee'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_2_g = glyphs_g.append('g')
      let glyphs_2_ring = glyphs_2_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_2)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[0] == 'Residual_abs') {
        glyphs_2_ring.attr('fill', (d,j) => residualsColorScale(other_indicator_1[i][j]))
      } else if (other_focused_indicators.value[0] == 'POD/FAR') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator_1[i][j] == 1) return '#333'
          else if (other_indicator_1[i][j] == 0) return '#eee'
        })
      } else if (other_focused_indicators.value[0] == 'Multi_accuracy') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator_1[i][j] == 0) return '#cecece'
          else if (other_indicator_1[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator_1[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_3_g = glyphs_g.append('g')
      let glyphs_3_ring = glyphs_3_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_3)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[1] == 'Residual_abs') {
        glyphs_3_ring.attr('fill', (d,j) => residualsColorScale(other_indicator_2[i][j]))
      } else if (other_focused_indicators.value[1] == 'POD/FAR') {
        glyphs_3_ring.attr('fill', (d,j) => {
          if (other_indicator_2[i][j] == 1) return '#333'
          else if (other_indicator_2[i][j] == 0) return '#eee'
        })
      } else if (other_focused_indicators.value[1] == 'Multi_accuracy') {
        glyphs_3_ring.attr('fill', (d,j) => {
          if (other_indicator_2[i][j] == 0) return '#cecece'
          else if (other_indicator_2[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator_2[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }
  
  // 暂时先不绘制多指标的glyph，信息有点乱
  // // 极坐标图参数
  // let binaryInnerR = 0;
  // let binaryOuterR = 10
  // let angleOffset = -Math.PI / 2; // 角度偏移量，使图形从正上方开始

  // // 创建径向热力图
  // // console.log(inforStore.sel_phase_details.st_binary_label);
  // let pie = d3.pie();
  // pie.sort(null);
  // let forecast_step_num = residuals[0].length
  // let arcData = pie(Array(forecast_step_num).fill(1))
  // // console.log(podArcData)
  // let binaryArc = d3.arc()
  //   .innerRadius(0)
  //   .outerRadius(8)
  // let multiArc = d3.arc()
  //   .innerRadius(10)
  //   .outerRadius(16)
  // let residualsArc = d3.arc()
  //   .innerRadius(18)
  //   .outerRadius(24)
  

  // for (let i = 0; i < residuals.length; ++i) {
  //   let single_glyphs_g = glyphs_g.append('g')
  //     .on('click', () => {
  //       // let phase_id = inforStore.cur_phase_sorted_id
  //       // let phase_list = inforStore.st_phase_events.phases_list
  //       // let stamp_strs = inforStore.st_phase_events.time_strs
  //       // let stamp_id = phase_list[phase_id].start + Number(cur_sel_step.value)
  //       // console.log(phase_list[phase_id].start, cur_sel_step.value, stamp_id);
  //       inforStore.ins_inspect_type = 'phase'
  //       $('.overlay-container').css('display', 'flex')
  //       inforStore.cur_sel_condition.loc_id = i
  //       let tmp_stamp_obj = {}
  //       tmp_stamp_obj[String(stamp_id)] = {}
  //       tmp_stamp_obj[String(stamp_id)]['stamp_id'] = stamp_id
  //       tmp_stamp_obj[String(stamp_id)]['timestamp'] = stamp_strs[stamp_id]
  //       tmp_stamp_obj[String(stamp_id)]['fore_step'] = Array.from({ length: binary_labels[i].length }, (_, index) => index);
  //       tmp_stamp_obj[String(stamp_id)]['binary_label'] = binary_labels[i]
  //       tmp_stamp_obj[String(stamp_id)]['multi_label'] = multi_labels[i]
  //       tmp_stamp_obj[String(stamp_id)]['residual'] = residuals[i]
  //       inforStore.tile_resi_edge_range = local_err_range
  //       inforStore.cur_sel_stamp_objs_single = tmp_stamp_obj
  //       getData(inforStore, 'instance_seqs', stamp_id, i)
  //     })
  //   let binary_ring = single_glyphs_g.append('g')
  //       .attr('class', '.binary-ring')
  //       .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
  //         .selectAll('path')
  //         .data(arcData)
  //         .join("path")
  //           .attr('d', binaryArc)
  //           .attr('stroke', '#999')
  //           .attr('fill', (d,j) => {
  //             if (binary_labels[i][j] == 1) return '#333'
  //             else if (binary_labels[i][j] == -1) return '#cecece'
  //             else if (binary_labels[i][j] == 2) return valColorScheme_fire[3]
  //             else if (binary_labels[i][j] == -2) return valColorScheme_blue[3]
  //           })
  //   let multi_ring = single_glyphs_g.append('g')
  //       .attr('class', '.multi-ring')
  //       .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
  //         .selectAll('path')
  //         .data(arcData)
  //         .join("path")
  //           .attr('d', multiArc)
  //           .attr('stroke', '#999')
  //           .attr('fill', (d,j) => {
  //             // return '#cecece'
  //             if (multi_labels[i][j] == 0) return '#cecece'
  //             else if (multi_labels[i][j] == 1) return valColorScheme_fire[3]
  //             else if (multi_labels[i][j] == -1) return valColorScheme_blue[3]
  //             else return '#cecece'
  //           })
  //   let residuals_ring = single_glyphs_g.append('g')
  //       .attr('class', '.residuals-ring')
  //       .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
  //         .selectAll('path')
  //         .data(arcData)
  //         .join("path")
  //           .attr('d', residualsArc)
  //           .attr('stroke', '#999')
  //           .attr('fill', (d,j) => residualsColorScale(residuals[i][j]))
  // }

  // let initialTransform = d3.zoomIdentity;
  let zoom_func = d3.zoom()
    .scaleExtent([0.1, 10])
    .on('zoom', handleZoom);
  // st_layout_svg.call(zoom_func.transform, initialTransform);
  st_layout_svg.call(zoom_func)
  // let transformState = d3.zoomIdentity;
  
  function handleZoom(e) {
    cur_transform_state = e.transform;
    space_layout_g.attr('transform', cur_transform_state)
  }
  
  let resi_legend_len = 120
  let resiLegendScale = d3.scaleSequential(d3.interpolateRdBu)
  // let resiLegendScale = d3.scaleSequential(d3.interpolateBrBG)
    .domain([0, resi_legend_len])
  let residual_legend = st_layout_svg.append('g')
    .attr('transform', 'translate(60, 20)')
  residual_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => resiLegendScale(i))
  residual_legend.append('text')
    .attr('x', resi_legend_len * 0.5)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Residual Colormap')
  residual_legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${local_err_range[0]}`)
  residual_legend.append('text')
    .attr('x', resi_legend_len+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${local_err_range[1]}`)
  let binary_label_legend = st_layout_svg.append('g')
    .attr('transform', `translate(${resi_legend_len+165}, 20)`)
  let label_block_w = 60, box_w = 12
  binary_label_legend.append('text')
    .attr('x', 140)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Dichotomous Label')
  binary_label_legend.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#333') // hit
  binary_label_legend.append('text')
    .attr('x', box_w + 3)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Hit')

  binary_label_legend.append('rect')
    .attr('x', box_w+30).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#cecece') // neg correct
  binary_label_legend.append('text')
    .attr('x', box_w*2 + 33)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Correct Negative')
  
  binary_label_legend.append('rect')
    .attr('x', box_w*2+133).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_fire[3]) // false alarm
  binary_label_legend.append('text')
    .attr('x', box_w*3 + 136)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('False Alarm')
  
  binary_label_legend.append('rect')
    .attr('x', box_w*3+209).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_blue[3]) // false alarm
  binary_label_legend.append('text')
    .attr('x', box_w*4 + 212)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Miss')

  let multi_label_legend = st_layout_svg.append('g')
    .attr('transform', `translate(${resi_legend_len+515}, 20)`)
  multi_label_legend.append('text')
    .attr('x', 90)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Multi-category Label')
  multi_label_legend.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#cecece')
  multi_label_legend.append('text')
    .attr('x', box_w + 3)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Accurate')  // 估计准确 

  multi_label_legend.append('rect')
    .attr('x', box_w + 62).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_fire[3])
  multi_label_legend.append('text')
    .attr('x', box_w*2 + 65)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Higher')

  multi_label_legend.append('rect')
    .attr('x', box_w*2 + 110).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_blue[3])
  multi_label_legend.append('text')
    .attr('x', box_w*3 + 113)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Lower')
}

function drawTimeEventBar() {
  d3.select('#time-event-bar').selectAll('*').remove()
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let space_layout_w = 780, space_layout_h = 180, time_bar_h = 10
  let margin_left = 50, margin_right = 10
  let st_layout_w = space_layout_w + margin_left + margin_right
  let st_layout_h = space_layout_h + time_bar_h*3 - 20
  let st_layout_svg = d3.select('#time-event-bar')
    .attr('width', st_layout_w)
    .attr('height', st_layout_h)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let white_rate = 0.06
  // 绘制事件bar，略缩图
  let events_scope = 10
  let cell_w = 70, cell_h = 70
  let evevt_bar_y_shift = 136
  if (loc_coords_x.length > 100) {
    events_scope = 9
    cell_w = 80
    cell_h = 80
    evevt_bar_y_shift += 10
  }
  let cur_event_end = cur_event_start + events_scope
  
  let events_bar_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-evevt_bar_y_shift})`)
  let cell_x_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_x), Math.max(...loc_coords_x)])
        .range([cell_w*(white_rate), cell_w*(1-white_rate)])
  let cell_y_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_y), Math.max(...loc_coords_y)])
        .range([cell_h*(1-white_rate), cell_h*white_rate])
  let cellValColor = d3.scaleOrdinal()
    .domain(d3.range(inforStore.cur_val_bins.length))
    .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])

  let phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
  let phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
  let phase_raw_infor = []
  for (let i = 0; i < phase_raw_data.length; i++) {
    phase_raw_infor.push([])
    for (let j = 0; j < phase_raw_data[i].length; ++j) {
      phase_raw_infor[i].push({
        'val': phase_raw_data[i][j],
        'level': phase_raw_level[i][j]
      })
    }
  }
  let data_cells = events_bar_g.selectAll('g')
    .data(phase_raw_infor)
    .join('g')
      .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
      .style('cursor', 'pointer')
      .on('click', (e,d) => {
        cur_sel_event_step = d3.select(e.target).attr('cur_event_step')
        cur_sel_step.value = cur_event_start + parseInt(cur_sel_event_step)
        data_cells.selectAll('rect').attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        event_header_g.select('rect')
          .attr('fill', (d,i) => {
            console.log(d);
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.select('text')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
      })
  let cell_header_h = 14
  let cur_phase_id = inforStore.cur_phase_sorted_id
  let phase_events = inforStore.st_phase_events.phases_list[cur_phase_id].evolution_events

  let cur_events = []
  for (let i = 0; i < events_scope; ++i) {
    cur_events.push([])
    for (let j = 0; j < phase_events.length; ++j) {
      if (phase_events[j].step_id == i+cur_event_start) {
        cur_events[i].push(phase_events[j])
      }
      // if (phase_events[j].step_id > i+cur_event_start) break
    }
  }
  // 建立事件header
  let events_headers_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-evevt_bar_y_shift})`)
  let event_headers_g = events_headers_g.selectAll('g')
    .data(cur_events)
    .join('g')
      .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
      .attr('event-step', (d,i) => i)
  let event_header_g = event_headers_g.selectAll('g')
    .data(d => d)
    .join('g')
      .attr('id', (d,i) => `cur-event-${i}`)
      .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
  event_header_g.append('rect')
    .attr('x', -0.5).attr('y', 0)
    .attr('width', cell_w+1).attr('height', cell_header_h)
    .attr('fill', (d,i) => {
      if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
      else return '#cecece'
    })
  event_header_g.append('text')
    .attr('x', cell_w/2).attr('y', 10)
    .attr('text-anchor', 'middle')
    .style('font-size', '9px')
    .attr('fill', (d,i) => {
      if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
      else return '#333'
    })
    .text((d,i) => d.area_event.type)

  data_cells.append('rect')
    .attr('id', (d,i) => `data-cell-${i}`)
    .attr('cur_event_step', (d,i) => i)
    .attr('x', 0).attr('y', 0)
    .attr('width', cell_w).attr('height', cell_h)
    .attr('fill', '#fff')
    .attr('stroke', (d,i) => {
      if (i == cur_sel_event_step) return '#333'
      else return '#bababa'
    })
  data_cells.selectAll('circle')
    .data(d => d)
    .join('circle')
      .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
      .attr('loc_id', (d,i) => i)
      .attr('r', 2)
      .attr('fill', (d,i) => cellValColor(d.level))
      .attr('stroke', (d,i) => {
        if (d.val >= inforStore.phase_params.focus_th) return '#333'
        else return 'none'
      })
  
  let time_bar_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-52})`)
  let time_axis_bar = time_bar_g.append('g')
  let phase_len = inforStore.st_phase_events.phases_list[sel_phase_id].end - inforStore.st_phase_events.phases_list[sel_phase_id].start
  let temporal_ids = []
  for (let i = 0; i < phase_len; i++) {
    temporal_ids.push(i);
  }
  let step_width = (space_layout_w-20) / phase_len

  let temporal_err_scale = d3.scaleQuantize()
    .domain([0, inforStore.sel_phase_details.temporal_residuals_abs_max])
    .range(valColorScheme_fire)
  // let temporal_err_scale = d3.scaleLinear()
  // let temporal_err_scale = d3.scaleSequential(d3.interpolateGreens)
  //   .domain([0, inforStore.sel_phase_details.temporal_residuals_abs_max])
    // .range(['#eee', '#000'])
    // .range(valColorScheme_fire)
  let temporal_rate_scale = d3.scaleQuantize()
    .domain([0, 1])
    .range(valColorScheme_fire)
  // let temporal_rate_scale = d3.scaleLinear()
  // let temporal_rate_scale = d3.scaleSequential(d3.interpolateGreens)
  //   .domain([0, 1])
    // .range(['#eee', '#000'])
    // .range(valColorScheme_fire)
  // let time_x_scale = d3.scaleLinear()
  //   .domain(temporal_ids)
  //   .range([0, space_layout_w])
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  let cntColormap = d3.scaleLinear()
    .domain([0, 1])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length - 1]])
    // .range(['#eee', '#000'])
  
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 8)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text('Pollution_cnt')
  time_axis_bar.append('g').selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `time_unit-${d}`)
      .attr('x', d => d * step_width)
      .attr('y', 0)
      .attr('width', step_width)
      .attr('height', time_bar_h)
      .attr('fill', d => {
        if (phase_infor.time_pollution_cnt_all[d] == 0) return '#fff'
        else return cntColormap(phase_infor.time_pollution_cnt_all[d])
      })
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        // console.log(inforStore.sel_phase_details.time_pod[target_id], inforStore.sel_phase_details.time_far[target_id]);
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        phase_raw_infor = []
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.selectAll('.slider')
          .attr('x', cur_event_start * step_width)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id
        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })
  // let valColor = d3.scaleQuantile()
  //   .domain([0, 500])
  //   .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])
  let valColor = d3.scaleLinear()
    .domain([0, 500])
    .range(['#fff', '#4a1486'])
    // .range(['#efedf5', '#4a1486'])
    // .range(['#eee', '#000'])
  // let valColor = d3.scaleSequential(d3.interpolateBlues)
  //   .domain([0, 500])
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 19)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text('Pollution_val')
  time_axis_bar.append('g').selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `time_unit-${d}`)
      .attr('x', d => d * step_width)
      .attr('y', time_bar_h)
      .attr('width', step_width)
      .attr('height', time_bar_h)
      .attr('fill', d => valColor(phase_infor.time_pollution_val[d]))
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        console.log(cur_event_start, cur_sel_event_step);
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        phase_raw_infor = []
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.selectAll('.slider')
          .attr('x', cur_event_start * step_width)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id

        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 30)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text(inforStore.cur_timeline_indicator)
  time_axis_bar.append('g').selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `time_unit-${d}`)
      .attr('x', d => d * step_width)
      .attr('y', time_bar_h*2)
      .attr('width', step_width)
      .attr('height', time_bar_h)
      .attr('fill', d => {
        if (inforStore.cur_timeline_indicator == 'Residual_abs')
          return temporal_err_scale(inforStore.sel_phase_details.temporal_residuals_abs[d])
        else if (inforStore.cur_timeline_indicator == 'Multi_accuracy')
          return temporal_rate_scale(inforStore.sel_phase_details.time_multi_accuracy[d])
        else if (inforStore.cur_timeline_indicator == 'POD') {
          console.log(inforStore.sel_phase_details.time_pod);
          return temporal_rate_scale(inforStore.sel_phase_details.time_pod[d])
        }
        else if (inforStore.cur_timeline_indicator == 'FAR') {
          // console.log(inforStore.sel_phase_details.time_far);
          return temporal_rate_scale(inforStore.sel_phase_details.time_far[d])
        }
      })
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        console.log(cur_event_start, cur_sel_event_step);
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        phase_raw_infor = []
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.selectAll('.slider')
          .attr('x', cur_event_start * step_width)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id

        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
          event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })
  
  let slider_h = 8
  time_bar_g.append('rect')
    .attr('id', 'start-slider')
    .attr('class', 'slider')
    .attr('x', cur_event_start*step_width)
    .attr('y', -slider_h)
    .attr('width', step_width*events_scope)
    .attr('height', slider_h)
    .attr('fill', '#333')
    .attr('stroke', 'none')
    .attr('opactiy', 0.2)
    // .style('cursor', 'crosshair')

  time_bar_g.append('rect')
    .attr('class', 'slider')
    .attr('x', cur_event_start*step_width)
    .attr('y', time_bar_h*3)
    .attr('width', step_width*events_scope)
    .attr('height', slider_h)
    .attr('fill', '#333')
    .attr('stroke', 'none')
    .attr('opactiy', 0.2)
    // .style('cursor', 'crosshair')
  // 定义拖拽
  let acc_dx = 0
  const slider_drag = d3.drag().on("start", function(event) {}).on("drag", function(event) {
    // console.log(event);
    // const x = Math.max(0, Math.min(temporal_ids.length-events_scope, event.x));
    // cur_event_start = Math.round(x / step_width) * step_width
    // cur_event_end = cur_event_start + events_scope
    // time_axis_bar.selectAll('.slider')
    //   .attr('x', cur_event_start*step_width)
    // data_cells.attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
    // console.log(event.x, event.dx);
    let curSliderX = d3.select('#start-slider').attr('x')
    acc_dx += event.dx
    if (Math.abs(acc_dx) > step_width) {
      let newSliderStep = Math.round((parseInt(curSliderX) + acc_dx) / step_width)
      cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, newSliderStep));
      cur_event_end = cur_event_start + events_scope
      // console.log(curSliderX, acc_dx, (parseInt(curSliderX) + acc_dx), Math.max(0, Math.min(temporal_ids.length-events_scope, newSliderStep)), temporal_ids.length-events_scope,cur_event_start)
      phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
      phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
      phase_raw_infor = []
      for (let i = 0; i < phase_raw_data.length; i++) {
        phase_raw_infor.push([])
        for (let j = 0; j < phase_raw_data[i].length; ++j) {
          phase_raw_infor[i].push({
            'val': phase_raw_data[i][j],
            'level': phase_raw_level[i][j]
          })
        }
      }
      time_bar_g.selectAll('.slider')
        .attr('x', cur_event_start * step_width)
      // data_cells.selectAll('circle').remove()
      data_cells = events_bar_g.selectAll('g')
        .data(phase_raw_infor)
        .join('g')
      data_cells.selectAll('circle')
        .data(d => d)
        .join('circle')
          .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
          .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
          .attr('loc_id', (d,i) => i)
          .attr('r', 2)
          .attr('fill', (d,i) => cellValColor(d.level))
          .attr('stroke', (d,i) => {
            if (d.val >= inforStore.phase_params.focus_th) return '#333'
            else return 'none'
          })
      acc_dx = 0

      cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
    }
  }).on("end", function(event) {
    cur_sel_event_step = 0
    data_cells.selectAll('rect')
      .attr('stroke', '#bababa')
    data_cells.select(`#data-cell-${cur_sel_event_step}`)
      .attr('stroke', '#333')
    cur_sel_step.value = cur_event_start
    event_header_g.select('rect')
      .attr('fill', (d,i) => {
        console.log(d);
        if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
        else return '#cecece'
      })
    event_header_g.select('text')
      .attr('fill', (d,i) => {
        if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
        else return '#333'
      })
  })

  time_bar_g.selectAll('.slider').call(slider_drag)

  let resi_legend_len = 120
  let pollutionCntScale = d3.scaleLinear()
      .domain([0, resi_legend_len])
      .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length - 1]])
  let pollution_cnt_legend = st_layout_svg.append('g')
    .attr('transform', `translate(40, ${space_layout_h-10})`)
  let x_shift_pollu_cnt = 92
  pollution_cnt_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i + x_shift_pollu_cnt)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => pollutionCntScale(i))
  pollution_cnt_legend.append('text')
    .attr('x', 30)
    .attr('y', 11)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Pollution Count')
  pollution_cnt_legend.append('text')
    .attr('x', -4+x_shift_pollu_cnt)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  pollution_cnt_legend.append('text')
    .attr('x', resi_legend_len+4+x_shift_pollu_cnt)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('1')
  
  let pollutionValScale = d3.scaleLinear()
      .domain([0, resi_legend_len])
      .range(['#fff', '#4a1486'])
  let pollution_val_legend = st_layout_svg.append('g')
    .attr('transform', `translate(230, ${space_layout_h-10})`)
  let x_shift_pollu_val = 140
  pollution_val_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i+x_shift_pollu_val)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => pollutionValScale(i))
  pollution_val_legend.append('text')
    .attr('x', 80)
    .attr('y', 11)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Pollution Value')
  pollution_val_legend.append('text')
    .attr('x', -4+x_shift_pollu_val)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  pollution_val_legend.append('text')
    .attr('x', resi_legend_len+4+x_shift_pollu_val)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('500')
  
  let indicatorScale = d3.scaleQuantize()
      .domain([0, resi_legend_len])
      .range(valColorScheme_fire)
  let indicator_legend = st_layout_svg.append('g')
    .attr('transform', `translate(430, ${space_layout_h-10})`)
  let x_shift_indicator = 220
  indicator_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i+x_shift_indicator)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => indicatorScale(i))
  indicator_legend.append('text')
    .attr('x', 160)
    .attr('y', 11)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${inforStore.cur_timeline_indicator}`)
  indicator_legend.append('text')
    .attr('x', -4+x_shift_indicator)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  indicator_legend.append('text')
    .attr('x', resi_legend_len+4+x_shift_indicator)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(() => {
      if (inforStore.cur_timeline_indicator == 'Residual_abs')
        return `${parseFloat(inforStore.sel_phase_details.temporal_residuals_abs_max.toFixed(2))}`
      else if (inforStore.cur_timeline_indicator == 'Multi_accuracy')
        return 1
      else if (inforStore.cur_timeline_indicator == 'POD')
        return 1
      else if (inforStore.cur_timeline_indicator == 'FAR')
        return 1
    })
}

function drawSubsetDetails(detail_data) {
  d3.select('#join-dist-space').selectAll('*').remove();
  let x_sum_dist = detail_data.x_sum_dist
  let y_sum_dist = detail_data.y_sum_dist
  let filtered_x_sum_dist = detail_data.x_sum_dist.filter((value, index) => {
    return x_sum_dist[index] !== 0;
  });
  let filtered_y_sum_dist = detail_data.y_sum_dist.filter((value, index) => {
    return y_sum_dist[index] !== 0;
  });
  // 基于bin_edges生成范围pair
  let x_range_pairs = [], y_range_pairs = []
  for (let i = 0; i < inforStore.cur_x_bin_edges.length - 1; i++) {
    const pair = [inforStore.cur_x_bin_edges[i], inforStore.cur_x_bin_edges[i + 1]];
    x_range_pairs.push(pair);
  }
  for (let i = 0; i < inforStore.cur_y_bin_edges.length - 1; i++) {
    const pair = [inforStore.cur_y_bin_edges[i], inforStore.cur_y_bin_edges[i + 1]];
    y_range_pairs.push(pair);
  }
  let filtered_x_range_pairs = x_range_pairs.filter((value, index) => {
    return x_sum_dist[index] !== 0;
  });
  let filtered_y_range_pairs = y_range_pairs.filter((value, index) => {
    return y_sum_dist[index] !== 0;
  });

  // console.log(detail_data.x_sum_dist, filtered_x_sum_dist, filtered_x_bin_edges);
  let joint_dist = detail_data.space_level_joint_dist
  let joint_dist_max_cnt = detail_data.space_joint_dist_max_cnt
  let filtered_x_joint_dist = detail_data.space_level_joint_dist.filter((value, index) => {
    // console.log(value);
    return x_sum_dist[index] !== 0;
  })
  // console.log(filtered_x_joint_dist);
  let filtered_joint_dist = filtered_x_joint_dist.map(item => {
    return item.filter((value, index) => y_sum_dist[index] !== 0)
  })
  // console.log(filtered_joint_dist);

  let cell_w = 85, cell_h = 85
  let margin_left = 70, margin_top = 42, margin_right = 10, margin_bottom = 10
  let bar_len = 40
  let mtx_w = cell_w * filtered_x_range_pairs.length
  let mtx_h = cell_h * filtered_y_range_pairs.length
  let whole_w = bar_len + mtx_w + margin_left + margin_right
  let whole_h = bar_len + mtx_h + margin_top + margin_bottom

  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let white_rate = 0.1
  let loc_x_scale = d3.scaleLinear()
    .domain([Math.min(...loc_coords_x), Math.max(...loc_coords_x)])
    .range([cell_w*(white_rate), cell_w*(1-white_rate)])
  
  let loc_y_scale = d3.scaleLinear()
    .domain([Math.min(...loc_coords_y), Math.max(...loc_coords_y)])
    .range([cell_h*(1-white_rate), cell_h*white_rate])
  let bar_len_x_scale = d3.scaleLinear()
    .domain([0, d3.max(filtered_x_sum_dist)])
    .range([0, bar_len])
  let bar_len_y_scale = d3.scaleLinear()
    .domain([0, d3.max(filtered_y_sum_dist)])
    .range([0, bar_len])
  let colormap = d3.scaleLinear()
    .domain([1, joint_dist_max_cnt])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])

  let confusion_svg = d3.select('#join-dist-space')
    .attr('width', whole_w)
    .attr('height', whole_h)
  let x_text_g = confusion_svg.append('g')
    .attr('transform', `translate(${bar_len + margin_left}, 0)`)
  let y_text_g = confusion_svg.append('g')
    .attr('transform', `translate(0, ${bar_len + margin_top})`)
  let x_bar_g = confusion_svg.append('g')
    .attr('transform', `translate(${margin_left+bar_len}, 0)`)
  let y_bar_g = confusion_svg.append('g')
    .attr('transform', `translate(0, ${margin_top+bar_len})`)
  let mtx_g = confusion_svg.append('g')
    .attr('transform', `translate(${margin_left+bar_len}, ${margin_top+bar_len})`)
  
  x_bar_g.selectAll('rect')
    .data(filtered_x_sum_dist)
    .join('rect')
      .attr('x', (d,i) => i * cell_w + 1)
      .attr('y', (d,i) => margin_top+bar_len-bar_len_x_scale(d))
      .attr('width', cell_w-2)
      .attr('height', d => bar_len_x_scale(d))
      .attr('fill', '#999')
      .attr('stroke', 'none')
  y_bar_g.selectAll('rect')
    .data(filtered_y_sum_dist)
    .join('rect')
      .attr('x', (d,i) => margin_left+bar_len-bar_len_y_scale(d))
      .attr('y', (d,i) => i * cell_h + 1)
      .attr('width', d => bar_len_y_scale(d))
      .attr('height', cell_h-2)
      .attr('fill', '#999')
      .attr('stroke', 'none')

  for (let i = 0; i < filtered_x_range_pairs.length; ++i) {
    x_text_g.append('text')
      .attr('class', '.range-txt')
      .attr('x', (i+0.5) * cell_w)
      .attr('y', margin_top-10)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text(`[${filtered_x_range_pairs[i][0]},${filtered_x_range_pairs[i][1]}]`)
  }
  for (let i = 0; i < filtered_y_range_pairs.length; ++i) {
    y_text_g.append("text")
      .attr("transform", `translate(${margin_left-10}, ${(i+0.5) * cell_h}) rotate(-90)`) // 旋转角度
      .attr("x", 0) // 设置 x 坐标
      .attr("y", 0) // 设置 y 坐标
      // .attr("dy", "0.35em") // 垂直对齐方式
      .attr("text-anchor", "middle") // 水平对齐方式
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text(`[${filtered_y_range_pairs[i][0]},${filtered_y_range_pairs[i][1]}]`)
  }
  // let cur_w = (inforStore.cur_x_bin_edges.length-1) * cell_w
  // let cur_h = (inforStore.cur_y_bin_edges.length-1) * cell_h
  x_text_g.append('text')
    .attr('x', mtx_w * 0.5)
    .attr('y', margin_top - 26)
    .attr("text-anchor", "middle") // 水平对齐方式
    .style('font-size', '14px')
    .attr('fill', '#333')
    .text(inforStore.cur_x_attr)
  y_text_g.append('text')
    .attr("transform", `translate(${margin_left - 26}, ${mtx_h * 0.5}) rotate(-90)`)
    .attr('x', 0)
    .attr('y', 0)
    .attr("text-anchor", "middle") // 水平对齐方式
    .style('font-size', '14px')
    .attr('fill', '#333')
    .text(inforStore.cur_y_attr)

  for (let i = 0; i < filtered_joint_dist.length; ++i) {
    let mtx_col = mtx_g.append('g')
      .attr('transform', `translate(${i*cell_w}, 0)`)
    for (let j = 0; j < filtered_joint_dist[i].length; ++j) {
      let mtx_cell = mtx_col.append('g')
        .attr('transform', `translate(0, ${j*cell_h})`)
      mtx_cell.append('rect')
        .attr('x', 0).attr('y', 0)
        .attr('width', cell_w).attr('height', cell_h)
        .attr('fill', 'none')
        .attr('stroke', '#cecece')
        .attr('stroke-width', 1)
      let tooltip = d3.select('#subset-detail-tooltip')
      mtx_cell.selectAll('circle')
        .data(filtered_joint_dist[i][j])
        .join('circle')
          .attr('x_id', i)
          .attr('y_id', j)
          .attr('loc_id', (d2,k) => k)
          .attr('cx', (d2,i) => loc_x_scale(loc_coords_x[i]))
          .attr('cy', (d2,i) => loc_y_scale(loc_coords_y[i]))
          .attr('r', 2.8)
          .attr('fill', (d2,i) => {
            if (d2 == 0) return '#cecece'
            else return colormap(d2)
          })
          .attr('stroke', 'none')
          .on('click', (e, d) => {
            // 获取点所代表的数据
            let target = d3.select(e.target)
            let x_condition = {}, y_condition = {}
            let x_condition_val = {}, y_condition_val = {}
            let loc_id = target.attr('loc_id')
            for (let k = 0; k < x_range_pairs.length; k++) {
              if (JSON.stringify(x_range_pairs[k]) === JSON.stringify(filtered_x_range_pairs[target.attr('x_id')])) {
                x_condition[inforStore.cur_x_attr] = k;
                x_condition_val[inforStore.cur_x_attr] = x_range_pairs[k]
                break;
              }
            }
            for (let k = 0; k < y_range_pairs.length; k++) {
              if (JSON.stringify(y_range_pairs[k]) === JSON.stringify(filtered_y_range_pairs[target.attr('y_id')])) {
                y_condition[inforStore.cur_y_attr] = k;
                y_condition_val[inforStore.cur_y_attr] = y_range_pairs[k]
                break;
              }
            }

            inforStore.cur_sel_condition.loc_id = loc_id
            inforStore.cur_sel_condition.x_condition = x_condition_val
            inforStore.cur_sel_condition.y_condition = y_condition_val
            getData(inforStore, 'instance_details_subset', inforStore.cur_sel_data, inforStore.cur_sel_model, inforStore.cur_sel_subset_id, JSON.stringify(x_condition), JSON.stringify(y_condition), loc_id)
            inforStore.ins_inspect_type = 'subset'
            $('.overlay-container').css('display', 'flex')
            // console.log(e);
          })
          .on('mouseover', (e,d) => {
            let target = d3.select(e.target)
            let html_txt = `
              ${inforStore.cur_x_attr}: [${filtered_x_range_pairs[target.attr('x_id')]}]<br>
              ${inforStore.cur_y_attr}: [${filtered_y_range_pairs[target.attr('y_id')]}]<br>
              ${inforStore.cur_bin_color}: ${d}
            `
            tooltip.html(html_txt)
              .style("left", `${e.pageX+20}px`)
              .style("top", `${e.pageY-30}px`)
              .style("opacity", 1)
          })
          .on('mouseout', (e,d) => {
            tooltip.style("opacity", 0);
          })
    }
  }
  drawInsNumLegend()
}

function drawInsNumLegend() {
  d3.select('#ins-num-legend').selectAll('*').remove()
  let margin_left = 20, margin_right = 40, margin_top = 0, margin_bottom = 0
  let main_w = 120, main_h = 12
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legend_svg = d3.select('#ins-num-legend')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legend = legend_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let legendScale = d3.scaleLinear()
    .domain([0, main_w])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
  legend.selectAll('rect')
    .data(Array(main_w).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => legendScale(i))
  legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  legend.append('text')
    .attr('x', main_w+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${inforStore.sel_subset_details.space_joint_dist_max_cnt}`)
}


function strToArray(str, c) {
  return str.split(c)
}

function onTimelineIndicatorSel(item) {
  inforStore.cur_timeline_indicator = item
  // console.log(inforStore.cur_focus_indicator);
  // drawTimeEventBar()
}

function onGridIndicatorSel(item) {
  inforStore.cur_grid_indicator = item
}

function onXAxisAttrChange(item) {
  inforStore.cur_x_attr = item
  if (inforStore.cur_x_attr == 'Ground Truth' || inforStore.cur_x_attr == 'Prediction') {
    inforStore.cur_x_bin_edges = inforStore.cur_val_bins
  } else if (inforStore.cur_x_attr == 'Residual') {
    inforStore.cur_x_bin_edges = inforStore.multi_step_err_infor.val_bins
  } else {
    inforStore.cur_x_bin_edges = inforStore.cur_range_infor[inforStore.cur_x_attr].seg_points
  }
  getData(inforStore, 'subset_details', inforStore.cur_sel_subset_id, inforStore.cur_x_attr, inforStore.cur_y_attr, JSON.stringify(inforStore.cur_x_bin_edges), JSON.stringify(inforStore.cur_y_bin_edges))
}

function onYAxisAttrChange(item) {
  inforStore.cur_y_attr = item
  if (inforStore.cur_y_attr == 'Ground Truth' || inforStore.cur_y_attr == 'Prediction') {
    inforStore.cur_y_bin_edges = inforStore.cur_val_bins
  } else if (inforStore.cur_y_attr == 'Residual') {
    inforStore.cur_y_bin_edges = inforStore.multi_step_err_infor.val_bins
  } else {
    inforStore.cur_y_bin_edges = inforStore.cur_range_infor[inforStore.cur_y_attr].seg_points
  }
  getData(inforStore, 'subset_details', inforStore.cur_sel_subset_id, inforStore.cur_x_attr, inforStore.cur_y_attr, JSON.stringify(inforStore.cur_x_bin_edges), JSON.stringify(inforStore.cur_y_bin_edges))
}

</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      Error Exploration View
      <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="sel-title">Focused indicator: </div>
      <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="data-dropdown">
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ inforStore.cur_timeline_indicator }}</button>
        <ul class="dropdown-menu">
          <li v-for="(item, index) in inforStore.indicators_list" :value="item" @click="onTimelineIndicatorSel(item)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div>
      <div class="form-check" v-for="(item, index) in other_indicators" :key="index">
        <input class="form-check-input" type="checkbox" :value="item" v-model="other_focused_indicators">
        <label class="form-check-label">{{ item }}</label>
      </div>
      <!-- <svg id="ins-num-legend"></svg> -->
      <!-- <div v-if="inforStore.cur_detail_type == 'phase'" class="data-dropdown">
      </div> -->
      <!-- <div v-if="inforStore.cur_detail_type == 'phase'" class="sel-title">Grid indicator: </div> -->
      <!-- <div v-if="inforStore.cur_detail_type == 'phase'" class="data-dropdown">
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ inforStore.cur_grid_indicator }}</button>
        <ul class="dropdown-menu">
          <li v-for="(item, index) in inforStore.indicators_list" :value="item" @click="onGridIndicatorSel(item)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div> -->
    </div>
    <div class="exploration-block">
      <svg v-if="inforStore.cur_detail_type == 'phase'" id="st-layout-phase"></svg>
      <svg v-if="inforStore.cur_detail_type == 'phase'" id="time-event-bar"></svg>
      <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="cur_stamp-row">
        <div class="title">Timestamp: </div>
        <div class="cur_stamp">{{ cur_phase_time_str }}</div>
      </div>

      <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="feature-panel-title">Features: </div>
      <div v-if="inforStore.cur_detail_type == 'phase'" class="feature-panel">
        <div v-for="(item, index) in inforStore.feature_infor.input.split(',')" :key="index"><span v-if="cur_hover_loc != -1">{{item}}: {{inforStore.cur_data_infor.raw_data[global_time_id][cur_hover_loc][index]}}</span></div>
      </div>
      <!-- <svg v-if="inforStore.cur_detail_type == 'subset'" id="st-layout-subset"></svg> -->
      <!-- <svg id="level-confusion-global"></svg> -->
    </div>
    <div id="subset-detail-tooltip"></div>
  </div>

</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 860px;
  height: 840px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 820px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

.exploration-block {
  position: relative;
  /* width: 850px;
  height: 780px; */
}

.feature-panel {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 14.5%; /* 垂直居中 */
  left: 3%; /* 水平居中 */
  background-color: #fff;
}
.feature-panel-title {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 12%; /* 垂直居中 */
  left: 3%; /* 水平居中 */
  background-color: #fff;
  font-weight: 700;
  font-size: 14px;
}

.cur_stamp-row {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 9%; /* 垂直居中 */
  left: 3%; /* 水平居中 */
  display: flex;
  background-color: #fff;
  font-size: 14px;
}

.cur_stamp-row .title {
  font-weight: 700;
}

.cur_stamp-row .cur_stamp {
  margin-left: 5px;
  color: #1a73e8;
}

.sel-title {
  margin-left: 16px;
  font-size: 14px;
  font-weight: 700;
  font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
  color: #515A6E;
}

.form-check {
  font-size: 14px;
  margin-left: 16px;
  display: flex;
  align-items: center;
}

.form-check-label {
  font-weight: 14px;
  font-weight: 400;
  margin-left: 6px;
  margin-top: 2px;
}

.data-dropdown .dropdown-toggle {
  width: 130px !important;
  height: 24px;
  /* width: 120px; */
  padding: 0px 2px 0 4px;
  /* padding-bottom: -10px; */
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

.li-data-name {
    font-size: 14px;
}

.li-data-description {
    font-size: 12px;
    color: #777;
}

.select-config-row {
  display: flex;
  justify-content: space-around;
  align-items: center;
}

#subset-detail-tooltip {
  position: absolute;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #999;
  border-radius: 5px;
  pointer-events: none;
  opacity: 0;
}

#time-event-bar {
  margin-top: -164px;
}
</style>