<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import $ from 'jquery'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'
import SubsetList from '@/components/SubsetList/index.vue'
import EventsView from '@/components/EventsView/index.vue'

const inforStore = useInforStore()
let global_time_id = ref(0)
let global_time_id_left = ref(0)
let global_time_id_right = ref(0)
let cur_sel_step = ref(0)
let cur_hover_loc_left = ref(-1)
let cur_hover_loc_right = ref(-1)
let cur_hover_loc = ref(-1)
let cur_outer_indicator = ref('elevation')
let cur_inner_indicator = ref('RH')
let view_linked = ref(true)
let view_form_types = ref(['feature', 'error'])
let left_form_type = ref('feature')
let right_form_type = ref('error')
let step_opts = ref(['previous', 'current'])
let sel_step_left = ref('current')
let sel_step_right = ref('current')
let cur_step_left = ref(0)
let cur_step_right = ref(0)

const axis_attrs = ref(['Ground Truth', 'Prediction', 'Residual', 'target_val', 'temporal_state_vals', 'space_diff_state_vals', 'space_comp_state_vals'])
let bin_color_types = ref(['Count', 'Ground Truth', 'Prediction', 'Residual', 'target_val', 'temporal_state_vals', 'space_diff_state_vals', 'space_comp_state_vals'])

let intervalId_phase
let intervalId_subset

let inspect_modes = ['error', 'prediction']
let cur_inspect_mode = ref('prediction')
let pred_infors = ['']
let err_indicators = ['multi_indicators', 'residual', 'binary', 'level']
let cur_err_indicators = ref('multi_indicators')
// let focus_fore_steps = ref([1,1])
let cur_event_start = 0
let cur_sel_event_step = 0

// watch (() => inforStore.cur_data_infor, (oldVlaue, newValue) => {
//   focus_fore_steps.value = [1, inforStore.cur_data_infor.time.output_window]
// })
let cur_temporal_focus_cnt = ref([])
let cur_temporal_focus_locs = ref([])

watch (() => left_form_type.value, (oldVlaue, newValue) => {
  if (left_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_left.value, 'left')
  } else if (left_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_left.value, 'left')
  }
})
watch (() => sel_step_left.value, (oldVlaue, newValue) => {
  if (sel_step_left.value == 'current') {
    global_time_id_left.value = global_time_id.value
    cur_step_left.value = cur_sel_step.value
  }
  if (sel_step_left.value == 'previous') {
    cur_step_left.value = cur_sel_step.value-1
    global_time_id_left.value = global_time_id.value-1
  }
  if (left_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_left.value, 'left')
  } else if (left_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_left.value, 'left')
  }
})
watch (() => right_form_type.value, (oldVlaue, newValue) => {
  if (right_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_right.value, 'right')
  } else if (right_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_right.value, 'right')
  }
})
watch (() => sel_step_right.value, (oldVlaue, newValue) => {
  if (sel_step_right.value == 'current') {
    global_time_id_right.value = global_time_id.value
    cur_step_right.value = cur_sel_step.value
  }
  if (sel_step_right.value == 'previous') {
    global_time_id_right.value = global_time_id.value-1
    cur_step_right.value = cur_sel_step.value-1
  }
  if (right_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_right.value, 'right')
  } else if (right_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_right.value, 'right')
  }
})

watch (() => inforStore.cur_subset_st_indices, (oldVlaue, newValue) => {
  if (inforStore.cur_subset_st_indices.length == 0) {
    // cur_temporal_focus_cnt.value.map(() => 0)
    // cur_temporal_focus_locs.value.map(() => [])
    let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
    let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
    cur_temporal_focus_cnt.value = Array(parseInt(phase_infor.life_span)).fill(0)
    cur_temporal_focus_locs.value = Array(parseInt(phase_infor.life_span)).fill().map(() => [])
  } 
  else {
    let time_cnt = Array(cur_temporal_focus_cnt.value.length).fill(0)
    let time_locs = Array(cur_temporal_focus_locs.value.length).fill().map(() => [])
    for (let i = 0; i < inforStore.cur_subset_st_indices.length; ++i) {
      let cur_time_index = inforStore.cur_subset_st_indices[i][0]
      // if (cur_time_index >= time_locs.length) console.log('cur_time_index', cur_time_index, i);
      time_cnt[cur_time_index] += 1
      time_locs[cur_time_index].push(inforStore.cur_subset_st_indices[i][1])
    }
    cur_temporal_focus_cnt.value = time_cnt
    cur_temporal_focus_locs.value = time_locs
  }
  drawTimeEventBar()
  drawViews()
})

onUpdated(() => {
  // if ((inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)) {
  //   // drawSTLayout_Phase()
  // }
  // else if (inforStore.cur_detail_type == 'subset') drawSubsetDetails(inforStore.sel_subset_details)
})

let pre_phase_id = -1
let global_residuals_range = []
let global_wind_max = 0

function drawViews() {
  if (left_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_left.value, 'left')
  } else if (left_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_left.value, 'left')
  }
  if (right_form_type.value == 'feature') {
    drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_right.value, 'right')
  } else if (right_form_type.value == 'error') {
    drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_right.value, 'right')
  }
}

watch (() => inforStore.sel_phase_details, (oldVlaue, newValue) => {
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  cur_temporal_focus_cnt.value = Array(parseInt(phase_infor.life_span)).fill(0)
  cur_temporal_focus_locs.value = Array(parseInt(phase_infor.life_span)).fill().map(() => [])
  inforStore.cur_detail_type = 'phase'
  if (sel_phase_id != pre_phase_id) {
    cur_sel_step.value = 0
    cur_event_start = 0
    cur_sel_event_step = 0
    pre_phase_id = sel_phase_id
  }
  
  global_time_id.value = parseInt(cur_sel_step.value) + parseInt(phase_infor.start)
  if (sel_step_left.value == 'current') {
    global_time_id_left.value = global_time_id.value
    cur_step_left.value = cur_sel_step.value
  }
  if (sel_step_left.value == 'previous') {
    cur_step_left.value = cur_sel_step.value-1
    global_time_id_left.value = global_time_id.value-1
  }
  if (sel_step_right.value == 'current') {
    global_time_id_right.value = global_time_id.value
    cur_step_right.value = cur_sel_step.value
  }
  if (sel_step_right.value == 'previous') {
    cur_step_right.value = cur_sel_step.value-1
    global_time_id_right.value = global_time_id.value-1
  }

  // 启动轮询，每隔一定时间调用一次轮询函数
  // intervalId_phase = setInterval(askForDrawPhase, 100);
  if (document.getElementById('st-layout-right')){
    let all_features = inforStore.feature_infor.input.split(', ')
    let U_index = all_features.indexOf('U')
    let V_index = all_features.indexOf('V')
    let phase_wind = inforStore.cur_data_infor.raw_data.slice(phase_infor.start, phase_infor.end)
    let global_U = [].concat(...phase_wind.map(arr => [].concat(...arr.map(item => item[U_index]))))
    let global_V = [].concat(...phase_wind.map(arr => [].concat(...arr.map(item => item[V_index]))))
    let loc_U_extent = d3.extent(global_U)
    let loc_V_extent = d3.extent(global_V)
    global_wind_max = Math.max(-loc_U_extent[0], loc_U_extent[1], -loc_V_extent[0], loc_V_extent[1])

    let global_residuals = [].concat(...inforStore.sel_phase_details.st_residuals.map(arr => [].concat(...arr)))
    let tmp_range = d3.extent(global_residuals)
    let global_err_abs_max = (Math.round(d3.max([-tmp_range[0], tmp_range[1]]) * 100) / 100).toFixed(2)
    global_residuals_range = [-global_err_abs_max, global_err_abs_max]

    drawViews()
    drawTimeEventBar()
  }
  // drawLevelConfusionSpace(inforStore.sel_phase_details)
  // console.log(inforStore.sel_phase_details)
})

let other_indicators = ref(['POD/FAR', 'Multi_accuracy'])
let other_focused_indicators = ref([])
watch (() => inforStore.cur_timeline_indicator, (oldVlaue, newValue) => {
  if (inforStore.cur_timeline_indicator == 'Residual_abs') other_indicators.value = ['POD/FAR', 'Multi_accuracy']
  if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') other_indicators.value = ['Multi_accuracy', 'Residual_abs']
  if (inforStore.cur_timeline_indicator == 'Multi_accuracy') other_indicators.value = ['POD/FAR', 'Residual_abs']
  other_focused_indicators.value = []
  drawViews()
  drawTimeEventBar()
})

watch (() => other_focused_indicators.value, (oldVlaue, newValue) => {
  if (left_form_type.value == 'error') drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_left.value, 'left')
  if (right_form_type.value == 'error') drawSTLayout_Phase(inforStore.cur_sel_model, sel_step_right.value, 'right')
})

watch (() => cur_outer_indicator.value, (oldVlaue, newValue) => {
  if (left_form_type.value == 'feature') drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_left.value, 'left')
  if (right_form_type.value == 'feature') drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_right.value, 'right')
})

watch (() => cur_inner_indicator.value, (oldVlaue, newValue) => {
  if (left_form_type.value == 'feature') drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_left.value, 'left')
  if (right_form_type.value == 'feature') drawSTLayout_Feature(inforStore.cur_sel_model, sel_step_right.value, 'right')
})

watch (() => inforStore.sel_subset_details, (oldVlaue, newValue) => {
  inforStore.cur_detail_type = 'subset'
  // intervalId_subset = setInterval(() => askForDrawSubset(inforStore.sel_subset_details), 100);
  if (document.getElementById('join-dist-space'))
    drawSubsetDetails(inforStore.sel_subset_details)
  // console.log(inforStore.sel_subset_details)
})

watch (() => cur_sel_step.value, (oldVlaue, newValue) => {
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  global_time_id.value = parseInt(cur_sel_step.value) + parseInt(phase_infor.start)
  if (sel_step_left.value == 'current') {
    global_time_id_left.value = global_time_id.value
    cur_step_left.value = cur_sel_step.value
  }
  if (sel_step_left.value == 'previous') {
    cur_step_left.value = cur_sel_step.value-1
    global_time_id_left.value = global_time_id.value-1
  }
  if (sel_step_right.value == 'current') {
    global_time_id_right.value = global_time_id.value
    cur_step_right.value = cur_sel_step.value
  }
  if (sel_step_right.value == 'previous') {
    cur_step_right.value = cur_sel_step.value-1
    global_time_id_right.value = global_time_id.value-1
  }
  drawViews()
})
let grid_points, line
watch (() => cur_hover_loc_left.value, (oldVlaue, newValue) => {
  cur_hover_loc.value = cur_hover_loc_left.value
  // 高亮视图中的loc - 用红色边框？
  if (cur_hover_loc_left.value == -1) {
    d3.select('#right-mark-grid').datum([])
    d3.select('#right-mark-grid').attr('d', '')
  } else {
    d3.select('#right-mark-grid')
      .datum(grid_points[cur_hover_loc_left.value])
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", valColorScheme_red[1])
      .attr("stroke-width", 2)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
  }
})
watch (() => cur_hover_loc_right.value, (oldVlaue, newValue) => {
  cur_hover_loc.value = cur_hover_loc_right.value
  // 高亮视图中的loc - 用红色边框？
  if (cur_hover_loc_right.value == -1) {
    d3.select('#left-mark-grid').datum([])
    d3.select('#left-mark-grid').attr('d', '')
  } else {
    d3.select('#left-mark-grid')
      .datum(grid_points[cur_hover_loc_right.value])
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", valColorScheme_red[1])
      .attr("stroke-width", 2)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
  }
})

function getDistance(p1, p2, x_scale, y_scale) {
  let dx = x_scale(p2[0]) - x_scale(p1[0]);
  let dy = y_scale(p2[1]) - y_scale(p1[1]);
  return Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
}

let cur_transform_state = {k: 1, x: 0, y: 0}
let transform_state_left = {k: 1, x: 0, y: 0}
let transform_state_right = {k: 1, x: 0, y: 0}
let zoom_func = d3.zoom()
    .scaleExtent([0.1, 10])
    .on('zoom', handleZoom);
function handleZoom(e) {
  cur_transform_state = e.transform
  transform_state_left = e.transform
  transform_state_right = e.transform
  d3.selectAll('.space-layout-g').attr('transform', cur_transform_state)
}
let zoom_func_left = d3.zoom()
    .scaleExtent([0.1, 10])
    .on('zoom', handleZoom_left);
function handleZoom_left(e) {
  transform_state_left = e.transform
  cur_transform_state = e.transform
  d3.select('#space-layout-g-left').attr('transform', transform_state_left)
}
let zoom_func_right = d3.zoom()
    .scaleExtent([0.1, 10])
    .on('zoom', handleZoom_right);
function handleZoom_right(e) {
  transform_state_right = e.transform;
  cur_transform_state = e.transform
  d3.select('#space-layout-g-right').attr('transform', transform_state_right)
}
watch (() => view_linked.value, (oldVlaue, newValue) => {
  if (view_linked.value) {
    // d3.select('#st-layout-feature').call(zoom_func_left.transform, d3.zoomIdentity)
    // d3.select('#st-layout-phase').call(zoom_func_right.transform, d3.zoomIdentity)
    // console.log(d3.zoomIdentity);
    transform_state_left = {
      k: cur_transform_state.k,
      x: cur_transform_state.x,
      y: cur_transform_state.y
    }
    transform_state_right = {
      k: cur_transform_state.k,
      x: cur_transform_state.x,
      y: cur_transform_state.y
    }
    d3.select('#st-layout-left').call(zoom_func_left.transform, cur_transform_state)
    d3.select('#st-layout-right').call(zoom_func_right.transform, cur_transform_state)
    d3.select('#st-layout-left').call(zoom_func)
    d3.select('#st-layout-right').call(zoom_func)
  } else {
    d3.select('#st-layout-left').call(zoom_func.transform, transform_state_left)
    d3.select('#st-layout-right').call(zoom_func.transform, transform_state_right)
    d3.select('#st-layout-left').call(zoom_func_left)
    d3.select('#st-layout-right').call(zoom_func_right)
  }
})

let cur_phase_time_str_left = ref('')
let cur_phase_time_str_right = ref('')
let space_layout_w = 770, space_layout_h = 770
function drawSTLayout_Feature(model_sel, step_sel, view_sel) {
  let phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_list = inforStore.st_phase_events.phases_list
  let cur_step, cur_global_time_id
  if (step_sel == 'current') {
    cur_step = Number(cur_sel_step.value)
    cur_global_time_id = global_time_id.value
  } else if (step_sel == 'previous') {
    cur_step = Number(cur_sel_step.value) - 1
    cur_global_time_id = global_time_id.value - 1
  } 
  let stamp_id = phase_list[phase_id].start + cur_step
  let stamp_strs = inforStore.st_phase_events.time_strs
  let svg_id
  if (view_sel == 'left') {
    svg_id = '#st-layout-left'
    cur_phase_time_str_left.value = stamp_strs[stamp_id]
  } else if (view_sel == 'right') {
    svg_id = '#st-layout-right'
    cur_phase_time_str_right.value = stamp_strs[stamp_id]
  }
  d3.select(svg_id).selectAll('*').remove()
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let margin_left = 10, margin_right = 10
  let st_layout_w = space_layout_w + margin_left + margin_right
  let st_layout_h = space_layout_h - 5

  let st_layout_svg = d3.select(svg_id)
    .attr('class', 'st-layout-svg')
    .attr('width', st_layout_w)
    .attr('height', st_layout_h)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let grid_borders = inforStore.cur_data_infor.space.grid_borders
  // console.log(grid_borders);
  grid_points = grid_borders.map(item => item['border_points'])
  // let grid_points_end = grid_borders.map(item => item['border_points'].slice(1, 5))
  let grid_points_x = grid_points.map(item => item.map(e => e[0])).flat()
  let grid_points_y = grid_points.map(item => item.map(e => e[1])).flat()
  
  let white_rate = 0.05
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...grid_points_x), Math.max(...grid_points_x)])
        .range([space_layout_w*white_rate, space_layout_w*(1-white_rate)])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...grid_points_y), Math.max(...grid_points_y)])
        .range([space_layout_h*(1-white_rate), space_layout_h*white_rate])
  let cell_len = getDistance(grid_borders[0].border_points[0], grid_borders[0].border_points[1], loc_x_scale, loc_y_scale)
  let space_layout_g = st_layout_svg.append('g')
    .attr('id', 'space-layout-g-left')
    .attr('class', 'space-layout-g')
    // .attr('transform', `translate(${margin_left}, -30)`)
    .attr('transform', () => {
      if (view_linked.value) return cur_transform_state
      else return transform_state_left
    })
  let grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
    .on('mouseover', (e) => {
      let border_path = d3.select(e.target)
      while (border_path.attr('loc_id') == null) {
        border_path = d3.select(border_path.node().parentNode)
      }
      let target_id = parseInt(border_path.attr('loc_id'))
      if (view_sel == 'left') cur_hover_loc_left.value = target_id
      else if (view_sel == 'right') cur_hover_loc_right.value = target_id
      // 显示 tooltips
      d3.select(`#loc-tooltip-${view_sel}`)
        .style("left", () => {
          if (view_sel == 'left') return (e.pageX + 10) + "px"
          if (view_sel == 'right') return (e.pageX-390) + "px"
        })
        .style("top", (e.pageY - 30) + "px")
        .style("opacity", 1)
        // .text(`Value: ${d}`);
    })
    .on('mouseout', (e) => {
      if (view_sel == 'left') cur_hover_loc_left.value = -1
      else if (view_sel == 'right') cur_hover_loc_right.value = -1
      d3.select(`#loc-tooltip-${view_sel}`)
        .style("opacity", 0);
    })
  let pollu_grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
  line = d3.line()
    .x(d => loc_x_scale(d[0])) // x 坐标映射
    .y(d => loc_y_scale(d[1])); // y 坐标映射
  let level_id_list = []
  for (let i = 0; i < inforStore.cur_val_bins.length-1; ++i) {
    level_id_list.push(i)
  }
  
  // 获取features的数据
  let all_features = inforStore.feature_infor.input.split(', ')
  let outer_index = all_features.indexOf(cur_outer_indicator.value)
  let inner_index = all_features.indexOf(cur_inner_indicator.value)
  let loc_outer_data = inforStore.cur_data_infor.raw_data[cur_global_time_id].map(item => item[outer_index])
  let loc_inner_data = inforStore.cur_data_infor.raw_data[cur_global_time_id].map(item => item[inner_index])
  let U_index = all_features.indexOf('U')
  let V_index = all_features.indexOf('V')
  let loc_U = inforStore.cur_data_infor.raw_data[cur_global_time_id].map(item => item[U_index])
  let loc_V = inforStore.cur_data_infor.raw_data[cur_global_time_id].map(item => item[V_index])
  let windScale = d3.scaleLinear()
    .domain([-global_wind_max, global_wind_max])
    .range([-cell_len*0.30, cell_len*0.30])
  let outerColor = d3.scaleQuantize()
    .domain(d3.extent(loc_outer_data))
    .range(['#eff3ff', '#c6dbef', '#9ecae1', '#6baed6', '#3182bd', '#08519c'])
    // .range(['#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#08519c'])

  let innerColor = d3.scaleQuantize()
    .domain(d3.extent(loc_inner_data))
    .range(['#feedde', '#fdd0a2', '#fdae6b', '#fd8d3c', '#e6550d', '#a63603'])
    // .range(['#edf8e9', '#c7e9c0', '#a1d99b', '#74c476', '#31a354', '#006d2c'])

  let borders_g = grid_borders_g.append('g')
  borders_g.selectAll('path')
    .data(grid_points)
    .join('path')
      .attr('class', 'left-loc-border')
      .attr('id', (d,i) => `left_loc-${i}`)
      .attr('loc_id', (d,i) => i)
      .attr("d", line) // 应用生成器
      .attr("fill", (d, i) => outerColor(loc_outer_data[i]))
      .attr("stroke", "#999")
      .attr("stroke-width", 1)
      .attr("opacity", 0.9)
  let pollu_grid_points = grid_points.filter(function(value, index) {
    let cur_val = inforStore.sel_phase_details.phase_raw_val[cur_step][index]
    return (cur_val >= inforStore.phase_params.focus_th)
  })
  pollu_grid_borders_g.selectAll('path')
    .data(pollu_grid_points)
    .join('path')
      .attr('id', (d,i) => `left_pollu_loc-${i}`)
      .attr('loc_id', (d,i) => i)
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", (d,i) => '#000')
      .attr("stroke-width", 2)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
      .attr("opacity", 0.9)
  let mark_grid = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
    .append('path')
      .attr('id', `${view_sel}-mark-grid`)
      .datum([])
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", 'red')
      .attr("stroke-width", 4)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
  let subset_marks_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
  let subset_marks = subset_marks_g.selectAll('circle')
    .data(cur_temporal_focus_locs.value[cur_step])
    .join('circle')
      .attr('transform', (d,i) => `translate(${loc_x_scale(loc_coords_x[d])-cell_len*0.33}, ${loc_y_scale(loc_coords_y[d])-cell_len*0.41}) scale(2)`)
      .attr('cx', 0).attr('cy', 0)
      .attr('r', 2)
      .attr('fill', '#333')
      .attr('stroke', 'none')
  // let s_mark_d = 
  
  // let initialTransform = d3.zoomIdentity;
  // st_layout_svg.call(zoom_func.transform, initialTransform);
  if (view_linked.value) st_layout_svg.call(zoom_func)
  else st_layout_svg.call(zoom_func_left)
  // let transformState = d3.zoomIdentity;
  if (inforStore.sel_phase_details.phase_pred_val[cur_step][0].length == 0) return
  let glyphs_g = grid_borders_g.append('g')
    // .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
  for (let i = 0; i < loc_outer_data.length; ++i) {
    let single_glyphs_g = glyphs_g.append('g')
    let single_glyph = single_glyphs_g.append('g')
      .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
      .attr('loc_id', i)
    // 计算风速的大小和角度（注意：计算中U表示纬向风速，V表示经向风速）
    let windSpeed = Math.sqrt(loc_U[i] * loc_U[i] + loc_V[i] * loc_V[i]); // 风速大小
    let windAngle = Math.atan2(-loc_U[i], loc_V[i]) * (180 / Math.PI); // 风向角度
    // let arrowPath = "M0,-5L10,0L0,5Z"; // 箭头的形状
    // let arrowPath = "M0,-4L8,0L0,4Z"; // 箭头的形状
    // let arrowPath = "M0,-3L6,0L0,3L2,0Z"; // 箭头的形状
    let arrowPath = "M0,-4L8,0L0,4L3,0Z"; // 箭头的形状
    let arrow_g = single_glyph.append('g')
    arrow_g.append('circle')
      .attr('x', 0).attr('y', 0)
      .attr('r', cell_len*0.32).attr('fill', '#333')
      .attr('fill', '#fff')
      // .attr('fill', innerColor(loc_inner_data[i]))
      .attr('stroke', innerColor(loc_inner_data[i]))
      .attr('stroke-width', 5)
    arrow_g.append('circle')
      .attr('x', 0).attr('y', 0)
      .attr('r', 2)
      .attr('fill', '#333')
      // .attr('fill', innerColor(loc_inner_data[i]))
    arrow_g.append('line')
      .attr('x1', 0).attr('y1', 0)
      .attr('x2', windScale(loc_V[i])).attr('y2', -windScale(loc_U[i]))
      // .attr('stroke', innerColor(loc_inner_data[i]))
      .attr('stroke', '#333')
    arrow_g.append("path")
      .attr("d", arrowPath)
      .attr("transform", `translate(${windScale(loc_V[i])},${-windScale(loc_U[i])}) rotate(${windAngle}) translate(-4,0)`)
      // .attr("transform", `rotate(${windAngle}) scale(1.5) translate(-3,0)`)
      .style("fill", "#333")
      // .attr('fill', innerColor(loc_inner_data[i]))
  }

  let resi_legend_len = 120
  let resiLegendScale = d3.scaleSequential(d3.interpolateRdBu)
  // let resiLegendScale = d3.scaleSequential(d3.interpolateBrBG)
    .domain([0, resi_legend_len])
  let residual_legend = st_layout_svg.append('g')
    .attr('transform', 'translate(60, 20)')
  residual_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => resiLegendScale(i))
  residual_legend.append('text')
    .attr('x', resi_legend_len * 0.5)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Residual Colormap')
  residual_legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    // .text(`${local_err_range[0]}`)
    .text(`${global_residuals_range[0]}`)
  residual_legend.append('text')
    .attr('x', resi_legend_len+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    // .text(`${local_err_range[1]}`)
    .text(`${global_residuals_range[1]}`)
}

function drawSTLayout_Phase(model_sel, step_sel, view_sel) {
  let phase_id = inforStore.sel_phase_details.sel_phase_id
  let phase_list = inforStore.st_phase_events.phases_list
  let cur_step
  if (step_sel == 'current') cur_step = Number(cur_sel_step.value)
  if (step_sel == 'previous') cur_step = Number(cur_sel_step.value)-1
  let stamp_id = phase_list[phase_id].start + cur_step
  let stamp_strs = inforStore.st_phase_events.time_strs
  let svg_id
  if (view_sel == 'left') {
    svg_id = '#st-layout-left'
    cur_phase_time_str_left.value = stamp_strs[stamp_id]
  } else if (view_sel == 'right') {
    svg_id = '#st-layout-right'
    cur_phase_time_str_right.value = stamp_strs[stamp_id]
  }
  d3.select(svg_id).selectAll('*').remove()
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let margin_left = 10, margin_right = 10
  let st_layout_w = space_layout_w + margin_left + margin_right
  let st_layout_h = space_layout_h - 5

  let st_layout_svg = d3.select(svg_id)
    .attr('class', 'st-layout-svg')
    .attr('width', st_layout_w)
    .attr('height', st_layout_h)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let grid_borders = inforStore.cur_data_infor.space.grid_borders
  // console.log(grid_borders);
  grid_points = grid_borders.map(item => item['border_points'])
  // let grid_points_end = grid_borders.map(item => item['border_points'].slice(1, 5))
  let grid_points_x = grid_points.map(item => item.map(e => e[0])).flat()
  let grid_points_y = grid_points.map(item => item.map(e => e[1])).flat()
  
  let white_rate = 0.05
  let points_x_extent = d3.extent(grid_points_x)
  let points_y_extent = d3.extent(grid_points_y)
  let loc_x_scale = d3.scaleLinear()
        .domain(points_x_extent)
        .range([space_layout_w*white_rate, space_layout_w*(1-white_rate)])
  let loc_y_scale = d3.scaleLinear()
        .domain(points_y_extent)
        .range([space_layout_h*(1-white_rate), space_layout_h*white_rate])
  let space_layout_g = st_layout_svg.append('g')
    .attr('id', 'space-layout-g-right')
    .attr('class', 'space-layout-g')
    // .attr('transform', `translate(${margin_left}, -30)`)
    .attr('transform', () => {
      if (view_linked.value) return cur_transform_state
      else return transform_state_right
    })
  // let points_x_range = points_x_extent[1] - points_x_extent[0]
  // let points_y_range = points_y_extent[1] - points_y_extent[0]
  let grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
    .on('click', (e) => {
      inforStore.ins_inspect_type = 'phase'
      $('.overlay-container').css('display', 'flex')
      let border_path = d3.select(e.target)
      while (border_path.attr('loc_id') == null) {
        border_path = d3.select(border_path.node().parentNode)
      }
      let target_id = parseInt(border_path.attr('loc_id'))
      inforStore.cur_sel_condition.loc_id = target_id
      let tmp_stamp_obj = {}
      tmp_stamp_obj[String(stamp_id)] = {}
      tmp_stamp_obj[String(stamp_id)]['stamp_id'] = stamp_id
      tmp_stamp_obj[String(stamp_id)]['timestamp'] = stamp_strs[stamp_id]
      tmp_stamp_obj[String(stamp_id)]['fore_step'] = Array.from({ length: binary_labels[i].length }, (_, index) => index)
      tmp_stamp_obj[String(stamp_id)]['binary_label'] = binary_labels[target_id]
      tmp_stamp_obj[String(stamp_id)]['multi_label'] = multi_labels[target_id]
      tmp_stamp_obj[String(stamp_id)]['residual'] = residuals[target_id]
      inforStore.tile_resi_edge_range = local_err_range
      inforStore.cur_sel_stamp_objs_single = tmp_stamp_obj
      getData(inforStore, 'instance_seqs', stamp_id, target_id, inforStore.cur_focused_scope)
    })
    .on('mouseover', (e) => {
      let border_path = d3.select(e.target)
      while (border_path.attr('loc_id') == null) {
        border_path = d3.select(border_path.node().parentNode)
      }
      let target_id = parseInt(border_path.attr('loc_id'))
      if (view_sel == 'left') cur_hover_loc_left.value = target_id
      else if (view_sel == 'right') cur_hover_loc_right.value = target_id
      // 显示 tooltips
      d3.select(`#loc-tooltip-${view_sel}`)
        .style("left", () => {
            if (view_sel == 'left') return (e.pageX + 10) + "px"
            if (view_sel == 'right') return (e.pageX-390) + "px"
          })
        .style("top", (e.pageY - 30) + "px")
        .style("opacity", 1)
        // .text(`Value: ${d}`);
    })
    .on('mouseout', (e) => {
      if (view_sel == 'left') cur_hover_loc_left.value = -1
      else if (view_sel == 'right') cur_hover_loc_right.value = -1
      d3.select(`#loc-tooltip-${view_sel}`)
        .style("opacity", 0);
    })
  
  let pollu_grid_borders_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)

  line = d3.line()
    .x(d => loc_x_scale(d[0])) // x 坐标映射
    .y(d => loc_y_scale(d[1])); // y 坐标映射
  let level_id_list = []
  for (let i = 0; i < inforStore.cur_val_bins.length-1; ++i) {
    level_id_list.push(i)
  }
  let boxColorLevel = d3.scaleOrdinal()
    .domain(level_id_list)
    .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])
  let boxColorPOD = d3.scaleOrdinal()
    .domain([-2, -1, 1, 2])
    .range([valColorScheme_blue[3], '#cecece', '#333', valColorScheme_fire[3]])
  let boxColorFAR = d3.scaleOrdinal()
    .domain([-1, 0, 1])
    .range([valColorScheme_blue[3], '#cecece', valColorScheme_fire[3]])
  let borders_g = grid_borders_g.append('g')
  borders_g.selectAll('path')
    .data(grid_points)
    .join('path')
      .attr('class', 'right-loc-border')
      .attr('id', (d,i) => `right_loc-${i}`)
      .attr('loc_id', (d,i) => i)
      .attr("d", line) // 应用生成器
      .attr("fill", (d, i) => boxColorLevel(inforStore.sel_phase_details.phase_raw_level[cur_step][i]))
      .attr("stroke", "#999")
      .attr("stroke-width", 1)
      .attr("opacity", 0.9)
  let pollu_grid_points = grid_points.filter(function(value, index) {
    // let cur_level = inforStore.sel_phase_details.phase_raw_level[cur_step][index]
    // let cur_th = inforStore.cur_val_bins[cur_level]
    let cur_val = inforStore.sel_phase_details.phase_raw_val[cur_step][index]
    return (cur_val >= inforStore.phase_params.focus_th)
  })
  pollu_grid_borders_g.selectAll('path')
    .data(pollu_grid_points)
    .join('path')
      .attr('id', (d,i) => `right_pollu_loc-${i}`)
      .attr('loc_id', (d,i) => i)
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", (d,i) => '#000')
      .attr("stroke-width", 2)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
      .attr("opacity", 0.9)
  let mark_grid = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
    .append('path')
      .attr('id', `${view_sel}-mark-grid`)
      .datum([])
      .attr("d", line) // 应用生成器
      .attr("fill", 'none')
      .attr("stroke", 'red')
      .attr("stroke-width", 4)
      .style("stroke-linejoin", "round")
      .style("stroke-linecap", "round")
  let cell_len = getDistance(grid_borders[0].border_points[0], grid_borders[0].border_points[1], loc_x_scale, loc_y_scale)
  let subset_marks_g = space_layout_g.append('g')
    .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
  let subset_marks = subset_marks_g.selectAll('circle')
    .data(cur_temporal_focus_locs.value[cur_step])
    .join('circle')
      .attr('transform', (d,i) => `translate(${loc_x_scale(loc_coords_x[d])-cell_len*0.33}, ${loc_y_scale(loc_coords_y[d])-cell_len*0.41})`)
      .attr('cx', 0).attr('cy', 0)
      .attr('r', 4)
      .attr('fill', valColorScheme_red[1])
      .attr('stroke', 'none')

  if (view_linked.value) st_layout_svg.call(zoom_func)
  else st_layout_svg.call(zoom_func_left)
  // let transformState = d3.zoomIdentity;
  if (inforStore.sel_phase_details.phase_pred_val[cur_step][0].length == 0) return
  let glyphs_g = grid_borders_g.append('g')
    // .attr('transform', `translate(${margin_left+space_layout_w*0.08}, 4) scale(0.85)`)
  let binary_labels = inforStore.sel_phase_details.st_binary_label[cur_step]
  let multi_labels = inforStore.sel_phase_details.st_multi_label[cur_step]
  let residuals = inforStore.sel_phase_details.st_residuals[cur_step]
  let binary_pred = inforStore.sel_phase_details.phase_pred_flag[cur_step]
  let level_pred = inforStore.sel_phase_details.phase_pred_level[cur_step]
  let val_pred = inforStore.sel_phase_details.phase_pred_val[cur_step]

  let cur_focus_indicator
  if (inforStore.cur_timeline_indicator == 'Residual_abs') {
    cur_focus_indicator = residuals
  } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
    cur_focus_indicator = binary_pred
  } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
    cur_focus_indicator = multi_labels
  }
  
  let pie = d3.pie();
  pie.sort(null);
  let forecast_step_num = residuals[0].length
  let arcData = pie(Array(forecast_step_num).fill(1))
  let local_err_max = d3.max(residuals.map(item => d3.max(item)))
  let local_err_min = d3.min(residuals.map(item => d3.min(item)))
  let local_err_abs_max = d3.max([-local_err_min, local_err_max])
  let local_err_range = [-local_err_abs_max.toFixed(2), local_err_abs_max.toFixed(2)]
  // console.log(local_err_range);
  let residualsColorScale = d3.scaleSequential(d3.interpolateRdBu)
  // let residualsColorScale = d3.scaleSequential(d3.interpolateBrBG)
    .domain(global_residuals_range)
    // .domain(local_err_range)
  if (other_focused_indicators.value.length == 0) {
    let singleIndicatorArc = d3.arc()
      .innerRadius(0)
      .outerRadius(20)
    for (let i = 0; i < residuals.length; ++i) {
      let single_glyphs_g = glyphs_g.append('g')
      let single_ring = single_glyphs_g.append('g')
        .attr('class', '.binary-pred-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', singleIndicatorArc)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        single_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        single_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#cecece'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        single_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }

  if (other_focused_indicators.value.length == 1) {
    let other_indicator
    if (other_focused_indicators.value[0] == 'POD/FAR') other_indicator = binary_pred
    if (other_focused_indicators.value[0] == 'Multi_accuracy') other_indicator = multi_labels
    if (other_focused_indicators.value[0] == 'Residual_abs') other_indicator = residuals
    
    let doubleIndicatorArc_1 = d3.arc()
      .innerRadius(0)
      .outerRadius(12)
    let doubleIndicatorArc_2 = d3.arc()
      .innerRadius(16)
      .outerRadius(24)
    for (let i = 0; i < residuals.length; ++i) {
      let glyphs_1_g = glyphs_g.append('g')
      let glyphs_1_ring = glyphs_1_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_1)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        glyphs_1_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#cecece'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_2_g = glyphs_g.append('g')
      let glyphs_2_ring = glyphs_2_g.append('g')
        .attr('class', '.glyphs-2-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_2)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[0] == 'Residual_abs') {
        glyphs_2_ring.attr('fill', (d,j) => residualsColorScale(other_indicator[i][j]))
      } else if (other_focused_indicators.value[0] == 'POD/FAR') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator[i][j] == 1) return '#333'
          else if (other_indicator[i][j] == 0) return '#cecece'
        })
      } else if (other_focused_indicators.value[0] == 'Multi_accuracy') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator[i][j] == 0) return '#cecece'
          else if (other_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }

  if (other_focused_indicators.value.length == 2) {
    let other_indicator_1, other_indicator_2
    if (other_focused_indicators.value[0] == 'POD/FAR') other_indicator_1 = binary_pred
    if (other_focused_indicators.value[0] == 'Multi_accuracy') other_indicator_1 = multi_labels
    if (other_focused_indicators.value[0] == 'Residual_abs') other_indicator_1 = residuals
    if (other_focused_indicators.value[1] == 'POD/FAR') other_indicator_2 = binary_pred
    if (other_focused_indicators.value[1] == 'Multi_accuracy') other_indicator_2 = multi_labels
    if (other_focused_indicators.value[1] == 'Residual_abs') other_indicator_2 = residuals
    
    let doubleIndicatorArc_1 = d3.arc()
      .innerRadius(0)
      .outerRadius(8)
    let doubleIndicatorArc_2 = d3.arc()
      .innerRadius(10)
      .outerRadius(16)
    let doubleIndicatorArc_3 = d3.arc()
      .innerRadius(18)
      .outerRadius(24)
    
    for (let i = 0; i < residuals.length; ++i) {
      let glyphs_1_g = glyphs_g.append('g')
      let glyphs_1_ring = glyphs_1_g.append('g')
        .attr('class', '.glyphs-1-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_1)
            .attr('stroke', '#999')
      if (inforStore.cur_timeline_indicator == 'Residual_abs') {
        glyphs_1_ring.attr('fill', (d,j) => residualsColorScale(cur_focus_indicator[i][j]))
      } else if (inforStore.cur_timeline_indicator == 'POD' || inforStore.cur_timeline_indicator == 'FAR') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 1) return '#333'
          else if (cur_focus_indicator[i][j] == 0) return '#cecece'
        })
      } else if (inforStore.cur_timeline_indicator == 'Multi_accuracy') {
        glyphs_1_ring.attr('fill', (d,j) => {
          if (cur_focus_indicator[i][j] == 0) return '#cecece'
          else if (cur_focus_indicator[i][j] == 1) return valColorScheme_fire[3]
          else if (cur_focus_indicator[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_2_g = glyphs_g.append('g')
      let glyphs_2_ring = glyphs_2_g.append('g')
        .attr('class', '.glyphs-3-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_2)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[0] == 'Residual_abs') {
        glyphs_2_ring.attr('fill', (d,j) => residualsColorScale(other_indicator_1[i][j]))
      } else if (other_focused_indicators.value[0] == 'POD/FAR') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator_1[i][j] == 1) return '#333'
          else if (other_indicator_1[i][j] == 0) return '#cecece'
        })
      } else if (other_focused_indicators.value[0] == 'Multi_accuracy') {
        glyphs_2_ring.attr('fill', (d,j) => {
          if (other_indicator_1[i][j] == 0) return '#cecece'
          else if (other_indicator_1[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator_1[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
      let glyphs_3_g = glyphs_g.append('g')
      let glyphs_3_ring = glyphs_3_g.append('g')
        .attr('class', '.glyphs-3-ring')
        .attr('loc_id', i)
        .attr('transform', `translate(${loc_x_scale(loc_coords_x[i])}, ${loc_y_scale(loc_coords_y[i])})`)
          .selectAll('path')
          .data(arcData)
          .join("path")
            .attr('d', doubleIndicatorArc_3)
            .attr('stroke', '#999')
      if (other_focused_indicators.value[1] == 'Residual_abs') {
        glyphs_3_ring.attr('fill', (d,j) => residualsColorScale(other_indicator_2[i][j]))
      } else if (other_focused_indicators.value[1] == 'POD/FAR') {
        glyphs_3_ring.attr('fill', (d,j) => {
          if (other_indicator_2[i][j] == 1) return '#333'
          else if (other_indicator_2[i][j] == 0) return '#cecece'
        })
      } else if (other_focused_indicators.value[1] == 'Multi_accuracy') {
        glyphs_3_ring.attr('fill', (d,j) => {
          if (other_indicator_2[i][j] == 0) return '#cecece'
          else if (other_indicator_2[i][j] == 1) return valColorScheme_fire[3]
          else if (other_indicator_2[i][j] == -1) return valColorScheme_blue[3]
          else return '#cecece'
        })
      }
    }
  }

  let resi_legend_len = 120
  let legend_y_shift = 20, legend_x_shift_1 = 60, legend_x_shift_2 = 60
  let cur_x_shift = 60
  if (inforStore.cur_timeline_indicator.includes('Residual_abs') || other_focused_indicators.value.includes('Residual_abs')) {
    let resiLegendScale = d3.scaleSequential(d3.interpolateRdBu)
      .domain([0, resi_legend_len])
    let residual_legend = st_layout_svg.append('g')
      .attr('transform', `translate(${cur_x_shift}, ${legend_y_shift})`)
    residual_legend.selectAll('rect')
      .data(Array(resi_legend_len).fill(1))
      .join('rect')
        .attr('x', (d,i) => i)
        .attr('y', 0)
        .attr('width', 1)
        .attr('height', 12)
        .attr('fill', (d,i) => resiLegendScale(i))
    residual_legend.append('text')
      .attr('x', resi_legend_len * 0.5)
      .attr('y', -8)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Residual Colormap')
    residual_legend.append('text')
      .attr('x', -4)
      .attr('y', 11)
      .attr('text-anchor', 'end')
      .style('font-size', '12px')
      .attr('fill', '#333')
      // .text(`${local_err_range[0]}`)
      .text(`${global_residuals_range[0]}`)
    residual_legend.append('text')
      .attr('x', resi_legend_len+4)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      // .text(`${local_err_range[1]}`)
      .text(`${global_residuals_range[1]}`)
    cur_x_shift += resi_legend_len+85
  }
  if (inforStore.cur_timeline_indicator.includes('POD/FAR') || other_focused_indicators.value.includes('POD/FAR')) {
    let binary_label_legend = st_layout_svg.append('g')
      .attr('transform', `translate(${cur_x_shift}, ${legend_y_shift})`)
    let label_block_w = 60, box_w = 12
    binary_label_legend.append('text')
      .attr('x', 134)
      .attr('y', -8)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Dichotomous Label')
    binary_label_legend.append('rect')
      .attr('x', box_w+30).attr('y', 0)
      .attr('width', box_w)
      .attr('height', box_w)
      .attr('fill', '#333') // neg correct
    binary_label_legend.append('text')
      .attr('x', box_w*2 + 33)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Forecast Yes')
    binary_label_legend.append('rect')
      .attr('x', box_w*2+123).attr('y', 0)
      .attr('width', box_w)
      .attr('height', box_w)
      .attr('fill', '#cecece') // false alarm
    binary_label_legend.append('text')
      .attr('x', box_w*3 + 126)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Forecast No')
    cur_x_shift += 300
  }
  if (inforStore.cur_timeline_indicator.includes('Multi_accuracy') || other_focused_indicators.value.includes('Multi_accuracy')) {
    let multi_label_legend = st_layout_svg.append('g')
      .attr('transform', `translate(${cur_x_shift}, ${legend_y_shift})`)
    let label_block_w = 60, box_w = 12
    multi_label_legend.append('text')
      .attr('x', 90)
      .attr('y', -8)
      .attr('text-anchor', 'middle')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Multi-category Label')
    multi_label_legend.append('rect')
      .attr('x', 0).attr('y', 0)
      .attr('width', box_w)
      .attr('height', box_w)
      .attr('fill', '#cecece')
    multi_label_legend.append('text')
      .attr('x', box_w + 3)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Accurate')  // 估计准确 
    multi_label_legend.append('rect')
      .attr('x', box_w + 62).attr('y', 0)
      .attr('width', box_w)
      .attr('height', box_w)
      .attr('fill', valColorScheme_fire[3])
    multi_label_legend.append('text')
      .attr('x', box_w*2 + 65)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Higher')
    multi_label_legend.append('rect')
      .attr('x', box_w*2 + 110).attr('y', 0)
      .attr('width', box_w)
      .attr('height', box_w)
      .attr('fill', valColorScheme_blue[3])
    multi_label_legend.append('text')
      .attr('x', box_w*3 + 113)
      .attr('y', 11)
      .attr('text-anchor', 'start')
      .style('font-size', '12px')
      .attr('fill', '#333')
      .text('Lower')
  }
}

function drawTimeEventBar() {
  d3.select('#time-event-bar').selectAll('*').remove()
  let sel_phase_id = inforStore.sel_phase_details.sel_phase_id
  let space_layout_w = 1530, space_layout_h = 180, time_bar_h = 10
  let margin_left = 50, margin_right = 10
  let st_layout_w = space_layout_w + margin_left + margin_right
  let st_layout_h = space_layout_h + time_bar_h*3 - 20
  let st_layout_svg = d3.select('#time-event-bar')
    .attr('width', st_layout_w)
    .attr('height', st_layout_h)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let white_rate = 0.06
  let phase_len = inforStore.st_phase_events.phases_list[sel_phase_id].end - inforStore.st_phase_events.phases_list[sel_phase_id].start
  let step_width = (space_layout_w-20) / phase_len
  
  // 绘制事件bar，略缩图
  let events_scope = 20
  let cell_w = 70, cell_h = 70
  let evevt_bar_y_shift = 136
  if (loc_coords_x.length > 100) {
    events_scope = 9
    cell_w = 80
    cell_h = 80
    evevt_bar_y_shift += 10
  }
  let cur_event_end = cur_event_start + events_scope
  
  let events_bar_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-evevt_bar_y_shift})`)
  let cell_x_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_x), Math.max(...loc_coords_x)])
        .range([cell_w*(white_rate), cell_w*(1-white_rate)])
  let cell_y_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_y), Math.max(...loc_coords_y)])
        .range([cell_h*(1-white_rate), cell_h*white_rate])
  let cellValColor = d3.scaleOrdinal()
    .domain(d3.range(inforStore.cur_val_bins.length))
    .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])

  // console.log('len', inforStore.cur_phase_data.phase_raw_data.length, inforStore.sel_phase_details.phase_raw_level.length)
  let phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
  let phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
  let phase_raw_infor = []
  for (let i = 0; i < phase_raw_data.length; i++) {
    phase_raw_infor.push([])
    for (let j = 0; j < phase_raw_data[i].length; ++j) {
      phase_raw_infor[i].push({
        'val': phase_raw_data[i][j],
        'level': phase_raw_level[i][j]
      })
    }
  }
  let data_cells = events_bar_g.selectAll('g')
    .data(phase_raw_infor)
    .join('g')
      .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
      .style('cursor', 'pointer')
      .on('click', (e,d) => {
        cur_sel_event_step = d3.select(e.target).attr('cur_event_step')
        cur_sel_step.value = cur_event_start + parseInt(cur_sel_event_step)
        data_cells.selectAll('rect').attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        event_header_g.select('rect')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.select('text')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
        d3.select('#cur_step_mark').attr('x', cur_sel_event_step*step_width)
      })
  let cell_header_h = 14
  let cur_phase_id = inforStore.cur_phase_sorted_id
  let phase_events = inforStore.st_phase_events.phases_list[cur_phase_id].evolution_events

  let cur_events = []
  for (let i = 0; i < events_scope; ++i) {
    cur_events.push([])
    for (let j = 0; j < phase_events.length; ++j) {
      if (phase_events[j].step_id == i+cur_event_start) {
        cur_events[i].push(phase_events[j])
      }
      // if (phase_events[j].step_id > i+cur_event_start) break
    }
  }
  // 建立事件header
  let events_headers_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-evevt_bar_y_shift})`)
  let event_headers_g = events_headers_g.selectAll('g')
    .data(cur_events)
    .join('g')
      .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
      .attr('event-step', (d,i) => i)
  let event_header_g = event_headers_g.selectAll('g')
    .data(d => d)
    .join('g')
      .attr('id', (d,i) => `cur-event-${i}`)
      .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
  event_header_g.append('rect')
    .attr('x', -0.5).attr('y', 0)
    .attr('width', cell_w+1).attr('height', cell_header_h)
    .attr('fill', (d,i) => {
      if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
      else return '#cecece'
    })
  event_header_g.append('text')
    .attr('x', cell_w/2).attr('y', 10)
    .attr('text-anchor', 'middle')
    .style('font-size', '9px')
    .attr('fill', (d,i) => {
      if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
      else return '#333'
    })
    .text((d,i) => d.area_event.type)

  data_cells.append('rect')
    .attr('id', (d,i) => `data-cell-${i}`)
    .attr('cur_event_step', (d,i) => i)
    .attr('x', 0).attr('y', 0)
    .attr('width', cell_w).attr('height', cell_h)
    .attr('fill', '#fff')
    .attr('stroke', (d,i) => {
      if (i == cur_sel_event_step) return '#333'
      else return '#bababa'
    })
  data_cells.selectAll('circle')
    .data(d => d)
    .join('circle')
      .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
      .attr('loc_id', (d,i) => i)
      .attr('r', 2)
      .attr('fill', (d,i) => cellValColor(d.level))
      .attr('stroke', (d,i) => {
        if (d.val >= inforStore.phase_params.focus_th) return '#333'
        else return 'none'
      })
  
  let time_bar_g = st_layout_svg.append('g')
    .attr('transform', `translate(${margin_left+30}, ${space_layout_h-58})`)
  let time_axis_bar = time_bar_g.append('g')
  let temporal_ids = []
  for (let i = 0; i < phase_len; i++) {
    temporal_ids.push(i);
  }
  let temporal_err_scale = d3.scaleQuantize()
    .domain([0, inforStore.sel_phase_details.temporal_residuals_abs_max])
    .range(valColorScheme_fire)
  // let temporal_err_scale = d3.scaleLinear()
  // let temporal_err_scale = d3.scaleSequential(d3.interpolateGreens)
  //   .domain([0, inforStore.sel_phase_details.temporal_residuals_abs_max])
    // .range(['#eee', '#000'])
    // .range(valColorScheme_fire)
  let temporal_rate_scale = d3.scaleQuantize()
    .domain([0, 1])
    .range(valColorScheme_fire)
  // let temporal_rate_scale = d3.scaleLinear()
  // let temporal_rate_scale = d3.scaleSequential(d3.interpolateGreens)
  //   .domain([0, 1])
    // .range(['#eee', '#000'])
    // .range(valColorScheme_fire)
  // let time_x_scale = d3.scaleLinear()
  //   .domain(temporal_ids)
  //   .range([0, space_layout_w])
  let phase_infor = inforStore.st_phase_events.phases_list[sel_phase_id]
  let scope_size = inforStore.cur_focused_scope[1] - inforStore.cur_focused_scope[0] + 1
  let focusColormap = d3.scaleSequential(d3.interpolateGreys)
    .domain([0, d3.max(cur_temporal_focus_cnt.value) / (loc_coords_x.length * scope_size)])
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 8)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text('Focus_cnt')
  time_axis_bar.append('g').attr('id', 'focus-time-axis')
    .selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `focus_unit-${d}`)
      .attr('x', d => d * step_width)
      .attr('y', 0)
      .attr('width', step_width)
      .attr('height', time_bar_h)
      .attr('fill', d => {
        // console.log(cur_temporal_focus_cnt.value[d], loc_coords_x.length * scope_size);
        if (cur_temporal_focus_cnt.value[d] == 0) return '#fff'
        else return focusColormap(cur_temporal_focus_cnt.value[d] / (loc_coords_x.length * scope_size))
      })
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        // console.log(inforStore.sel_phase_details.time_pod[target_id], inforStore.sel_phase_details.time_far[target_id]);
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        d3.select('#cur_step_mark').attr('x', cur_sel_event_step*step_width)
        phase_raw_infor = []
        // if (inforStore.sel_phase_details.phase_raw_level)
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.select('#start-slider')
          .attr('transform', `translate(${cur_event_start * step_width}, ${time_bar_h*4+3})`)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id
        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })

  // let cntColormap = d3.scaleLinear()
  //   .domain([0, 1])
  //   .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length - 1]])
  let cntLenMap = d3.scaleLinear()
    .domain([0, 1])
    .range([time_bar_h*2, 0])
    // .range(['#eee', '#000'])
  // let valColor = d3.scaleQuantile()
  //   .domain([0, 500])
  //   .range(['#fcfbfd', '#efedf5', '#dadaeb', '#bcbddc', '#9e9ac8', '#807dba', '#6a51a3', '#4a1486'])
  let valColor = d3.scaleLinear()
    // .domain([inforStore.phase_params.focus_th, 500])
    .domain([0, 500])
    .range(['#fff', '#4a1486'])
    // .range(['#efedf5', '#4a1486'])
    // .range(['#eee', '#000'])
  // let valColor = d3.scaleSequential(d3.interpolateBlues)
  //   .domain([0, 500])
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 24)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text('Pollution')
  time_axis_bar.append('g').selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `cnt_unit-${d}`)
      .attr('x', d => d * step_width)
      // .attr('y', d => time_bar_h + cntLenMap(phase_infor.time_pollution_cnt_all[d]) + 1)
      .attr('y', d => time_bar_h + cntLenMap(phase_infor.time_pollution_cnt_all[d])/2 + 1)
      .attr('width', step_width)
      .attr('height', d => time_bar_h*2-cntLenMap(phase_infor.time_pollution_cnt_all[d]))
      .attr('fill', d => {
        // if (phase_infor.time_pollution_cnt_all[d] == 0) return '#fff'
        // else return cntColormap(phase_infor.time_pollution_cnt_all[d])
        return valColor(phase_infor.time_pollution_event_val[d])
      })
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        // console.log(inforStore.sel_phase_details.time_pod[target_id], inforStore.sel_phase_details.time_far[target_id]);
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        d3.select('#cur_step_mark').attr('x', cur_sel_event_step*step_width)
        phase_raw_infor = []
        // if (inforStore.sel_phase_details.phase_raw_level)
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.select('#start-slider')
          .attr('transform', `translate(${cur_event_start * step_width}, ${time_bar_h*4+3})`)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id
        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })
  // time_axis_bar.append('text')
  //   .attr('x', -4)
  //   .attr('y', 30)
  //   .attr('text-anchor', 'end')
  //   .style('font-size', '11px')
  //   .attr('fill', '#333')
  //   .text('Pollution_val')
  // time_axis_bar.append('g').selectAll('rect')
  //   .data(temporal_ids)
  //   .join('rect')
  //     .attr('id', d => `val_unit-${d}`)
  //     .attr('x', d => d * step_width)
  //     .attr('y', time_bar_h*2)
  //     .attr('width', step_width)
  //     .attr('height', time_bar_h)
  //     .attr('fill', d => valColor(phase_infor.time_pollution_event_val[d]))
  //     .attr('stroke', '#999')
  //     .on('click', (e) => {
  //       let target_id = d3.select(e.target).attr('id').split('-')[1]
  //       cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
  //       cur_event_end = cur_event_start + events_scope
  //       cur_sel_event_step = target_id - cur_event_start
  //       d3.select('#cur_step_mark').attr('x', cur_sel_event_step*step_width)
  //       phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
  //       phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
  //       phase_raw_infor = []
  //       for (let i = 0; i < phase_raw_data.length; i++) {
  //         phase_raw_infor.push([])
  //         for (let j = 0; j < phase_raw_data[i].length; ++j) {
  //           phase_raw_infor[i].push({
  //             'val': phase_raw_data[i][j],
  //             'level': phase_raw_level[i][j]
  //           })
  //         }
  //       }
  //       time_bar_g.select('#start-slider')
  //         .attr('transform', `translate(${cur_event_start * step_width}, ${time_bar_h*4})`)
  //       data_cells = events_bar_g.selectAll('g')
  //         .data(phase_raw_infor)
  //         .join('g')
  //       data_cells.selectAll('circle')
  //         .data(d => d)
  //         .join('circle')
  //           .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
  //           .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
  //           .attr('loc_id', (d,i) => i)
  //           .attr('r', 2)
  //           .attr('fill', (d,i) => cellValColor(d.level))
  //           .attr('stroke', (d,i) => {
  //             if (d.val >= inforStore.phase_params.focus_th) return '#333'
  //             else return 'none'
  //           })
  //       data_cells.selectAll('rect')
  //         .attr('stroke', '#bababa')
  //       data_cells.select(`#data-cell-${cur_sel_event_step}`)
  //         .attr('stroke', '#333')
  //       cur_sel_step.value = target_id

  //       cur_events = []
  //       for (let i = 0; i < events_scope; ++i) {
  //         cur_events.push([])
  //         for (let j = 0; j < phase_events.length; ++j) {
  //           if (phase_events[j].step_id == i+cur_event_start) {
  //             cur_events[i].push(phase_events[j])
  //           }
  //           // if (phase_events[j].step_id > i+cur_event_start) break
  //         }
  //       }
  //       events_headers_g.selectAll('*').remove()
  //       event_headers_g = events_headers_g.selectAll('g')
  //         .data(cur_events)
  //         .join('g')
  //           .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
  //       event_header_g = event_headers_g.selectAll('g')
  //         .data(d => d)
  //         .join('g')
  //           .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
  //       event_header_g.append('rect')
  //         .attr('x', -0.5).attr('y', 0)
  //         .attr('width', cell_w+1).attr('height', cell_header_h)
  //         .attr('fill', (d,i) => {
  //           if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
  //           else return '#cecece'
  //         })
  //       event_header_g.append('text')
  //         .attr('x', cell_w/2).attr('y', 10)
  //         .attr('text-anchor', 'middle')
  //         .style('font-size', '9px')
  //         .attr('fill', (d,i) => {
  //           if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
  //           else return '#333'
  //         })
  //         .text((d,i) => d.area_event.type)
  //     })
  
  time_axis_bar.append('text')
    .attr('x', -4)
    .attr('y', 41)
    .attr('text-anchor', 'end')
    .style('font-size', '11px')
    .attr('fill', '#333')
    .text(inforStore.cur_timeline_indicator)
  time_axis_bar.append('g').selectAll('rect')
    .data(temporal_ids)
    .join('rect')
      .attr('id', d => `resi_unit-${d}`)
      .attr('x', d => d * step_width)
      .attr('y', time_bar_h*3 + 2)
      .attr('width', step_width)
      .attr('height', time_bar_h)
      .attr('fill', d => {
        if (inforStore.cur_timeline_indicator == 'Residual_abs')
          return temporal_err_scale(inforStore.sel_phase_details.temporal_residuals_abs[d])
        else if (inforStore.cur_timeline_indicator == 'Multi_accuracy')
          return temporal_rate_scale(inforStore.sel_phase_details.time_multi_accuracy[d])
        else if (inforStore.cur_timeline_indicator == 'POD') {
          return temporal_rate_scale(inforStore.sel_phase_details.time_pod[d])
        }
        else if (inforStore.cur_timeline_indicator == 'FAR') {
          // console.log(inforStore.sel_phase_details.time_far);
          return temporal_rate_scale(inforStore.sel_phase_details.time_far[d])
        }
      })
      .attr('stroke', '#999')
      .on('click', (e) => {
        let target_id = d3.select(e.target).attr('id').split('-')[1]
        cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, target_id));
        cur_event_end = cur_event_start + events_scope
        cur_sel_event_step = target_id - cur_event_start
        d3.select('#cur_step_mark').attr('x', cur_sel_event_step*step_width)
        phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
        phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
        phase_raw_infor = []
        for (let i = 0; i < phase_raw_data.length; i++) {
          phase_raw_infor.push([])
          for (let j = 0; j < phase_raw_data[i].length; ++j) {
            phase_raw_infor[i].push({
              'val': phase_raw_data[i][j],
              'level': phase_raw_level[i][j]
            })
          }
        }
        time_bar_g.select('#start-slider')
          .attr('transform', `translate(${cur_event_start * step_width}, ${time_bar_h*4+3})`)
        data_cells = events_bar_g.selectAll('g')
          .data(phase_raw_infor)
          .join('g')
        data_cells.selectAll('circle')
          .data(d => d)
          .join('circle')
            .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
            .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
            .attr('loc_id', (d,i) => i)
            .attr('r', 2)
            .attr('fill', (d,i) => cellValColor(d.level))
            .attr('stroke', (d,i) => {
              if (d.val >= inforStore.phase_params.focus_th) return '#333'
              else return 'none'
            })
        data_cells.selectAll('rect')
          .attr('stroke', '#bababa')
        data_cells.select(`#data-cell-${cur_sel_event_step}`)
          .attr('stroke', '#333')
        cur_sel_step.value = target_id

        cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
          event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
      })
  
  let slider_h = 8
  let slider = time_bar_g.append('g')
    .attr('id', 'start-slider')
    .attr('class', 'slider')
    .attr('transform', `translate(${cur_event_start*step_width}, ${time_bar_h*4+3})`)
    .attr('cursor', 'ew-resize')
  slider.append('rect')
    .attr('x', 0)
    .attr('y', 0)
    .attr('width', step_width*events_scope)
    .attr('height', slider_h)
    .attr('fill', '#333')
    .attr('stroke', 'none')
    .attr('opactiy', 0.2)
  slider.append('rect')
    .attr('id', 'cur_step_mark')
    .attr('x', cur_sel_event_step*step_width)
    .attr('y', 0)
    .attr('width', step_width)
    .attr('height', slider_h)
    .attr('fill', '#cecece')
    .attr('stroke', '#fff')
  // 定义拖拽
  let acc_dx = 0
  const slider_drag = d3.drag().on("start", function(event) {}).on("drag", function(event) {
    // const x = Math.max(0, Math.min(temporal_ids.length-events_scope, event.x));
    // cur_event_start = Math.round(x / step_width) * step_width
    // cur_event_end = cur_event_start + events_scope
    // time_axis_bar.selectAll('.slider')
    //   .attr('x', cur_event_start*step_width)
    // data_cells.attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
    let curSliderX = cur_event_start * step_width
    acc_dx += event.dx
    if (Math.abs(acc_dx) > step_width) {
      let newSliderStep = Math.round((parseInt(curSliderX) + acc_dx) / step_width)
      cur_event_start = Math.max(0, Math.min(temporal_ids.length-events_scope, newSliderStep));
      cur_event_end = cur_event_start + events_scope
      // console.log(curSliderX, acc_dx, (parseInt(curSliderX) + acc_dx), Math.max(0, Math.min(temporal_ids.length-events_scope, newSliderStep)), temporal_ids.length-events_scope,cur_event_start)
      phase_raw_data = inforStore.cur_phase_data.phase_raw_data.slice(cur_event_start, cur_event_end)
      phase_raw_level = inforStore.sel_phase_details.phase_raw_level.slice(cur_event_start, cur_event_end)
      phase_raw_infor = []
      for (let i = 0; i < phase_raw_data.length; i++) {
        phase_raw_infor.push([])
        for (let j = 0; j < phase_raw_data[i].length; ++j) {
          phase_raw_infor[i].push({
            'val': phase_raw_data[i][j],
            'level': phase_raw_level[i][j]
          })
        }
      }
      time_bar_g.select('#start-slider')
        .attr('transform', `translate(${cur_event_start * step_width}, ${time_bar_h*4+3})`)
        // .attr('x', cur_event_start * step_width)
      // data_cells.selectAll('circle').remove()
      data_cells = events_bar_g.selectAll('g')
        .data(phase_raw_infor)
        .join('g')
      data_cells.selectAll('circle')
        .data(d => d)
        .join('circle')
          .attr('cx', (d,i) => cell_x_scale(loc_coords_x[i]))
          .attr('cy', (d,i) => cell_y_scale(loc_coords_y[i]))
          .attr('loc_id', (d,i) => i)
          .attr('r', 2)
          .attr('fill', (d,i) => cellValColor(d.level))
          .attr('stroke', (d,i) => {
            if (d.val >= inforStore.phase_params.focus_th) return '#333'
            else return 'none'
          })
      acc_dx = 0

      cur_events = []
        for (let i = 0; i < events_scope; ++i) {
          cur_events.push([])
          for (let j = 0; j < phase_events.length; ++j) {
            if (phase_events[j].step_id == i+cur_event_start) {
              cur_events[i].push(phase_events[j])
            }
            // if (phase_events[j].step_id > i+cur_event_start) break
          }
        }
        events_headers_g.selectAll('*').remove()
        event_headers_g = events_headers_g.selectAll('g')
          .data(cur_events)
          .join('g')
            .attr('transform', (d,i) => `translate(${i*(cell_w+5)}, 0)`)
        event_header_g = event_headers_g.selectAll('g')
          .data(d => d)
          .join('g')
            .attr('transform', (d,i) => `translate(0, ${-(i+1)*cell_header_h})`)
        event_header_g.append('rect')
          .attr('x', -0.5).attr('y', 0)
          .attr('width', cell_w+1).attr('height', cell_header_h)
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
            else return '#cecece'
          })
        event_header_g.append('text')
          .attr('x', cell_w/2).attr('y', 10)
          .attr('text-anchor', 'middle')
          .style('font-size', '9px')
          .attr('fill', (d,i) => {
            if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
            else return '#333'
          })
          .text((d,i) => d.area_event.type)
        cur_sel_step.value = parseInt(cur_event_start) + parseInt(cur_sel_event_step)
    }
  }).on("end", function(event) {
    // cur_sel_event_step = 0
    data_cells.selectAll('rect')
      .attr('stroke', '#bababa')
    data_cells.select(`#data-cell-${cur_sel_event_step}`)
      .attr('stroke', '#333')
    event_header_g.select('rect')
      .attr('fill', (d,i) => {
        if (d.step_id-cur_event_start == cur_sel_event_step) return '#333'
        else return '#cecece'
      })
    event_header_g.select('text')
      .attr('fill', (d,i) => {
        if (d.step_id-cur_event_start == cur_sel_event_step) return '#fff'
        else return '#333'
      })
  })

  time_bar_g.select('#start-slider').call(slider_drag)

  let resi_legend_len = 120
  // let pollutionCntScale = d3.scaleLinear()
  //     .domain([0, resi_legend_len])
  //     .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length - 1]])
  // let pollution_cnt_legend = st_layout_svg.append('g')
  //   .attr('transform', `translate(40, ${space_layout_h-5})`)
  // let x_shift_pollu_cnt = 92
  // pollution_cnt_legend.selectAll('rect')
  //   .data(Array(resi_legend_len).fill(1))
  //   .join('rect')
  //     .attr('x', (d,i) => i + x_shift_pollu_cnt)
  //     .attr('y', 0)
  //     .attr('width', 1)
  //     .attr('height', 12)
  //     .attr('fill', (d,i) => pollutionCntScale(i))
  // pollution_cnt_legend.append('text')
  //   .attr('x', 30)
  //   .attr('y', 11)
  //   .attr('text-anchor', 'middle')
  //   .style('font-size', '12px')
  //   .attr('fill', '#333')
  //   .text('Pollution Count')
  // pollution_cnt_legend.append('text')
  //   .attr('x', -4+x_shift_pollu_cnt)
  //   .attr('y', 11)
  //   .attr('text-anchor', 'end')
  //   .style('font-size', '12px')
  //   .attr('fill', '#333')
  //   .text('0')
  // pollution_cnt_legend.append('text')
  //   .attr('x', resi_legend_len+4+x_shift_pollu_cnt)
  //   .attr('y', 11)
  //   .attr('text-anchor', 'start')
  //   .style('font-size', '12px')
  //   .attr('fill', '#333')
  //   .text('1')
  
  let pollutionValScale = d3.scaleLinear()
      .domain([0, resi_legend_len])
      .range(['#fff', '#4a1486'])
  let pollution_val_legend = st_layout_svg.append('g')
    .attr('transform', `translate(230, ${space_layout_h-5})`)
  let x_shift_pollu_val = 840
  pollution_val_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i+x_shift_pollu_val)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => pollutionValScale(i))
  pollution_val_legend.append('text')
    .attr('x', x_shift_pollu_val-60)
    .attr('y', 11)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Pollution Value')
  pollution_val_legend.append('text')
    .attr('x', -4+x_shift_pollu_val)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  pollution_val_legend.append('text')
    .attr('x', resi_legend_len+4+x_shift_pollu_val)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('500')
  
  let indicatorScale = d3.scaleQuantize()
      .domain([0, resi_legend_len])
      .range(valColorScheme_fire)
  let indicator_legend = st_layout_svg.append('g')
    .attr('transform', `translate(430, ${space_layout_h-5})`)
  let x_shift_indicator = 920
  indicator_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i+x_shift_indicator)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => indicatorScale(i))
  indicator_legend.append('text')
    .attr('x', x_shift_indicator-60)
    .attr('y', 11)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${inforStore.cur_timeline_indicator}`)
  indicator_legend.append('text')
    .attr('x', -4+x_shift_indicator)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  indicator_legend.append('text')
    .attr('x', resi_legend_len+4+x_shift_indicator)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(() => {
      if (inforStore.cur_timeline_indicator == 'Residual_abs')
        return `${parseFloat(inforStore.sel_phase_details.temporal_residuals_abs_max.toFixed(2))}`
      else if (inforStore.cur_timeline_indicator == 'Multi_accuracy')
        return 1
      else if (inforStore.cur_timeline_indicator == 'POD')
        return 1
      else if (inforStore.cur_timeline_indicator == 'FAR')
        return 1
    })
}

function onTimelineIndicatorSel(item) {
  inforStore.cur_timeline_indicator = item
  // console.log(inforStore.cur_focus_indicator);
  // drawTimeEventBar()
}
function onOuterIndicatorSel(item) {
  cur_outer_indicator.value = item
}
function onInnerIndicatorSel(item) {
  cur_inner_indicator.value = item
}

function onLinkBtnClick() {
  view_linked.value = !view_linked.value
}

function onLeftFormTypeSel(item) {
  left_form_type.value = item
}
function onRightFormTypeSel(item) {
  right_form_type.value = item
}
function onLeftStepTypeSel(item) {
  sel_step_left.value = item
}
function onRightStepTypeSel(item) {
  sel_step_right.value = item
}

// function onFormBtnHover(label) {
//   console.log('hover!!');
//   let region_id = `#${label}-form-collapse`
//   $(region_id).addClass('show')
// }
// function onFormBtnout(label) {
//   let region_id = `#${label}-form-collapse`
//   $(region_id).removeClass('show')
// } 
function num_fix_2(val) {
  return parseFloat(val.toFixed(2));
}
</script>

<template>
  <div class="models-container">
    <div ref="reference" class="title-layer">
      Exploration View
      <div class="left-form-region">
        <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="sel-title">Information: </div>
        <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ left_form_type }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in view_form_types" :value="item" @click="onLeftFormTypeSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>

        <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="sel-title">Step: </div>
        <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ sel_step_left }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in step_opts" :value="item" @click="onLeftStepTypeSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
        <div id="left-form-btn" class="iconfont" data-bs-toggle="collapse" data-bs-target="#left-form-collapse" aria-controls="left-form-collapse">&#xe8ca;</div>
        <!-- <div id="left-form-btn" class="iconfont" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample" @mouseover="onFormBtnHover('left')" @mouseout="onFormBtnout('left')">&#xe8ca;</div> -->
      </div>
      <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="right-form-region">
        <div class="right-normal-forms">
          <div class="sel-title">Information: </div>
          <div class="data-dropdown">
            <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ right_form_type }}</button>
            <ul class="dropdown-menu">
              <li v-for="(item, index) in view_form_types" :value="item" @click="onRightFormTypeSel(item)" class='dropdown-item' :key="index">
                <div class="li-data-name">{{ item }}</div>
              </li>
            </ul>
          </div>
          <div class="sel-title">Step: </div>
          <div class="data-dropdown">
            <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ sel_step_right }}</button>
            <ul class="dropdown-menu">
              <li v-for="(item, index) in step_opts" :value="item" @click="onRightStepTypeSel(item)" class='dropdown-item' :key="index">
                <div class="li-data-name">{{ item }}</div>
              </li>
            </ul>
          </div>
          <div id="right-form-btn" class="iconfont" data-bs-toggle="collapse" data-bs-target="#right-form-collapse" aria-controls="right-form-collapse">&#xe8ca;</div>
        </div>
        <div class="module-btn-region">
          <button class="btn btn-primary module-btn" type="button" data-bs-toggle="collapse" data-bs-target="#event-module"  aria-controls="event-module">Event Module</button>
          <button class="btn btn-primary module-btn" type="button" data-bs-toggle="collapse" data-bs-target="#subset-module"  aria-controls="subset-module">Subgroup Module</button>
        </div>
      </div>
    </div>
    <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="collapse" id="left-form-collapse">
      <div v-if="left_form_type=='feature'" class="form-row">
        <div class="sel-title">Outer indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_outer_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.input_feats" :value="item" @click="onOuterIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="left_form_type=='feature'" class="form-row">
        <div class="sel-title">Inner indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_inner_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.input_feats" :value="item" @click="onInnerIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="left_form_type=='error'" class="form-row">
        <div class="sel-title">Focused indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ inforStore.cur_timeline_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.indicators_list" :value="item" @click="onTimelineIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="left_form_type=='error'" class="form-row">
        <div class="form-check" v-for="(item, index) in other_indicators" :key="index">
          <input class="form-check-input" type="checkbox" :value="item" v-model="other_focused_indicators">
          <label class="form-check-label">{{ item }}</label>
        </div>
      </div>
    </div>
    <div v-if="(inforStore.cur_detail_type == 'phase') && (inforStore.cur_phase_sorted_id != -1)" class="collapse" id="right-form-collapse">
      <div v-if="right_form_type=='feature'" class="form-row">
        <div class="sel-title">Outer indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_outer_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.input_feats" :value="item" @click="onOuterIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="right_form_type=='feature'" class="form-row">
        <div class="sel-title">Inner indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_inner_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.input_feats" :value="item" @click="onInnerIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="right_form_type=='error'" class="form-row">
        <div class="sel-title">Focused indicator: </div>
        <div class="data-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ inforStore.cur_timeline_indicator }}</button>
          <ul class="dropdown-menu">
            <li v-for="(item, index) in inforStore.indicators_list" :value="item" @click="onTimelineIndicatorSel(item)" class='dropdown-item' :key="index">
              <div class="li-data-name">{{ item }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="right_form_type=='error'" class="form-row">
        <div class="form-check" v-for="(item, index) in other_indicators" :key="index">
          <input class="form-check-input" type="checkbox" :value="item" v-model="other_focused_indicators">
          <label class="form-check-label">{{ item }}</label>
        </div>
      </div>
    </div>
    <div class="collapse" id="event-module">
      <EventsView />
    </div>
    <div class="collapse" id="subset-module">
      <SubsetList />
    </div>
    <div class="exploration-block">
      <div class="st-layout-container">
        <!-- <svg id="st-layout-feature"></svg> -->
        <svg id="st-layout-left"></svg>
        <div class="seg-line"></div>
        <!-- <svg id="st-layout-phase"></svg> -->
        <svg id="st-layout-right"></svg>
      </div>
      <svg id="time-event-bar"></svg>
      <div v-if="inforStore.cur_phase_sorted_id != -1" class="cur_stamp-row-left">
        <div class="title">Timestamp: </div>
        <div class="cur_stamp">{{ cur_phase_time_str_left }}</div>
      </div>
      <div v-if="inforStore.cur_phase_sorted_id != -1" class="cur_stamp-row-right">
        <div class="title">Timestamp: </div>
        <div class="cur_stamp">{{ cur_phase_time_str_right }}</div>
      </div>
      <div v-if="inforStore.cur_phase_sorted_id != -1" id="link-view-btn" :linked="view_linked ? 'yes': 'no'" @click="onLinkBtnClick()">
        <div id="link-view-text">Link Views</div>
        <div id="link-view-icon" class="iconfont">&#xe891;</div>
      </div>
      <!-- <div v-if="inforStore.cur_phase_sorted_id != -1" class="feature-panel-title">Features: </div> -->
      <!-- <div class="feature-panel">
        <div v-for="(item, index) in inforStore.feature_infor.input.split(', ')" :key="index"><span v-if="cur_hover_loc != -1">{{item}}: {{inforStore.cur_data_infor.raw_data[global_time_id][cur_hover_loc][index]}}</span></div>
      </div> -->
    </div>
    <!-- <div id="subset-detail-tooltip"></div> -->
    <div v-if="inforStore.cur_detail_type == 'phase'" id="loc-tooltip-left">
      <div v-if="cur_hover_loc!=-1"><span class="tooltip-title">Location:</span> <span class="tooltip-val">{{ inforStore.cur_data_infor.space.loc_list[cur_hover_loc].geometry.coordinates }} {{ inforStore.loc_regions[cur_hover_loc] }}</span></div>
      <div class="horizontal-line"></div>
      <div v-if="left_form_type == 'feature'">
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Pollutants:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Pollutants" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_left][cur_hover_loc][index]}}</span></span>
        </div>
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Weather:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Weather" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_left][cur_hover_loc][6+index]}}</span></span>
        </div>
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Space:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Space" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_left][cur_hover_loc][13+index]}}</span></span>
        </div>
      </div>
      <div v-if="left_form_type == 'error'">
        <div v-if="cur_hover_loc!=-1"><span class="tooltip-title">Truth:</span> <span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_left][cur_hover_loc][0]}}</span></div>
        <div><span class="tooltip-title">Residuals:</span></div>
        <div class="tooltip-row-grids" v-if="cur_hover_loc!=-1">
          <span class="tooltip-item" v-for="(item, index) in inforStore.sel_phase_details.st_residuals[cur_step_left][cur_hover_loc]" :key="index"><span class="tooltip-title">fore_step {{index}}:</span> <span class="tooltip-val">{{ num_fix_2(item) }}</span></span>
        </div>
      </div>
    </div>
    <div v-if="inforStore.cur_detail_type == 'phase'" id="loc-tooltip-right">
      <div v-if="cur_hover_loc!=-1"><span class="tooltip-title">Location:</span> <span class="tooltip-val">{{ inforStore.cur_data_infor.space.loc_list[cur_hover_loc].geometry.coordinates }} {{ inforStore.loc_regions[cur_hover_loc] }}</span></div>
      <div class="horizontal-line"></div>
      <div v-if="right_form_type == 'feature'">
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Pollutants:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Pollutants" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_right][cur_hover_loc][index]}}</span></span>
        </div>
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Weather:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Weather" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_right][cur_hover_loc][6+index]}}</span></span>
        </div>
        <div v-if="cur_hover_loc!=-1">
          <span class="tooltip-title">Space:</span> <span class="tooltip-item" v-for="(item, index) in inforStore.type_feats.Space" :key="index"><span class="tooltip-title">{{item}}-</span><span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_right][cur_hover_loc][13+index]}}</span></span>
        </div>
      </div>
      <div v-if="right_form_type == 'error'">
        <div v-if="cur_hover_loc!=-1"><span class="tooltip-title">Truth:</span> <span class="tooltip-val">{{inforStore.cur_data_infor.raw_data[global_time_id_right][cur_hover_loc][0]}}</span></div>
        <div><span class="tooltip-title">Residuals:</span></div>
        <div class="tooltip-row-grids" v-if="cur_hover_loc!=-1">
          <span class="tooltip-item" v-for="(item, index) in inforStore.sel_phase_details.st_residuals[cur_step_left][cur_hover_loc]" :key="index"><span class="tooltip-title">fore_step {{index}}:</span> <span class="tooltip-val">{{ num_fix_2(item) }}</span></span>
        </div>
      </div>
    </div>
  </div>

</template>

<style scoped>
.models-container {
  width: 1610px;
  /* width: 860px; */
  height: 836px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 2px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 1600px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

.exploration-block {
  position: relative;
  /* width: 850px;
  height: 780px; */
}

.st-layout-container {
  display: flex;
  justify-content: space-around;
  /* align-items: center; */
}

.left-form-region {
  width: 626px;
  height: 20px;
  display: flex;
  align-items: center;
  /* border-right: solid 2px #cecece; */
}

.right-form-region {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 800px;
}

.right-normal-forms {
  display: flex;
  align-items: center;
  margin-left: 14px;
}

.error-form-region {
  display: flex;
  align-items: center;
}

.model-btn-region {
  display: flex;
  align-items: center;
}

.module-btn {
  font-size: 14px;
  padding: 2px 4px 2px 4px;
  height: 26px;
}

.seg-line {
  width: 1px;
  border: solid 1px #cecece;
  margin-top: 30px;
  height: 532px;
}

.feature-panel {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 14.5%; /* 垂直居中 */
  left: 3%; /* 水平居中 */
  background-color: #fff;
}
.feature-panel-title {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 12%; /* 垂直居中 */
  left: 3%; /* 水平居中 */
  background-color: #fff;
  font-weight: 700;
  font-size: 14px;
}
#link-view-btn {
  position: absolute;
  top: 72%; /* 垂直居中 */
  left: 47.95%; /* 水平居中 */
  color: #cecece;
  text-align: center;
}
#link-view-btn:hover {
  cursor: pointer ;
}
#link-view-btn[linked='yes'] {
  color: #1a73e8;
}
#link-view-btn[linked='no'] {
  color: #cecece;
}
#link-view-icon {
  display: block;
  margin-top: -16px;
  font-size: 32px;
}
#link-view-text {
  font-size: 14px;
}

.cur_stamp-row-left {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 5.2%; /* 垂直居中 */
  left: 1.2%; /* 水平居中 */
  display: flex;
  background-color: #fff;
  font-size: 14px;
}

.cur_stamp-row-right {
  position: absolute; /* 或者使用 fixed，根据需求选择 */
  top: 5.2%; /* 垂直居中 */
  left: 51.5%; /* 水平居中 */
  display: flex;
  background-color: #fff;
  font-size: 14px;
}

.cur_stamp-row-left .title,
.cur_stamp-row-right .title {
  font-weight: 700;
}

.cur_stamp-row-left .cur_stamp,
.cur_stamp-row-right .cur_stamp {
  margin-left: 5px;
  color: #1a73e8;
}

.sel-title {
  margin-left: 16px;
  font-size: 14px;
  font-weight: 700;
  font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
  color: #515A6E;
}

.form-check {
  font-size: 14px;
  margin-left: 16px;
  display: flex;
  align-items: center;
}

.form-check-label {
  font-weight: 14px;
  font-weight: 400;
  margin-left: 6px;
  margin-top: 2px;
}

.data-dropdown .dropdown-toggle {
  width: 130px !important;
  height: 24px;
  /* width: 120px; */
  padding: 0px 2px 0 4px;
  /* padding-bottom: -10px; */
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

.li-data-name {
    font-size: 14px;
}

.li-data-description {
    font-size: 12px;
    color: #777;
}

.select-config-row {
  display: flex;
  justify-content: space-around;
  align-items: center;
}

#loc-tooltip-left,
#loc-tooltip-right {
  width: 380px;
  position: absolute;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #999;
  border-radius: 5px;
  pointer-events: none;
  opacity: 0;
}

#time-event-bar {
  margin-top: -164px;
}

#subset-module {
  position: absolute;
  background-color: #fff;
  z-index:9999;
  height: 628px;
  padding: 0;
  margin-left: -2px
}
#event-module {
  position: absolute;
  background-color: #fff;
  z-index:9999;
  padding: 0;
  margin-left: -2px
}


.form-row {
  display: flex
}

#left-form-collapse, 
#right-form-collapse {
  z-index: 999;
  position: absolute;
  margin-left: 480px;
  width: 280px;
  border: solid 1px #cecece;
  border-radius: 5px;
  padding: 8px 4px 12px 4px;
  background-color: #fff;
}

#right-form-collapse {
  margin-left: 1080px;
  width: 290px;
}

#left-form-btn,
#right-form-btn {
  margin-left: 16px;
  font-size: 22px;
  color: #999;
  cursor: pointer;
}
#left-form-btn:hover,
#right-form-btn:hover {
  color: #1a73e8;
}

.module-btn-region {
  width: 240px;
  display: flex;
  justify-content: space-around;
}

.tooltip-title {
  font-size: 14px;
  font-weight: 700;
  color: #333;
}
.tooltip-val {
  font-size: 14px;
  color: #1a73e8;
}
.tooltip-item {
  margin-right: 10px;
  flex-basis: 45%;
}
.horizontal-line {
  border-bottom: 1px solid #cecece; /* 分割线颜色和粗细 */
  margin-top: 6px; /* 可选，增加一些下边距以避免内容过于紧凑 */
  margin-bottom: 6px; /* 可选，增加一些下边距以避免内容过于紧凑 */
}
.tooltip-row-grids {
  display: flex;
  flex-wrap: wrap;
}
</style>