<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const inforStore = useInforStore()

function drawAttrDistribution() {
    
}

</script>

<template>
  <div>
    <svg></svg>
  </div>

</template>

<style scoped>
</style>