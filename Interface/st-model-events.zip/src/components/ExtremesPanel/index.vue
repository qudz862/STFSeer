<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const inforStore = useInforStore()

watch (() => inforStore.attrs_hists, (oldVlaue, newValue) => {
  let log_e_hist = inforStore.attrs_hists['PM2.5'].map(item => Math.log(item))
  let log_10_hist = inforStore.attrs_hists['PM2.5'].map(item => Math.log10(item))
})

</script>

<template>
  <div class="models-container">
    <div class="title-layer">Extremes Panel</div>
    <div>Target pollutant: {{ inforStore.feature_infor.output }}</div>
    
  </div>

</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 740px;
  height: 368px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 720px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>