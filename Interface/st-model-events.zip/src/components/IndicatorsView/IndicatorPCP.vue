<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const props = defineProps({
  view_mode: String
})

const inforStore = useInforStore()

const model_color_scheme = ref(d3.schemeTableau10)
let cur_models = ref([])
let model_types = ref([])
let swap_overview_indicators

const indicator_pcp = {
  width: 860,
  height: 260,
  margin_top: 10, 
  margin_right: 40, 
  margin_bottom: 40, 
  margin_left: 40
}

const indicator_matrix = {
  width: 860,
  height: 280,
  margin_top: 40, 
  margin_right: 10, 
  margin_bottom: 10, 
  margin_left: 42
}

// 函数用于交换内外层级的键
function swapKeys(object) {
  const swappedObject = {};
  for (const outerKey in object) {
    for (const innerKey in object[outerKey]) {
      if (!swappedObject[innerKey]) {
        swappedObject[innerKey] = {};
      }
      swappedObject[innerKey][outerKey] = object[outerKey][innerKey];
    }
  }
  return swappedObject;
}

function drawIndicatorPCP() {
  d3.selectAll("#indicator-pcp").selectAll('*').remove()
  if (Object.keys(inforStore.cur_overview_indicators).length == 0) return
  let dimensions = Object.keys(inforStore.cur_overview_indicators)
  swap_overview_indicators = swapKeys(inforStore.cur_overview_indicators)
  let indicator_data = Object.values(swap_overview_indicators)
  const width = indicator_pcp.width - indicator_pcp.margin_left - indicator_pcp.margin_right
  const height = indicator_pcp.height - indicator_pcp.margin_top - indicator_pcp.margin_bottom
  let pcp_svg = d3.select('#indicator-pcp')
    .attr("width", indicator_pcp.width)
    .attr("height", indicator_pcp.height)
    .append("g")
    .attr("transform", "translate(" + indicator_pcp.margin_left + "," + indicator_pcp.margin_top + ")");
  
  // Create scales for each dimension
  let yScales = {}
  dimensions.forEach(dimension => {
    yScales[dimension] = d3.scaleLinear()
      .domain(d3.extent(indicator_data, d => d[dimension]))
      .range([height, 0]);
  });
  let xScale = d3.scalePoint()
    .domain(dimensions)
    .range([0, width])
  
  // Create and render axes
  const yAxes = {};
  dimensions.forEach(dimension => {
    yAxes[dimension] = d3.axisLeft(yScales[dimension])
      .tickSize(2.5) // 设置刻度线长度
    // 添加轴
    let pcp_axis = pcp_svg.append("g")
      .attr("class", "pcp-axis")
      .attr("transform", "translate(" + xScale(dimension) + ",0)")
      .call(yAxes[dimension]);
      // 添加样式...
    pcp_axis.selectAll('text')
      .style("font-size", "9.5px"); // 设置字号大小
    pcp_axis.selectAll(".tick line")
      .style("stroke-width", "1.5px"); // 设置刻度线的宽度
    pcp_axis.selectAll(".domain")
      .style("stroke-width", "1.5px"); // 设置轴线的宽度
  });
  // console.log(yAxes);

  // 添加路径
  pcp_svg.selectAll(".line")
    .data(indicator_data)
    .enter().append("path")
    .attr("class", "line")
    .attr("d", d => d3.line()(dimensions.map(dimension => [xScale(dimension), yScales[dimension](d[dimension])])))  
    .attr("fill", 'none')
    .attr("stroke", (d,i) => model_color_scheme.value[i])
    .attr("stroke-width", 3)
    // 添加样式...

  // 添加轴标签
  let textElements = pcp_svg.selectAll(".axis-label")
    .data(dimensions)
    .enter().append("text")
    .attr("id", (d,i) => `axis-label-${i}`)
    .attr("transform", d => "translate(" + xScale(d) + "," + (height + 10) + ")")
    .text(d => d)
    .attr('text-anchor', 'middle')
    .style('font-size', '10px')
    // 添加样式...
  textElements.each(function(d,i) {
    const textNode = d3.select(`#axis-label-${i}`);
    const axis_text = textNode.text()
    let split_pos_1 = axis_text.indexOf('&')
    let split_pos_2 = axis_text.indexOf('(')
    let words = []
    if (split_pos_1 != -1) {
      words.push(axis_text.slice(0, split_pos_1))
      words.push(axis_text.slice(split_pos_1, split_pos_2))
      words.push(axis_text.slice(split_pos_2))
    } else {
      words.push(axis_text.slice(0, split_pos_2))
      words.push(axis_text.slice(split_pos_2))
    }

    // console.log('words', words);
    let lineHeight = 1.1; // 行高
    
    d3.select(`#axis-label-${i}`).text("");
    let tspan = textNode.append("tspan")
      .attr("x", 0)
      .attr("dy", 0) // 初始偏移
      .text(words[0]);

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = tspan.text() + " " + word;
      const tspanNode = tspan.node();

      // 检查文本是否超出容器宽度
      if (tspanNode.getComputedTextLength() <= 30) {
        tspan.text(testLine);
      } else {
        tspan = textNode.append("tspan")
          .attr("x", 0)
          .attr("dy", lineHeight + "em") // 下一行的偏移
          .text(word);
      }
    }
  });
}

function euclideanDistance(vector1, vector2, valScales) {
  if (vector1.length !== vector2.length) {
    throw new Error("Vectors must have the same length.");
  }

  let sumSquaredDifferences = 0;
  for (let i = 0; i < vector1.length; i++) {
    const difference = valScales[i](vector1[i]) - valScales[i](vector2[i]);
    // sumSquaredDifferences += difference * difference;
    sumSquaredDifferences += difference;
  }

  // return Math.sqrt(sumSquaredDifferences);
  return sumSquaredDifferences;
}

function matrixDataSort(orginal_data_obj, valScales) {
  let orginal_data = Object.values(orginal_data_obj)
  let orginal_dimensions = Object.keys(orginal_data_obj)
  let new_data = [...orginal_data]
  let new_dimensions = [...orginal_dimensions]

  const targetVector = new Array(orginal_data[0].length).fill(0);
  new_data.sort((vectorA, vectorB) => {
    const distanceA = euclideanDistance(vectorA, targetVector, valScales);
    const distanceB = euclideanDistance(vectorB, targetVector, valScales);
    return distanceA - distanceB;
  });
  new_dimensions.sort((dimA, dimB) => {
    let dimAData = orginal_data_obj[dimA]
    let dimBData = orginal_data_obj[dimB]
    const distanceA = euclideanDistance(dimAData, targetVector, valScales);
    const distanceB = euclideanDistance(dimBData, targetVector, valScales);
    return distanceA - distanceB;
  })
  return {new_data, new_dimensions}
  
}

function drawIndicatorMatrix() {
  d3.selectAll("#indicator-matrix").selectAll('*').remove()
  if (Object.keys(inforStore.cur_overview_indicators).length == 0) return
  let orginal_matrix_data = Object.values(inforStore.cur_overview_indicators).map(item => Object.values(item))
  let matrix_axis = Object.keys(inforStore.cur_overview_indicators)
  const colorScales = []
  const valScales = []
  orginal_matrix_data.forEach(axis_data => {
    // let colorScale = d3.scaleSequential()
    let colorScale = d3.scaleLinear()
      .domain([d3.min(axis_data), d3.max(axis_data)])
      // .interpolator(d3.interpolateCool); // 使用 Blues 颜色映射
      .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
    let valScale = d3.scaleLinear()
      .domain([d3.min(axis_data), d3.max(axis_data)])
      // .interpolator(d3.interpolateCool); // 使用 Blues 颜色映射
      .range([0, 1])
    colorScales.push(colorScale)
    valScales.push(valScale)
  })

  let matrix_obj = {}
  for (let key in swap_overview_indicators) {
    matrix_obj[key] = Object.values(swap_overview_indicators[key])
  }
  let sortedObj = matrixDataSort(matrix_obj, valScales)
  let matrix_data = sortedObj.new_data
  let matrix_dims = sortedObj.new_dimensions

  const width = indicator_matrix.width - indicator_matrix.margin_left - indicator_matrix.margin_right
  const height = indicator_matrix.height - indicator_matrix.margin_top - indicator_matrix.margin_bottom
  let matrix_svg = d3.select('#indicator-matrix')
    .attr("width", indicator_matrix.width)
    .attr("height", indicator_matrix.height)
    .append("g")
    .attr("transform", "translate(" + indicator_matrix.margin_left + "," + indicator_matrix.margin_top + ")");

  const interval_x = 2, interval_y = 2
  const cell_height = height / matrix_data.length
  const cell_width = width / matrix_data[0].length

  const cells = matrix_svg.selectAll("g")
    .data(matrix_data)
    .enter()
    .append("g")
    .attr("transform", (d, i) => `translate(0, ${i * cell_height})`);

  cells.selectAll("rect")
    .data(d => d)
    .enter()
    .append("rect")
    .attr("x", (d, i) => i * cell_width)
    .attr('y', 0)
    .attr("width", cell_width - interval_x)
    .attr("height", cell_height - interval_y)
    .style("fill", (d, i) => colorScales[i](d));
  if (matrix_axis.length < 25) {
    cells.selectAll('text')
      .data(d => d)
      .enter()
      .append("text")
      .attr("x", (d,i) => i * cell_width + (cell_width - interval_x)/2)
      .attr("y", (cell_height - interval_y)/2)
      .attr("dy", 5)
      .text(d => Math.round(d * 10000) / 10000)
      .attr('text-anchor', 'middle')
      .style('font-size', d => {
        if (matrix_axis.length < 16) return '10px'
        else if (matrix_axis.length >= 16) return '9px';
        else if (matrix_axis.length >= 20) return '8px';
        else if (matrix_axis.length >= 22) return '7px';
      })
      .style('fill', '#fff')
  }
  let model_labels = matrix_svg.append('g')
    .selectAll('text')
    .data(matrix_dims)
    .join('text')
      .attr('id', (d,i) => `row-label-${i}`)
      .attr('transform', (d,i) => `translate(${-indicator_matrix.margin_left/2-2}, ${i*cell_height+(cell_height - interval_y)/2})`)
      .attr('text-anchor', 'middle')
      .style('font-size', '10px')
  model_labels.append('tspan')
    .attr('x', 0)
    .attr('dy', -2)
    .text(d => d.split('-')[0])
  model_labels.append('tspan')
    .attr('x', 0)
    .attr('dy', 12)
    .text(d => '-' + d.split('-')[1])
  let axis_labels = matrix_svg.append('g')
    .selectAll('text')
    .data(matrix_axis)
    .join('text')
      .attr('id', (d,i) => `col-label-${i}`)
      .attr('transform', (d,i) => `translate(${i*cell_width + (cell_width - interval_x)/2}, ${-indicator_matrix.margin_top+10})`)
      .attr('text-anchor', 'middle')
      .style('font-size', '10px')
  
  axis_labels.each(function(d,i) {
    const textNode = d3.select(`#col-label-${i}`);
    const axis_text = d
    let split_pos_1 = axis_text.indexOf('&')
    let split_pos_2 = axis_text.indexOf('(')
    let words = []
    if (split_pos_1 != -1) {
      words.push(axis_text.slice(0, split_pos_1))
      words.push(axis_text.slice(split_pos_1, split_pos_2))
      words.push(axis_text.slice(split_pos_2))
    } else {
      words.push(axis_text.slice(0, split_pos_2))
      words.push(axis_text.slice(split_pos_2))
    }

    // console.log('words', words);
    let lineHeight = 1.1; // 行高
    let tspan 
    if (words.length == 2) {
      tspan = textNode.append("tspan")
        .attr("x", 0)
        .attr("dy", 13) // 初始偏移
        .text(words[0]);
    } else if (words.length == 3) {
      tspan = textNode.append("tspan")
        .attr("x", 0)
        .attr("dy", 3) // 初始偏移
        .text(words[0]);
    }
    

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = tspan.text() + " " + word;
      const tspanNode = tspan.node();

      // 检查文本是否超出容器宽度
      if (tspanNode.getComputedTextLength() <= 30) {
        tspan.text(testLine);
      } else {
        tspan = textNode.append("tspan")
          .attr("x", 0)
          .attr("dy", lineHeight + "em") // 下一行的偏移
          .text(word);
      }
    }
  });
}

watch (() => inforStore.cur_overview_indicators, (oldVlaue, newValue) => {
  if (Object.keys(inforStore.cur_overview_indicators).length != 0) {
    cur_models.value = Object.keys(Object.values(inforStore.cur_overview_indicators)[0])
    model_types.value = cur_models.value.map(item => item.split('-')[0])
  }
  swap_overview_indicators = swapKeys(inforStore.cur_overview_indicators)
  if (props.view_mode == 'PCP') drawIndicatorPCP()
  else if (props.view_mode == 'Heatmap') drawIndicatorMatrix()
})

onUpdated(() => {
  if (props.view_mode == 'PCP') drawIndicatorPCP()
  else if (props.view_mode == 'Heatmap') drawIndicatorMatrix()
})

</script>

<template>
  <div>
    <div v-if="view_mode == 'PCP'" class="model-legend">
      <div class="model-item" v-for="(item, index) in cur_models" :key="index">
        <div class="model-color-icon" :style="{backgroundColor: model_color_scheme[index]}"></div>
        <Popper placement="right">
          <span class="model_name">{{ item }}</span>
          <template #content>
            <div class="model-tooltip-title">{{ item }}</div>
            <div>Year: <span class="model-tooltip-text">{{ inforStore.model_infor[model_types[index]].Year }}</span></div>
            <div>Publication: <span class="model-tooltip-text">{{ inforStore.model_infor[model_types[index]].Publication }}</span></div>
            <div>Introduction: <span class="model-tooltip-text">{{ inforStore.model_infor[model_types[index]].Introduction }}</span></div>
            <div>Spatial_module: <span class="model-tooltip-text">{{ inforStore.model_infor[model_types[index]].Modules.Spatial_module }}</span></div>
            <div>Temporal_module: <span class="model-tooltip-text">{{ inforStore.model_infor[model_types[index]].Modules.Temporal_module }}</span></div>
          </template>
        </Popper>
        
      </div>
    </div>
    <div v-if="view_mode == 'PCP'" class="pcp-container">
      <svg id="indicator-pcp"></svg>
    </div>
    <div v-if="view_mode == 'Heatmap'" class="matrix-container">
      <svg id="indicator-matrix"></svg>
    </div>
  </div>
</template>

<style scoped>
.model-legend {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 8px;
  /* margin-left: 12px; */
}

.model-item {
  display: flex;
  align-items: center;
  margin-right: 12px;
}

.model-color-icon {
  width: 16px;
  height: 12px;
  border-radius: 2px;
  background-color: #c2c5c5;
  margin-right: 3px;
}

.pcp-container {
  display: flex;
  justify-content: center;
  margin-top: 2px;
}
.matrix-container {
  display: flex;
  justify-content: center;
  margin-top: 2px;
  margin-left: 8px;
}

.model_name {
  text-decoration-line: underline;
}

.model_name:hover {
  cursor: pointer;
  color: dodgerblue;
}

.model-tooltip-title {
  font-weight: 700;
}

.model-tooltip-text {
  color: #1a73e8;
}
</style>