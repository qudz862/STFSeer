<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { Login } from "view-ui-plus"

import IndicatorPCP from './IndicatorPCP.vue'

const inforStore = useInforStore()

let cur_sel_subgroups = {
  'time_scope': [],
  'val_range': []
}

let cur_sel_metrics = []
let required_indicators = ref([])
let view_mode = ref('PCP')

let new_scheme_name = ref("")
let new_scheme_description = ref("")

const eval_indicators = ref(["nFailures", "MAE", "MAPE", "MSE", "RMSE", "masked_MAE", "masked_MAPE", "masked_MSE", "masked_RMSE", "R2", "EVAR"])

// watch (() => view_mode.value, (oldVlaue, newValue) => {
//   console.log(view_mode.value);
// })

const onSubgroupClick = (event, type, item) => {
  const cur_element = event.target
  cur_element.selected = !cur_element.selected
  if (cur_element.selected) {
    cur_element.classList.add('label-selected')
    cur_sel_subgroups[type].push(item)
  } else {
    cur_element.classList.remove('label-selected')
    const cur_index = cur_sel_subgroups[type].indexOf(item); // 获取要删除元素的索引
    if (cur_index !== -1) {
      cur_sel_subgroups[type].splice(cur_index, 1); // 删除一个元素
    }
  }
  getTmpIndicators()
}

const onMetricClick = (event, item) => {
  const cur_element = event.target
  cur_element.selected = !cur_element.selected
  if (cur_element.selected) {
    cur_element.classList.add('label-selected')
    cur_sel_metrics.push(item)
  } else {
    cur_element.classList.remove('label-selected')
    const cur_index = cur_sel_metrics.indexOf(item); // 获取要删除元素的索引
    if (cur_index !== -1) {
      cur_sel_metrics.splice(cur_index, 1); // 删除一个元素
    }
  }
  getTmpIndicators()
}

const showDeleteIcon = index => {
  const delete_icons = document.getElementsByClassName('axis-label-delete')
  delete_icons[index].style.visibility = 'visible'
}

const hideDeleteIcon = index => {
  const delete_icons = document.getElementsByClassName('axis-label-delete')
  delete_icons[index].style.visibility = 'hidden'
}

const deleteIndicator = index => {
  let deletedItem = inforStore.cur_sel_indicators.splice(index, 1)[0];
  // console.log(deletedItem, inforStore.cur_sel_indicators);
  // 指标数据中删掉
  let indicators_copy = {...inforStore.cur_overview_indicators}
  delete indicators_copy[deletedItem]
  inforStore.cur_overview_indicators = indicators_copy
}

const getTmpIndicators = () => {
  required_indicators.value = []
  let merged_subgroups = []
  for (let key in cur_sel_subgroups) {
    if (cur_sel_subgroups[key].length == 0)
      continue
    else if (merged_subgroups.length == 0 && cur_sel_subgroups[key].length != 0) {
      merged_subgroups = [...cur_sel_subgroups[key]]
      continue
    }
    let new_merged_subgroups = []
    for (let i = 0; i < merged_subgroups.length; ++i) {
      for (let j = 0; j < cur_sel_subgroups[key].length; ++j) {
        new_merged_subgroups.push(merged_subgroups[i]+'&'+cur_sel_subgroups[key][j])
      }
    }
    merged_subgroups = [...new_merged_subgroups]
  }
  
  for (let i = 0; i < merged_subgroups.length; ++i) {
    for (let j = 0; j < cur_sel_metrics.length; ++j) {
      required_indicators.value.push(merged_subgroups[i]+"(" + cur_sel_metrics[j] + ")")
    }
  }
}

const addIndicators = () => {
  inforStore.cur_sel_indicators = inforStore.cur_sel_indicators.concat(required_indicators.value)
  // 令所有选中的label变为未选中
  const all_labels = document.querySelectorAll('.axis-label');
  all_labels.forEach(element => {
    // 添加一个类名删除操作，无论该类名是否存在
    element.classList.remove('label-selected');
    element.selected = false
  });
  cur_sel_metrics = []
  cur_sel_subgroups = {
    'time_scope': [],
    'val_range': []
  }

  // 获取需要更新的指标数据
  getData(inforStore, 'overview_indicators', inforStore.cur_sel_task, inforStore.cur_sel_data, JSON.stringify(inforStore.cur_sel_time), JSON.stringify(inforStore.cur_sel_failure_rules), inforStore.cur_sel_scope_th, JSON.stringify(required_indicators.value))
  required_indicators.value = []
}

const removeAllIndicators = () => {
  inforStore.cur_sel_indicators = []
  inforStore.cur_overview_indicators = {}
}

const onSchemeConfigClick = key => {
  inforStore.cur_sel_indicator_scheme = key
  inforStore.cur_sel_indicators = inforStore.indicator_schemes[inforStore.cur_sel_indicator_scheme].indicators
  inforStore.cur_overview_indicators = {}
  getData(inforStore, 'overview_indicators', inforStore.cur_sel_task, inforStore.cur_sel_data, JSON.stringify(inforStore.cur_sel_time), JSON.stringify(inforStore.cur_sel_failure_rules), inforStore.cur_sel_scope_th, JSON.stringify(inforStore.cur_sel_indicators))
}
</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      <div>Indicators View</div>
      <div class="indicator-scheme-sel">
        <div class="attr-title">Scheme: </div>
        <div class="config-dropdown">
          <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ inforStore.cur_sel_indicator_scheme }}</button>
          <ul class="dropdown-menu" id="dropdown-choose-task">
            <!-- <li @click="onDataCardClick(-1)" class='dropdown-item'>
                <div class="li-data-name">Choose inspected data</div>
            </li> -->
            <li v-for="(key, index) in Object.keys(inforStore.indicator_schemes)" :value="key" @click="onSchemeConfigClick(key)" class='dropdown-item'>
              <div class="error-config-title">
                <span>{{ key }}</span> 
                <span>({{ inforStore.indicator_schemes[key].indicators.length }} indicators)</span>
              </div>
              <div class="li-config-description">{{ inforStore.indicator_schemes[key].description }}</div>
            </li>
          </ul>
        </div>
      </div>
      <div class="view-mode-check">
        <div class="form-check">
          <input class="form-check-input" type="radio" value="PCP" v-model="view_mode">
          <label class="form-check-label">PCP</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" value="Heatmap" v-model="view_mode">
          <label class="form-check-label">Heatmap</label>
        </div>
      </div>
    </div>
    <div class="indicator-sel-block">
      <div class="axis-labels-row">
        <div id="subgroup-row-title" class="label-row-title">Subgroup</div>
        <div class="label-row-content">
          <div class="labels-block" v-for="(key, index) in Object.keys(inforStore.cur_overview_subgroups)">
            <div class="axis-item" v-for="(item, i) in inforStore.cur_overview_subgroups[key]">
              <span class="axis-label" selected=false @click="onSubgroupClick($event, key, item)">{{ item }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="axis-labels-row">
        <div class="label-row-title">Metrics</div>
        <div class="label-row-content">
          <div class="axis-item" v-for="(item, index) in eval_indicators">
            <span class="axis-label" selected=false @click="onMetricClick($event, item)">{{ item }}</span>
          </div>
        </div>
        
      </div>
      <div class="add-indicator-row">
        <div>Indicators to be added: <span class="required-labels" v-for="(item,index) in required_indicators">{{ item }}</span></div>
        <div id="add-indicator" @click="addIndicators()">
          <span class="iconfont">&#xe617;</span> 
          <span>Add</span>
        </div>
      </div>

      <div class="axis-labels-row">
        <div id="indicator-row-title" class="label-row-title">Indicators</div>
        <div class="label-row-content">
          <div class="indicator-item" v-for="(item, index) in inforStore.cur_sel_indicators" @mouseover="showDeleteIcon(index)" @mouseout="hideDeleteIcon(index)">
            <!-- <div class="axis-color-icon"></div> -->
            <span class="axis-label">{{item}}</span>
            <span class="axis-label-delete iconfont" @click="deleteIndicator(index)">&#xe620;</span>
          </div>
          <div id="remove-all" @click="removeAllIndicators()">
            <span>Remove All</span>
          </div>
        </div>
      </div>
    </div>
    <IndicatorPCP :view_mode="view_mode" />
  </div>
</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 876px;
  height: 466px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 860px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  /* align-items: center; */
  /* justify-content: space-between; */
}

.indicator-sel-block {
  border: solid 1px #cecece;
  border-radius: 6px;
  margin-left: 12px;
  margin-right: 12px;
}

.sel-indicator-container {
  display: flex;
}

.axis-labels-row {
  /* margin-left: 12px; */
  min-height: 26px;
  display: flex;
  flex-wrap: wrap;
  border-bottom: solid 1px #cecece;
}

.axis-labels-row:last-of-type {
  border-bottom: none;
}

.add-indicator-row {
  min-height: 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-left: 4px;
  padding-right: 12px;
  border-bottom: solid 1px #cecece;
}

.label-row-title {
  width: 70px;
  border-right: solid 1px #c2c5c5;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  /* padding-left: 4px; */
  background-color: #efefef;
}

#subgroup-row-title {
  border-top-left-radius: 5px;
}

#indicator-row-title {
  border-bottom-left-radius: 5px;
}

.label-row-content {
  display: flex;
  flex: 1;
  align-items: center;
  flex-wrap: wrap;
  margin-left: 2px;
}

.labels-block {
  display: flex;
  flex-wrap: wrap;
  margin-right: 10px;
}

.axis-item {
  display: flex;
  align-items: center;
  margin-right: 6px;
}

.indicator-item {
  display: flex;
  align-items: center;
}

.axis-label {
  font-size: 13px;
  cursor: pointer;
  padding: 1px 3px;
  border: solid 1px #fff;
  border-radius: 4px;
}

.axis-label:hover {
  font-size: 13px;
  cursor: pointer;
  border-color: #1a73e8;
}

.required-labels {
  font-size: 13px;
  margin-right: 8px;
}

.label-selected {
  color: #fff;
  background-color: #1a73e8;
}

.axis-label-delete {
  font-size: 10px;
  /* margin-left: 2px; */
  opacity: 0.5;
  cursor: pointer;
  visibility: hidden;
  position: relative;
  top: -10px; /* 负值使其在上方留出空间 */
  right: 2px;
}

.axis-label-delete:hover {
  color: #1a73e8;
}

#save-scheme,
#remove-all,
#add-indicator {
  font-size: 13px;
  min-width: 60px;
  line-height: 20px;
  color: #333;
  border: solid 1px #1a73e8;
  border-radius: 5px;
  /* background-color: #999; */
  text-align: center;
  font-weight: 700;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
}

#remove-all {
  min-width: 84px;
}

#save-scheme {
  min-width: 112px;
  margin-left: 6px;
}

#save-scheme:hover,
#remove-all:hover,
#add-indicator:hover {
  background-color: #1a73e8;
  color: #fff;
}

#add-indicator .iconfont {
  font-size: 6px;
  margin-right: 3px;
}

.indicator-scheme-sel {
  display: flex;
  align-items: end;
  width: 260px;
  margin-left: 20px;
  font-size: 14px;
  font-weight: 400;
}

.view-mode-check {
  display: flex;
  align-items: start;
  width: 300px;
  margin-left: 20px;
  /* justify-content: center; */
  /* align-items: center; */
  font-size: 14px;
  font-weight: 400;
}

.view-mode-check .form-check {
  display: flex;
  align-items: center;
  margin-right: 10px;
}

.view-mode-check .form-check-input {
  width: 14px !important; 
  height: 14px !important;
  margin-top: 0;
  margin-right: 4px;
}

.config-dropdown {
  /* margin-right: 20px !important; */
}

.config-dropdown .dropdown-toggle {
  width: 200px !important;
  height: 22px;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.config-dropdown .dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.config-dropdown .dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  width: 310px;
  cursor: pointer;
  white-space: normal;
}

.config-dropdown .dropdown-item:hover {
  background-color: #cecece;
}

.error-config-title {
  display: flex;
  /* justify-content: space-between; */
  align-items: center;
}

.error-config-title span:first-child {
  margin-right: 6px;
}

.li-config-description {
  font-size: 12px;
  color: #777;
  margin-top: 3px;
}

.attr-title {
  font-weight: 700;
}

.save-config-name {
  font-size: 14px;
  display: flex;
  align-items: center;
  margin-bottom: 6px;
}

.save-config-name .form-control {
  width: 190px !important;
  height: 22px;
  /* width: 120px; */
  margin-left: 4px;
  padding: 0px 2px 0 4px !important;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
}

.save-config-description {
  font-size: 14px;
}

.save-config-row {
  margin-top: 6px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.save-config-state {  
  font-size: 14px;
  /* font-weight: 700; */
  color: #157347;
}

#save-config-btn {
  font-size: 14px;
  padding: 3px 6px !important;
}

</style>
