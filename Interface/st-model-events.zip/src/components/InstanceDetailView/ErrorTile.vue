<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'

const inforStore = useInforStore()

const props = defineProps({
  stamp_id: String,
  stamp_obj: Object,
  err_range: Array,
  cur_index: Number
})

// console.log(props.stamp_id);
// console.log(inforStore.cur_sel_stamp_objs[props.stamp_id]);
// console.log(inforStore.cur_sel_stamp_objs[props.stamp_id].timestamp);

const err_tile_id = (stamp_id) => ('err-tile' + stamp_id)
onMounted(() => {
  drawErrorTile()
})

onUpdated(() => {
  drawErrorTile()
})

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}

function drawErrorTile() {
  let cur_stamp_obj = props.stamp_obj
  let binary_labels = cur_stamp_obj.binary_label
  let multi_labels = cur_stamp_obj.multi_label
  let residuals = cur_stamp_obj.residual
  
  let svg_w = 60, svg_h = 60
  let svg_id = err_tile_id(props.stamp_id)
  d3.select(`#${svg_id}`).selectAll('*').remove()
  let svg = d3.select(`#${svg_id}`)
    .attr('width', svg_w)
    .attr('height', svg_h)
  let glyphs_g = svg.append('g')
  let residualsColorScale = d3.scaleSequential(d3.interpolateRdBu)
    .domain(props.err_range)
  let forecast_step_num = residuals.length
  let pie = d3.pie()
  let arcData = pie(Array(forecast_step_num).fill(1))
  let binaryArc = d3.arc()
    .innerRadius(0)
    .outerRadius(8)
  let multiArc = d3.arc()
    .innerRadius(10)
    .outerRadius(16)
  let residualsArc = d3.arc()
    .innerRadius(18)
    .outerRadius(24)
  let stepArc = d3.arc()
    .innerRadius(24.5)
    .outerRadius(28)
  
  let binary_ring = glyphs_g.append('g')
      .attr('class', '.binary-ring')
      .attr('transform', `translate(${svg_w/2}, ${svg_h/2})`)
        .selectAll('path')
        .data(arcData)
        .join("path")
          .attr('d', binaryArc)
          .attr('stroke', '#999')
          // .attr('stroke', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return '#333'
          //   else return '#cecece'
          // })
          .attr('stroke-width', 0.5)
          .attr('fill', (d,i) => {
            if (binary_labels[i] == 1) return '#333'
            else if (binary_labels[i] == -1) return '#cecece'
            else if (binary_labels[i] == 2) return valColorScheme_red[3]
            else if (binary_labels[i] == -2) return valColorScheme_blue[3]
          })
          // .attr('opacity', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return 1
          //   else return 0.2
          // })
  let multi_ring = glyphs_g.append('g')
      .attr('class', '.multi-ring')
      .attr('transform', `translate(${svg_w/2}, ${svg_h/2})`)
        .selectAll('path')
        .data(arcData)
        .join("path")
          .attr('d', multiArc)
          .attr('stroke', '#999')
          // .attr('stroke', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return '#333'
          //   else return '#cecece'
          // })
          // .attr('stroke-width', 0.5)
          .attr('fill', (d,i) => {
            // return '#cecece'
            if (multi_labels[i] == 0) return '#cecece'
            else if (multi_labels[i] == 1) return valColorScheme_fire[3]
            else if (multi_labels[i] == -1) return valColorScheme_blue[3]
            else {
              return '#cecece'
            }
          })
          // .attr('opacity', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return 1
          //   else return 0.2
          // })
  let residuals_ring = glyphs_g.append('g')
      .attr('class', '.residuals-ring')
      .attr('transform', `translate(${svg_w/2}, ${svg_h/2})`)
        .selectAll('path')
        .data(arcData)
        .join("path")
          .attr('d', residualsArc)
          .attr('stroke', '#999')
          // .attr('stroke', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return '#333'
          //   else return '#cecece'
          // })
          // .attr('stroke-width', 0.5)
          .attr('fill', (d,i) => residualsColorScale(residuals[i]))
          // .attr('opacity', (d,i) => {
          //   if (cur_stamp_obj.fore_step.includes(i)) return 1
          //   else return 0.2
          // })
  
  // const angleInterval = 360 / forecast_step_num;
  // let step_circles = glyphs_g.append('g')
  //   .attr('transform', `translate(${svg_w/2}, ${svg_h/2-4})`)
  // for (let i = 0; i < forecast_step_num; i++) {
  //   const angle = (i + 0.5) * angleInterval
  //   // 将极坐标转换为笛卡尔坐标
  //   const x = Math.cos(toRadians(angle)) * 28;
  //   const y = Math.sin(toRadians(angle)) * 28;
  //   // 绘制小圆
  //   step_circles.append("circle")
  //     .attr("cx", x)
  //     .attr("cy", y)
  //     .attr("r", 1)  // 小圆的半径
  //     .attr("fill", "#333");
  // }

  let step_ring = glyphs_g.append('g')
      .attr('class', '.step-ring')
      .attr('transform', `translate(${svg_w/2}, ${svg_h/2})`)
        .selectAll('path')
        .data(arcData)
        .join("path")
          .attr('d', stepArc)
          .attr('stroke', '#fff')
          // .attr('stroke-width', 2)
          .attr('fill', (d,i) => {
            if (cur_stamp_obj.fore_step.includes(i)) return '#333'
            // else return '#cecece'
            else return 'none'
          })
}


</script>

<template>
  <div class="err-tile-box">
    <div class="stamp-str">{{ stamp_obj.timestamp }}</div>
    <svg class="err-tile" :id="err_tile_id(stamp_id)"></svg>
  </div>
</template>

<style scoped>
.stamp-str {
  margin-bottom: -4px;
}

.err-tile-box {
  width: 70px;
  height: 75px;
  border: solid 1px #999;
  margin: 1px;
  text-align: center;
}

.err-tile-box:hover {
  cursor: pointer;
}

</style>