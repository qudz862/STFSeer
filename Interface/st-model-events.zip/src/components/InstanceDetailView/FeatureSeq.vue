<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'

const inforStore = useInforStore()

const props = defineProps({
  feature_id: Number,
  feature_str: String,
  feature_data: Array,
  feature_conditions: Object,
  all_features: Array
})

onMounted(() => {
  // console.log(props.feature_id);
  drawFeatureSeq()
})

onUpdated(() => {
  // console.log(props.feature_id);
  drawFeatureSeq()
})

const view_id = (feat_id) => `feat_seq-${feat_id}`

function drawFeatureSeq() {
  inforStore.cur_feature_hover_step = inforStore.loc_feature_conditions.step_id
  let svg_id = view_id(props.feature_id)
  let feat_seq_svg = d3.select('#'+svg_id)
  feat_seq_svg.selectAll('*').remove()
  let margin_left = 45, margin_right = 34, margin_top = 20, margin_bottom = 20
  let main_w = 440, main_h = 80
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  feat_seq_svg
    .attr('width', svg_w)
    .attr('height', svg_h)
  
  let xScale_step = d3.scaleLinear()
    .domain([0, props.feature_data.length-1])
    .range([0, main_w])
  let step_len = xScale_step(1) - xScale_step(0) 
  let cur_stamps = props.feature_data.map(item => item.stamp)
  let cur_dates = cur_stamps.map(item => {
    let cur_year = parseInt('20'+item.substring(0,2))
    let cur_month = parseInt(item.substring(3,5))-1
    let cur_day = parseInt(item.substring(6,8))
    let cur_hour = parseInt(item.substring(9,11))
    let cur_date = new Date(cur_year, cur_month, cur_day, cur_hour)  
    return cur_date
  })
  let data_date = props.feature_data.map((item,i) => {
    return {'date': cur_dates[i], 'val': item.val}
  })
  let xScale_stamp = d3.scaleTime()
    .domain([cur_dates[0], cur_dates[cur_dates.length-1]])
    .range([0, main_w])
  let y_data = props.feature_data.map(item => item.val)
  let y_data_min = d3.min(y_data)
  let y_data_max = d3.max(y_data) 
  let y_data_min_edge = y_data_min - (y_data_max-y_data_min) * 0.08
  if (props.feature_id == 0) {
    let seq_id = inforStore.loc_feature_conditions.seq_id
    let loc_id = inforStore.loc_feature_conditions.loc_id
    let pred_seq = inforStore.cur_instance_seqs.instance_seqs_space[seq_id].map(item => item[loc_id])
    let pred_output = inforStore.cur_instance_seqs.output_pred_steps_space[loc_id][seq_id]
    pred_seq.push(pred_output)
    if (d3.max(pred_seq) > y_data_max) y_data_max = d3.max(pred_seq)
    
  }
  let yScale = d3.scaleLinear()
    .domain([y_data_min_edge, y_data_max])
    .range([main_h, 0])
  let xAxis = d3.axisBottom(xScale_stamp)
    .ticks(inforStore.cur_data_infor.time.input_window+1)
    .tickFormat(d3.timeFormat("%d %H"))  
    .tickSize(4.0)
  let yAxis = d3.axisLeft(yScale)
    .tickSize(3.0)
    .ticks(5)
  
  let seq_g = feat_seq_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
    .on('mousemove', (e) => {
      let offset_x = e.offsetX - margin_left
      let offset_step_num = Math.round(offset_x / step_len)
      inforStore.cur_feature_hover_step = offset_step_num
      d3.selectAll('.flag-line')
        .attr('x1', xScale_step(inforStore.cur_feature_hover_step))
        .attr('x2', xScale_step(inforStore.cur_feature_hover_step))
      let flag_points = d3.selectAll('.flag-point')
      flag_points.data(flag_points.nodes())
        .attr('cx', xScale_step(inforStore.cur_feature_hover_step))
        .attr('cy', (_, i) => {
          let cur_cy = d3.select(`#point-${i}-${inforStore.cur_feature_hover_step}`).attr('cy')
          return cur_cy
        })
      let flag_texts = d3.selectAll('.flag-text')
      flag_texts.data(flag_texts.nodes())
        .attr('x', () => {
          if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return xScale_step(inforStore.cur_feature_hover_step)+5
          else return xScale_step(inforStore.cur_feature_hover_step)-5
        })
        .attr('text-anchor', () => {
          if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return 'start'
          else return 'end'
        })
        .text((_, i) => {
          let cur_feat = props.all_features[i]
          let cur_val = inforStore.cur_loc_features[cur_feat][inforStore.cur_feature_hover_step].val
          return cur_val
        })
      let flag_texts_pred = d3.selectAll('.flag-text-pred')
      flag_texts_pred.data(flag_texts.nodes())
        .attr('x', () => {
          if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return xScale_step(inforStore.cur_feature_hover_step)+5
          else return xScale_step(inforStore.cur_feature_hover_step)-5
        })
        .attr('text-anchor', () => {
          if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return 'start'
          else return 'end'
        })
        .text(() => {
          let pred_step_id = parseInt(inforStore.cur_feature_hover_step) + parseInt(inforStore.loc_feature_conditions.pred_num) - parseInt(inforStore.cur_data_infor.time.input_window)
          if (pred_step_id >= 0) {
            let cur_pred_val = d3.select(`#pred-point-${pred_step_id}`).attr('pred_val')
            return parseFloat(cur_pred_val).toFixed(2)
          }
          else return ''
        })
    })
  seq_g.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', main_w)
    .attr('height', main_h)
    .attr('fill', '#fff')
    .attr('stroke', 'none')

  const line = d3.line()
    .x((d) => xScale_stamp(d.date))
    .y((d) => yScale(d.val))

  seq_g.append('line')
    .attr('class', 'flag-line')
    .attr('x1', xScale_step(inforStore.cur_feature_hover_step))
    .attr('x2', xScale_step(inforStore.cur_feature_hover_step))
    .attr('y1', 0).attr('y2', main_h)
    .attr('fill', 'none')
    .attr('stroke', valColorScheme_blue[3])
    .attr('stroke-width', 2)
    .attr('stroke-dasharray', '5,5')
  seq_g.append('path')
    .datum(data_date)
    .attr('d', line)  
    .attr('fill', 'none')
    .attr('stroke', '#666');
  let seq_points_g = seq_g.append('g')
  seq_points_g.selectAll('circle')
    .data(data_date)
    .join('circle')
      .attr('id', (d,i) => `point-${props.feature_id}-${i}`)
      .attr('cx', (d,i) => xScale_stamp(d.date))
      .attr('cy', (d,i) => yScale(d.val))
      .attr('r', 2.5)
      .attr('fill', (d,i) => '#999')
  
  seq_g.append('circle')
    .attr('class', 'flag-point')
    .attr('cx', xScale_step(inforStore.cur_feature_hover_step))
    .attr('cy', yScale(props.feature_data[inforStore.cur_feature_hover_step].val))
    .attr('r', 2.5)
    .attr('fill', valColorScheme_blue[3])
  seq_g.append('text')
    .attr('class', 'flag-text')
    .attr('x', () => {
      if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return xScale_step(inforStore.cur_feature_hover_step)+5
      else return xScale_step(inforStore.cur_feature_hover_step)-5
    })
    .attr('y', 12)
    .attr('text-anchor', () => {
      if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return 'start'
      else return 'end'
    })
    .style('font-size', '12px')
    .attr('fill', valColorScheme_blue[3])
    .text(props.feature_data[inforStore.cur_feature_hover_step].val)

  if (props.feature_id == 0) {
    let pred_data_num = inforStore.loc_feature_conditions.pred_num
    let seq_id = inforStore.loc_feature_conditions.seq_id
    let loc_id = inforStore.loc_feature_conditions.loc_id
    let pred_seq = inforStore.cur_instance_seqs.instance_seqs_space[seq_id].map(item => item[loc_id])
    let pred_output = inforStore.cur_instance_seqs.output_pred_steps_space[loc_id][seq_id]
    pred_seq.push(pred_output)
    let pred_data = []
    for (let i = inforStore.cur_data_infor.time.input_window-pred_data_num; i <= inforStore.cur_data_infor.time.input_window; ++i) {
      let pred_step_obj = {}
      pred_step_obj['date'] = data_date[i].date
      pred_step_obj['val'] = pred_seq[i]
      pred_data.push(pred_step_obj)
    }
    let pred_seq_g = feat_seq_svg.append('g')
      .attr('transform', `translate(${margin_left}, ${margin_top})`)
    pred_seq_g.append('path')
      .datum(pred_data)
      .attr('d', line)  
      .attr('fill', 'none')
      .attr('stroke', valColorScheme_fire[3])
      .attr('stroke-dasharray', '3,3')
    let pred_seq_points_g = seq_g.append('g')
    pred_seq_points_g.selectAll('circle')
      .data(pred_data)
      .join('circle')
        .attr('id', (d,i) => `pred-point-${i}`)
        .attr('pred_val', (d,i) => d.val)
        .attr('cx', (d,i) => xScale_stamp(d.date))
        .attr('cy', (d,i) => yScale(d.val))
        .attr('r', 2.5)
        .attr('fill', (d,i) => valColorScheme_fire[3])
    seq_g.append('text')
      .attr('class', 'flag-text-pred')
      .attr('x', () => {
        if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return xScale_step(inforStore.cur_feature_hover_step)+5
        else return xScale_step(inforStore.cur_feature_hover_step)-5
      })
      .attr('y', 30)
      .attr('text-anchor', () => {
        if (inforStore.cur_feature_hover_step < inforStore.cur_data_infor.time.input_window / 2) return 'start'
        else return 'end'
      })
      .style('font-size', '12px')
      .attr('fill', valColorScheme_fire[3])
      .text(() => {
        let pred_step_id = parseInt(inforStore.cur_feature_hover_step) + parseInt(pred_data_num) - parseInt(inforStore.cur_data_infor.time.input_window)
        if (pred_step_id >= 0) return pred_data[pred_step_id].val.toFixed(2)
        else return ''
      })
  }

  feat_seq_svg.append('text')
    .attr('x', margin_left)
    .attr('y', 15)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(props.feature_str)
  feat_seq_svg.append('text')
    .attr('x', margin_left+main_w+4)
    .attr('y', margin_top+main_h+4)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Time')

  feat_seq_svg.append('g')
    .attr('id', `feat-${props.feature_id}-x-axis`)
    .attr('transform', `translate(${margin_left}, ${margin_top+main_h})`)
    .call(xAxis);
  feat_seq_svg.append('g')
    .attr('id', `feat-${props.feature_id}-y-axis`)
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
    .call(yAxis);
  d3.select(`#feat-${props.feature_id}-x-axis`)
    .selectAll('.tick:nth-child(odd)')
    .select('text')
    // .remove()
    .style('display', 'none')
}

</script>

<template>
  <div>
    <svg class="feature-seq" :id="view_id(feature_id)"></svg>
  </div>
  

</template>

<style scoped>
.feature-seq {
  margin-right: 4px;
}
</style>