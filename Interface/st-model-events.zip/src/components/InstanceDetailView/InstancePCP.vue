<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'

const inforStore = useInforStore()

watch (() => inforStore.cur_instance_details, (oldVlaue, newValue) => {
  drawInstancePCP()
})

watch (() => inforStore.tile_resi_edge_range, (oldVlaue, newValue) => {
  drawInstanceLegends()
})

let cur_filter_conditions = ref({})

// watch (() => cur_filter_conditions.value, (oldVlaue, newValue) => {
//   console.log(cur_filter_conditions.value);
// })

function drawInstancePCP() {
  d3.select('#ins-pcp-svg').selectAll('*').remove()
  let margin_left = 40, margin_right = 20, margin_top = 18, margin_bottom = 10
  let main_w = 1240, main_h = 200
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let pcp_svg = d3.select('#ins-pcp-svg')
    .attr('width', svg_w)
    .attr('height', svg_h)
    .append("g")
    .attr("transform", `translate(${margin_left},${margin_top})`)

  let instance_objs = inforStore.cur_instance_details.instance_objs
  let dim_objs = inforStore.cur_instance_details.attrs_obj
  let dims = ['truth', 'prediction', 'residual', 'temporal_state_vals', 'space_comp_state_vals', 'space_diff_state_vals', 'step']
  
  instance_objs.forEach(obj => {
    obj['selected'] = 1
  })


  // 为每个轴定义scale
  let yScales = {}
  dims.forEach(dim => {
    cur_filter_conditions.value[dim] = []
    if (dim_objs[dim].type == 'continuous') {
      yScales[dim] = d3.scaleLinear()
        .domain([dim_objs[dim].bin_edges[0], dim_objs[dim].bin_edges[dim_objs[dim].bin_edges.length-1]])
        .range([main_h, 0])
    }
    if (dim_objs[dim].type == 'category') {
      yScales[dim] = d3.scalePoint()
        .domain(dim_objs[dim].bin_edges)
        .range([main_h, 0])
    }
  });
  let xScale = d3.scalePoint()
    .domain(dims)
    .range([0, main_w])

  // 添加轴标签
  let textElements = pcp_svg.selectAll(".axis-label")
    .data(dims)
    .enter().append("text")
    .attr("id", (d,i) => `axis-label-${i}`)
    .attr("transform", d => `translate(${xScale(d)}, -10)`)
    .text(d => d)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')

  
  // 添加路径
  let lines = pcp_svg.selectAll(".line")
    .data(instance_objs)
    .join("path")
    .attr("class", "line")
    .attr("d", d => d3.line()(dims.map(dim => [xScale(dim), yScales[dim](d[dim])])))  
    .attr("fill", 'none')
    .attr("stroke", (d,i) => {
      if (d.selected == 1) return valColorScheme_blue[3]
      else return '#999'
    })
    .attr("stroke-width", 1)
    .attr("opacity", 0.5)

  // 创建刷选器
  const brushes = {}
  const brushes_g = {}
  let brush_w = 40
  dims.forEach(dim => {
    brushes[dim] = d3.brushY()
      .extent([[xScale(dim)-brush_w/2, 0], [xScale(dim)+brush_w/2, main_h]])
      .on('brush', brushMove)
      .on("end", brushEnded)
    brushes_g[dim] = pcp_svg.append("g")
      // .attr('transform', `translate(${xScale(dim)}, 0)`)
      .attr('class', `brush-${dim}`)
      .call(brushes[dim])
    brushes_g[dim].select('.overlay')
      .attr('dim', `${dim}`)
  })

  let brushing = false; // 添加一个标志位
  function brushMove(e) {
    let cur_dim = d3.select(e.sourceEvent.target).attr('dim')
    if (e && !brushing) {
      brushing = true; // 设置标志位，防止递归调用
      let selection = e.selection
      let step = 1
      let y0 = Math.floor(selection[0] / step) * step
      let y1 = Math.ceil(selection[1] / step) * step
      // 更新选择框的位置
      brushes_g[cur_dim].call(brushes[cur_dim].move, [y0, y1])
      brushing = false
    }
  }
  function brushEnded(e) {
    let selection = e.selection;
    let cur_dim = d3.select(e.sourceEvent.target).attr('dim')
    if (selection) {
      let y0 = yScales[cur_dim].invert(selection[0]);
      let y1 = yScales[cur_dim].invert(selection[1]);
      let y0_int = parseInt(Math.round(y0))
      let y1_int = parseInt(Math.round(y1))

      cur_filter_conditions.value[cur_dim] = [y1_int, y0_int]
      // 在这里可以执行你的操作，例如根据范围重新渲染图表等
    } else {
      cur_filter_conditions.value[cur_dim] = []
    }
    instance_objs.forEach(obj => {
      obj.selected = 1
      for (let dim in cur_filter_conditions.value) {
        if (cur_filter_conditions.value[dim] == []) continue
        let cur_condition = cur_filter_conditions.value[dim]
        if (obj[dim] < cur_condition[0] || obj[dim] > cur_condition[1]) {
          obj.selected = 0
          break
        }
      }
    })
    let filtered_ins_objs = instance_objs.filter(item => item.selected == 1)
    let filtered_stamp_objs = {}
    filtered_ins_objs.forEach(obj => {
      if (obj.stamp_id in filtered_stamp_objs) {
        filtered_stamp_objs[obj.stamp_id].fore_step.push(obj.step)
      } else {
        filtered_stamp_objs[obj.stamp_id] = inforStore.cur_instance_details.timestamp_objs[obj.stamp_id]
        filtered_stamp_objs[obj.stamp_id].fore_step = [obj.step]
      }
    })
    inforStore.cur_sel_stamp_objs = filtered_stamp_objs
    // pcp_svg.selectAll(".line").selectAll('*').remove()
    lines.attr("stroke", (d,i) => {
      if (d.selected == 1) return valColorScheme_blue[3]
      else return '#999'
    })
  }

  // 创建轴
  const yAxes = {};
  let pcp_axes = {}
  dims.forEach(dim => {
    yAxes[dim] = d3.axisLeft(yScales[dim])
      .tickSize(2.0) // 设置刻度线长度
    // 添加轴
    pcp_axes[dim] = pcp_svg.append("g")
      .attr("class", "pcp-axis")
      .attr("transform", "translate(" + xScale(dim) + ",0)")
      .call(yAxes[dim]);
    // 添加样式...
    pcp_axes[dim].selectAll('text')
      .style("font-size", "9.5px"); // 设置字号大小
    pcp_axes[dim].selectAll(".tick line")
      .style("stroke-width", "1.5px"); // 设置刻度线的宽度
    pcp_axes[dim].selectAll(".domain")
      .style("stroke-width", "1.5px"); // 设置轴线的宽度
  })
}

function drawInstanceLegends() {
  d3.select('#instance-legends').selectAll('*').remove()
  let margin_left = 20, margin_right = 20, margin_top = 32, margin_bottom = 0
  let main_w = 220, main_h = 160
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legends_svg = d3.select('#instance-legends')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legends_g = legends_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let resi_legend_len = 120
  let resiLegendScale = d3.scaleSequential(d3.interpolateRdBu)
    .domain([0, resi_legend_len])
  let residual_legend =  legends_g.append('g')
    .attr('transform', 'translate(48, 0)')
  residual_legend.selectAll('rect')
    .data(Array(resi_legend_len).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => resiLegendScale(i))
  residual_legend.append('text')
    .attr('x', resi_legend_len * 0.5)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Residual Colormap')
  residual_legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${parseFloat(inforStore.tile_resi_edge_range[0].toFixed(2))}`)
  residual_legend.append('text')
    .attr('x', resi_legend_len+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${parseFloat(inforStore.tile_resi_edge_range[1].toFixed(2))}`)
  let binary_label_legend = legends_g.append('g')
    .attr('transform', `translate(0, 65)`)
  let label_block_w = 60, box_w = 12
  binary_label_legend.append('text')
    .attr('x', 110)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Dichotomous Label')
  binary_label_legend.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#333') // hit
  binary_label_legend.append('text')
    .attr('x', box_w + 3)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Hit')

  binary_label_legend.append('rect')
    .attr('x', box_w+30).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#cecece') // neg correct
  binary_label_legend.append('text')
    .attr('x', box_w*2 + 33)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Correct Negative')
  
  binary_label_legend.append('rect')
    .attr('x', box_w*2+133).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_fire[3]) // false alarm
  binary_label_legend.append('text')
    .attr('x', box_w*3 + 136)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('False Alarm')
  
  binary_label_legend.append('rect')
    .attr('x', box_w*3+209).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_blue[3]) // false alarm
  binary_label_legend.append('text')
    .attr('x', box_w*4 + 212)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Miss')

  let multi_label_legend = legends_g.append('g')
    .attr('transform', `translate(24, 130)`)
    multi_label_legend.append('text')
    .attr('x', 90)
    .attr('y', -8)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Multi-category Label')
  multi_label_legend.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', '#cecece')
  multi_label_legend.append('text')
    .attr('x', box_w + 3)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Accurate')  // 估计准确 

  multi_label_legend.append('rect')
    .attr('x', box_w + 62).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_fire[3])
  multi_label_legend.append('text')
    .attr('x', box_w*2 + 65)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Higher')

  multi_label_legend.append('rect')
    .attr('x', box_w*2 + 110).attr('y', 0)
    .attr('width', box_w)
    .attr('height', box_w)
    .attr('fill', valColorScheme_blue[3])
  multi_label_legend.append('text')
    .attr('x', box_w*3 + 113)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('Lower')
}

</script>

<template>
  <div>
    <svg id="ins-pcp-svg"></svg>
    <svg id="instance-legends"></svg>
  </div>
</template>

<style scoped>
#instance-legends {
  margin-left: 20px;
}
</style>