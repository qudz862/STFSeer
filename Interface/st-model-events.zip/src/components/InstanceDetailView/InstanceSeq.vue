<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'
import FeatureSeq from './FeatureSeq.vue'

const inforStore = useInforStore()

const props = defineProps({
  show_state: String,
  seq_id: Number,
  stamp_id: Number,
  seq_data: Array,
  seq_num: Number,
  step_flag: Boolean
})

let show_features = ref(["PM2.5", "PM10", "SO2", "NO2", "CO", "O3", "U", "V", "TEMP", "RH", "PSFC"])
const ins_seq_id = (seq_id) => ('instance-seq-' + seq_id)
onMounted(() => {
  let svg_id = ins_seq_id(props.seq_id)
  d3.select('#'+svg_id).selectAll('*').remove()
  if (props.show_state == 'loc') drawInstanceSeq_loc()
  else if (props.show_state == 'space') drawInstanceSeq_space()

  $('#hide-feat-button').on('click', () => {
    d3.selectAll('.feature-seq').selectAll('*').remove()
    inforStore.loc_feature_conditions = {
      'loc_id': -1,
      'stamp_id': -1,
      'seq_id': -1,
      'step_id': -1,
      'pred_num': 0
    }
  })
})

onUpdated(() => {
  let svg_id = ins_seq_id(props.seq_id)
  d3.select('#'+svg_id).selectAll('*').remove()
  if (props.show_state == 'loc') drawInstanceSeq_loc()
  else if (props.show_state == 'space') drawInstanceSeq_space()
  
  $('#hide-feat-button').on('click', () => {
    d3.selectAll('.feature-seq').selectAll('*').remove()
    inforStore.loc_feature_conditions = {
      'loc_id': -1,
      'stamp_id': -1,
      'seq_id': -1,
      'step_id': -1,
      'pred_num': 0
    }
  })
})

function drawInstanceSeq_loc () {
  let svg_id = ins_seq_id(props.seq_id)
  let ins_seq_svg = d3.select('#'+svg_id)
  let margin_left = 5, margin_right = 5, margin_top = 5, margin_bottom = 5
  let main_w = 900, main_h = 100
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  ins_seq_svg
    .attr('width', svg_w)
    .attr('height', svg_h)
  let input_seq_g = ins_seq_svg.append('g')
  let output_g = ins_seq_svg.append('g')
}

function drawInstanceSeq_space () {
  let svg_id = ins_seq_id(props.seq_id)
  let ins_seq_svg = d3.select('#'+svg_id)
  ins_seq_svg.selectAll('*').remove()
  let margin_left = 5, margin_right = 5, margin_top = 1, margin_bottom = 1
  let main_w = 1512, main_h = 55
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let cell_w = 55, cell_h = 55
  ins_seq_svg
    .attr('width', svg_w)
    .attr('height', svg_h)
  let input_cells_data = inforStore.cur_instance_seqs.instance_seqs_space[props.seq_id]
  let input_len = input_cells_data.length
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let white_rate = 0.08
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_x), Math.max(...loc_coords_x)])
        .range([cell_w*(white_rate), cell_w*(1-white_rate)])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_y), Math.max(...loc_coords_y)])
        .range([cell_h*(1-white_rate), cell_h*white_rate])
  let valColor = d3.scaleLinear()
    .domain([0, inforStore.cur_instance_seqs.val_range[1]])
    .range(['#efedf5', '#4a1486'])
  if (props.seq_id == 0) {
    d3.select('#seq-head-col').selectAll('*').remove()
    let header_svg = d3.select('#seq-head-col')
      .attr('width', svg_w)
      .attr('height', 19)
    let input_label_g = header_svg.append('g')
    input_label_g.selectAll('text')
      .data(input_cells_data)
      .join('text')
        .attr('x', (d,i) => (i*(cell_w+3) + cell_w/2))
        .attr('y', 14)
        .attr('text-anchor', 'middle')
        .attr('fill', '#333')
        .style('font-size', '12px')
        .style('font-family', "Arial")
        .style('font-weight', 700)
        .text((d,i) => `Input ${i+1}`)
    let out_pred_x = input_len*(cell_w+3) + 12
    let out_truth_x = out_pred_x + cell_w + 3
    header_svg.append('text')
      .attr('x', out_pred_x + cell_w/2)
      .attr('y', 14)
      .attr('text-anchor', 'middle')
      .attr('fill', '#333')
      .style('font-size', '12px')
      .style('font-family', "Arial")
      .style('font-weight', 700)
      .text('Prediction')
    header_svg.append('text')
      .attr('x', out_truth_x + cell_w/2)
      .attr('y', 14)
      .attr('text-anchor', 'middle')
      .attr('fill', '#333')
      .style('font-size', '12px')
      .style('font-family', "Arial")
      .style('font-weight', 700)
      .text('Truth')
    d3.select('#truth-seq').selectAll('*').remove()
    // let truth_seq_svg = d3.select('#truth-seq')
    //   .attr('width', svg_w)
    //   .attr('height', svg_h)
    // let truth_seq_g = truth_seq_svg.append('g')
    //   .attr('transform', `translate(70, ${margin_top})`)
    // let truth_seq_data = inforStore.cur_instance_seqs.truth_seq_space
    // let truth_cells = truth_seq_g.selectAll('g')
    //   .data(truth_seq_data)
    //   .join('g')
    //     .attr('transform', (d,i) => `translate(${i*(cell_w+3)}, 0)`)
    // truth_cells.selectAll('circle')
    //   .data(d => d)
    //   .join('circle')
    //     .attr('cx', (d,i) => loc_x_scale(loc_coords_x[i]))
    //     .attr('cy', (d,i) => loc_y_scale(loc_coords_y[i]))
    //     .attr('r', 1.5)
    //     .attr('fill', (d,i) => valColor(d))
    // truth_cells.append('rect')
    //   .attr('x', loc_x_scale(loc_coords_x[inforStore.cur_sel_condition.loc_id])-2)
    //   .attr('y', loc_y_scale(loc_coords_y[inforStore.cur_sel_condition.loc_id])-2)
    //   .attr('width', 4)
    //   .attr('height', 4)
    //   .attr('fill', (d,i) => valColor(truth_seq_data[i][inforStore.cur_sel_condition.loc_id]))
    //   .attr('stroke', 'none') 
  }
  let input_seq_g = ins_seq_svg.append('g')
    .attr('transform', `translate(0, ${margin_top})`)
  let output_g = ins_seq_svg.append('g')
    .attr('transform', `translate(0, ${margin_top})`)
  let resiColorScale = d3.scaleSequential(d3.interpolateRdBu)
    .domain(inforStore.tile_resi_edge_range)
  let input_cells = input_seq_g.selectAll('g')
    .data(input_cells_data)
    .join('g')
      .attr('class', 'input-cell')
      .attr('step_id', (d,i) => i)
      .attr('transform', (d,i) => `translate(${i*(cell_w+3)}, 0)`)
  let pred_len = props.seq_id + (inforStore.cur_data_infor.time.output_window - props.seq_num)
  let truth_len = inforStore.cur_data_infor.time.input_window - pred_len
  input_cells.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', cell_w).attr('height', cell_h)
    .attr('fill', 'none')
    .attr('stroke-dasharray', (d,i) => {
      if (i < truth_len) return 'none'
      else return '5,5'
    })
    .attr('stroke-width', (d,i) => {
      if (i < truth_len) return 1.0
      else return 2.0
    })
    .attr('stroke', (d,i) => {
      if (i < truth_len) return '#bababa'
      else {
        let cur_loc_truth = inforStore.cur_instance_seqs.truth_seq_space[i][inforStore.cur_sel_condition.loc_id]
        let cur_loc_residual = d[inforStore.cur_sel_condition.loc_id] - cur_loc_truth
        return resiColorScale(cur_loc_residual)
      }
    })
  // let colormap = d3.scaleLinear()
  //   .domain([0, 1])
  //   .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length  -1]])
  input_cells.selectAll('circle')
    .data(d => d)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(loc_coords_y[i]))
      .attr('loc_id', (d,i) => i)
      .attr('r', 1.5)
      .attr('fill', (d,i) => valColor(d))
      .attr('stroke', (d,i) => {
        if (props.seq_id == inforStore.loc_feature_conditions.seq_id && i == inforStore.loc_feature_conditions.loc_id) return '#333'
        else return 'none'
      })
      .style('cursor', 'pointer')
      .on('click', (e) => {
        let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
        let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
        inforStore.loc_feature_conditions.step_id = step_id
        inforStore.loc_feature_conditions.loc_id = loc_id
        inforStore.loc_feature_conditions.stamp_id = props.stamp_id
        inforStore.loc_feature_conditions.seq_id = props.seq_id
        inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
        getData(inforStore, 'loc_features', loc_id, props.stamp_id)
        d3.select(e.target).attr('stroke', '#333')
      })
      // .attr('stroke', (d,i) => {
      //   if (i == inforStore.cur_sel_condition.loc_id) return '#333'
      //   else return 'none'
      // })
      // .attr('stroke-width', 0.5)
  input_cells.append('rect')
    .attr('x', loc_x_scale(loc_coords_x[inforStore.cur_sel_condition.loc_id])-2)
    .attr('y', loc_y_scale(loc_coords_y[inforStore.cur_sel_condition.loc_id])-2)
    .attr('width', 4)
    .attr('height', 4)
    .attr('fill', (d,i) => valColor(input_cells_data[i][inforStore.cur_sel_condition.loc_id]))
    .attr('stroke', (d,i) => {
      if (props.seq_id == inforStore.loc_feature_conditions.seq_id && inforStore.cur_sel_condition.loc_id == inforStore.loc_feature_conditions.loc_id) return '#333'
      else return 'none'
    })
    .style('cursor', 'pointer')
    .attr('loc_id', inforStore.cur_sel_condition.loc_id)
    .on('click', e => {
      let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
      let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
      inforStore.loc_feature_conditions.step_id = step_id
      inforStore.loc_feature_conditions.loc_id = loc_id
      inforStore.loc_feature_conditions.stamp_id = props.stamp_id
      inforStore.loc_feature_conditions.seq_id = props.seq_id
      inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
      getData(inforStore, 'loc_features', loc_id, props.stamp_id)
      d3.select(e.target).attr('stroke', '#333')
    })
  let seg_line_x = input_len*(cell_w+3) + 5
  ins_seq_svg.append('line')
    .attr('x1', seg_line_x)
    .attr('x2', seg_line_x)
    .attr('y1', 0)
    .attr('y1', cell_h)
    .attr('stroke', '#999')
    .attr('stroke-dasharray', '5,5')
  
  let output_pred_steps_space = inforStore.cur_instance_seqs.output_pred_steps_space.map(item => item[props.seq_id])
  let output_truth_steps_space = inforStore.cur_instance_seqs.output_truth_steps_space.map(item => item[props.seq_id])
  let output_pred_cell = output_g.append('g')
    .attr('transform', `translate(${seg_line_x+7}, 0)`)
    .attr('step_id', inforStore.cur_data_infor.time.input_window)
  output_pred_cell.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', cell_w).attr('height', cell_h)
    .attr('fill', 'none')
    .attr('stroke', () => {
      return resiColorScale(output_pred_steps_space[inforStore.cur_sel_condition.loc_id] - output_truth_steps_space[inforStore.cur_sel_condition.loc_id])
    })
    .attr('stroke-dasharray', '5,5')
    .attr('stroke-width', 2)
  output_pred_cell.selectAll('circle')
    .data(output_pred_steps_space)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(loc_coords_y[i]))
      .attr('r', 1.5)
      .attr('fill', (d,i) => valColor(d))
      .attr('stroke', (d,i) => {
        if (props.seq_id == inforStore.loc_feature_conditions.seq_id && i == inforStore.loc_feature_conditions.loc_id) return '#333'
        else return 'none'
      })
      .attr('loc_id', (d,i) => i)
      .style('cursor', 'pointer')
      .on('click', e => {
        let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
        let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
        inforStore.loc_feature_conditions.step_id = step_id
        inforStore.loc_feature_conditions.loc_id = loc_id
        inforStore.loc_feature_conditions.stamp_id = props.stamp_id
        inforStore.loc_feature_conditions.seq_id = props.seq_id
        inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
        getData(inforStore, 'loc_features', loc_id, props.stamp_id)
        d3.select(e.target).attr('stroke', '#333')
      })

  output_pred_cell.append('rect')
    .attr('x', loc_x_scale(loc_coords_x[inforStore.cur_sel_condition.loc_id])-2)
    .attr('y', loc_y_scale(loc_coords_y[inforStore.cur_sel_condition.loc_id])-2)
    .attr('width', 4)
    .attr('height', 4)
    .attr('fill', (d,i) => valColor(output_pred_steps_space[inforStore.cur_sel_condition.loc_id]))
    .attr('stroke', (d,i) => {
      if (props.seq_id == inforStore.loc_feature_conditions.seq_id && inforStore.cur_sel_condition.loc_id == inforStore.loc_feature_conditions.loc_id) return '#333'
      else return 'none'
    })
    .attr('loc_id', inforStore.cur_sel_condition.loc_id)
    .style('cursor', 'pointer')
    .on('click', e => {
      let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
      let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
      inforStore.loc_feature_conditions.step_id = step_id
      inforStore.loc_feature_conditions.loc_id = loc_id
      inforStore.loc_feature_conditions.stamp_id = props.stamp_id
      inforStore.loc_feature_conditions.seq_id = props.seq_id
      inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
      getData(inforStore, 'loc_features', loc_id, props.stamp_id)
      d3.select(e.target).attr('stroke', '#333')
    })
  let output_truth_cell = output_g.append('g')
    .attr('transform', `translate(${seg_line_x+7+(cell_w+3)}, 0)`)
    .attr('step_id', inforStore.cur_data_infor.time.input_window)
  output_truth_cell.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', cell_w).attr('height', cell_h)
    .attr('fill', 'none')
    .attr('stroke', '#bababa')
  output_truth_cell.selectAll('circle')
    .data(output_truth_steps_space)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(loc_coords_y[i]))
      .attr('r', 1.5)
      .attr('fill', (d,i) => valColor(d))
      .attr('loc_id', (d,i) => i)
      .attr('stroke', (d,i) => {
        if (props.seq_id == inforStore.loc_feature_conditions.seq_id && i == inforStore.loc_feature_conditions.loc_id) return '#333'
        else return 'none'
      })
      .style('cursor', 'pointer')
      .on('click', e => {
        let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
        let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
        inforStore.loc_feature_conditions.step_id = step_id
        inforStore.loc_feature_conditions.loc_id = loc_id
        inforStore.loc_feature_conditions.stamp_id = props.stamp_id
        inforStore.loc_feature_conditions.seq_id = props.seq_id
        inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
        getData(inforStore, 'loc_features', loc_id, props.stamp_id)
        d3.select(e.target).attr('stroke', '#333')
      })

  output_truth_cell.append('rect')
    .attr('x', loc_x_scale(loc_coords_x[inforStore.cur_sel_condition.loc_id])-2)
    .attr('y', loc_y_scale(loc_coords_y[inforStore.cur_sel_condition.loc_id])-2)
    .attr('width', 4)
    .attr('height', 4)
    .attr('fill', (d,i) => valColor(output_truth_steps_space[inforStore.cur_sel_condition.loc_id]))
    .attr('stroke', (d) => {
      if (props.seq_id == inforStore.loc_feature_conditions.seq_id && inforStore.cur_sel_condition.loc_id == inforStore.loc_feature_conditions.loc_id) return '#333'
      else return 'none'
    })
    .attr('loc_id', inforStore.cur_sel_condition.loc_id)
    .style('cursor', 'pointer')
    .on('click', e => {
      let loc_id = parseInt(d3.select(e.target).attr('loc_id'))
      let step_id = d3.select(e.target).node().parentNode.getAttribute('step_id')
      inforStore.loc_feature_conditions.step_id = step_id
      inforStore.loc_feature_conditions.loc_id = loc_id
      inforStore.loc_feature_conditions.stamp_id = props.stamp_id
      inforStore.loc_feature_conditions.seq_id = props.seq_id
      inforStore.loc_feature_conditions.pred_num = inforStore.cur_data_infor.time.output_window - props.seq_num + props.seq_id
      getData(inforStore, 'loc_features', loc_id, props.stamp_id)
      d3.select(e.target).attr('stroke', '#333')
    })
}

</script>

<template>
  <!-- 每个属性包含一个分布视图、 树视图，做成卡片-->
  <div v-if="seq_id == 0">
    <svg id="seq-head-col"></svg>
    <!-- <div class="input-col-header">
      <span v-for="(item, index) in inforStore.cur_instance_seqs.instance_seqs_space[props.seq_id]" :key="index">input {{ index+1 }}</span>
    </div> -->
    <!-- <svg id="truth-seq"></svg> -->
  </div>
  <div class="instance-seq">
    <div class="seq-head-row" :style="{'font-weight': step_flag ? 700: 400}">Forecast<br/>Step: {{ seq_id+1 }}</div>
    <svg class="ins-seq" :id="ins_seq_id(seq_id)"></svg>
  </div>
  <div class="feat-block" v-if="inforStore.loc_feature_conditions.seq_id == seq_id">
    <FeatureSeq v-for="(value, key, index) in inforStore.cur_loc_features" :key="index" :feature_id="index" :feature_str="key" :feature_data="value" :feature_conditions="inforStore.loc_feature_conditions" :all_features="show_features" />
    <div id="hide-feat-button">Hide Features View</div>
  </div>

</template>

<style scoped>
.instance-seq {
  margin-left: 5px;
  margin-top: 2px;
  display: flex;
  align-items: center;
  text-align: center;
  line-height: 14px;
}
.ins-seq {
  margin-left: 3px;
}

.seq-head-row {
  width: 60px !important;
  font-size: 12px;
  color: #333;
}

#seq-head-col {
  display: block;
  margin-left: 67px;
}

.feat-block {
  margin-left: 20px;
  /* width: 1600px; */
  display: flex;
  /* justify-content: space-around; */
  align-items: end;
  flex-wrap: wrap;
  margin-top: 5px;
  margin-bottom: 10px;
}

#hide-feat-button {
  font: 700 16px "Arial";
  margin-left: 30px;
  text-decoration-line: underline;
  color: #999;
  font-style: italic;
}

#hide-feat-button:hover {
  color: #1a73e8;
  cursor: pointer;
}
</style>