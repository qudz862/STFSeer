<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'
import InstanceSeq from './InstanceSeq.vue'
import InstancePCP from './InstancePCP.vue'
import ErrorTile from './ErrorTile.vue'

const inforStore = useInforStore()

function closePopup() {
  // inforStore.cur_sel_stamp_objs = {}
  // d3.select('#ins-pcp-svg').selectAll('*').remove()
  inforStore.cur_instance_seqs = {}
  // d3.selectAll('.err-tile-box').selectAll('*').remove()
  // d3.selectAll('.instance-seq').selectAll('*').remove()
  cur_sel_stamp.value = -1
  d3.selectAll('.feature-seq').selectAll('*').remove()
  inforStore.loc_feature_conditions = {
    'loc_id': -1,
    'stamp_id': -1,
    'seq_id': -1,
    'step_id': -1,
    'pred_num': 0
  }
  $('.overlay-container').css('display', 'none')
}

let show_states = ref([])
// let global_resi_edge_range = ref([0, 0])

watch (() => inforStore.cur_instance_seqs, (oldVlaue, newValue) => {
  // console.log(inforStore.cur_instance_seqs);
  if (Object.keys(inforStore.cur_instance_seqs).length !== 0) {
    show_states.value = new Array(inforStore.cur_instance_seqs.instance_seqs.length).fill('space')
    drawErrLegend()
  }
})

watch (() => inforStore.cur_sel_stamp_objs, (oldVlaue, newValue) => {
  // console.log(inforStore.cur_instance_details);
  let global_resi_edge = 0
  for (let stamp_id in inforStore.cur_instance_details.timestamp_objs) {
    let timestamp_obj = inforStore.cur_instance_details.timestamp_objs[stamp_id]
    let resi_seq = timestamp_obj.residual
    let cur_resi_pos_edge = d3.max(resi_seq)
    let cur_resi_neg_edge = d3.min(resi_seq)
    if (Math.abs(cur_resi_pos_edge) > global_resi_edge) global_resi_edge = cur_resi_pos_edge
    if (Math.abs(cur_resi_neg_edge) > global_resi_edge) global_resi_edge = Math.abs(cur_resi_neg_edge)
  }
  inforStore.tile_resi_edge_range = [-global_resi_edge, global_resi_edge]
})

const cur_sel_stamp = ref(-1)
const cur_sel_stamp_key = ref('')

const onTileClick = (index, key) => {
  if (index == cur_sel_stamp.value) {
    cur_sel_stamp.value = -1
    cur_sel_stamp_key.value = ''
  } else {
    cur_sel_stamp.value = index
    cur_sel_stamp_key.value = key
    // let cur_stamp_ids = Object.keys(inforStore.cur_sel_stamp_objs)
    getData(inforStore, 'instance_seqs', key, inforStore.cur_sel_condition.loc_id)
  }
  d3.selectAll('.feature-seq').selectAll('*').remove()
  inforStore.loc_feature_conditions = {
    'loc_id': -1,
    'stamp_id': -1,
    'seq_id': -1,
    'step_id': -1,
    'pred_num': 0
  }
}

watch (() => cur_sel_stamp.value, (oldVlaue, newValue) => {
  $('.err-tile-box').css('border-color', '#999')
  $('.err-tile-box').css('border-width', 1)
  if (cur_sel_stamp.value == -1) {
    inforStore.cur_instance_seqs.instance_seqs = []
  }
  if (cur_sel_stamp.value != -1) {
    $(`.err-tile-box:eq(${cur_sel_stamp.value})`).css('border-color', valColorScheme_blue[3])
    $(`.err-tile-box:eq(${cur_sel_stamp.value})`).css('border-width', 2)
  }
})

function getStepFlag (index) {
  if (cur_sel_stamp.value == -1) return false
  let steps = inforStore.cur_sel_stamp_objs[cur_sel_stamp_key.value].fore_step
  if (steps.includes(index)) return true
  else return false
}

function drawErrLegend() {
  d3.select('#pollution-val-legend').selectAll('*').remove()
  let margin_left = 20, margin_right = 40, margin_top = 0, margin_bottom = 0
  let main_w = 120, main_h = 12
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legend_svg = d3.select('#pollution-val-legend')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legend = legend_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let legendScale = d3.scaleLinear()
    .domain([0, main_w])
    .range(['#fff', '#4a1486'])
  legend.selectAll('rect')
    .data(Array(main_w).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => legendScale(i))
  legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  legend.append('text')
    .attr('x', main_w+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${inforStore.cur_instance_seqs.val_range[1]}`)
}
</script>

<template>
  <div class="overlay-container">
    <div class="center-popup">
      <div class="title-layer">
        <div class="title">Instance Details</div>
        <div class="infor-header">
          <span class="header-attr"><span class="attr-title">Location ID: </span><span class="attr-val">{{ inforStore.cur_sel_condition.loc_id }}</span></span>
          <span v-if="inforStore.ins_inspect_type == 'subset'" class="header-attr"><span class="attr-title">X Axis Condition: </span><span class="attr-val">{{ inforStore.cur_sel_condition.x_condition }}</span></span>
          <span v-if="inforStore.ins_inspect_type == 'subset'" class="header-attr"><span class="attr-title">Y Axis Condition: </span><span class="attr-val">{{ inforStore.cur_sel_condition.y_condition }}</span></span>
          <div class="header-attr">
            <span class="attr-title">Pollution Value: </span><svg class="phase-legend" id="pollution-val-legend" width="10" height="10"></svg>
          </div>
        </div>
        <div class="iconfont" id="close-icon" @click="closePopup()">&#xe620;</div>
      </div>
      <div>
        <div v-if="inforStore.ins_inspect_type == 'subset'" class="instance-pcp-block">
          <InstancePCP />
        </div>
        <div v-if="inforStore.ins_inspect_type == 'subset'" class="tiles-block">
          <ErrorTile v-for="(value, key, index) in inforStore.cur_sel_stamp_objs" :key="key" :stamp_id="key" :stamp_obj="value" :err_range="inforStore.tile_resi_edge_range" :cur_index="index" @click="onTileClick(index, key)"/>
        </div>
        <div v-if="inforStore.ins_inspect_type == 'phase'" class="tiles-block">
          <ErrorTile v-for="(value, key, index) in inforStore.cur_sel_stamp_objs_single" :key="key" :stamp_id="key" :stamp_obj="value" :err_range="inforStore.tile_resi_edge_range" :cur_index="index" @click="onTileClick(index, key)"/>
        </div>
        <div class="ins-seq-block">
          <InstanceSeq v-for="(item, index) in inforStore.cur_instance_seqs.instance_seqs" :key="index" :show_state="show_states[index]" :seq_data="item" :seq_id="index" :stamp_id="inforStore.cur_instance_seqs.stamp_id" :seq_num="inforStore.cur_instance_seqs.instance_seqs.length" :step_flag="getStepFlag(index)"/>
          <!-- <InstanceSeq v-for="(item, index) in inforStore.cur_instance_seqs.instance_seqs" :key="index" :show_state="show_states[index]" :seq_data="item" :update_val="inforStore.cur_instance_seqs.output_pred_steps[0]" :seq_id="index" :stamp_id="cur_sel_stamp" /> -->
        </div>
      </div>
    </div>
  </div>

</template>

<style scoped>
.overlay-container {
  display: none;
  justify-content: center;
  align-items: center;
  position: fixed;
  width: 100%;
  height: 100%;
}

.center-popup {
  width: 1610px;
  height: 1071px;
  background-color: #fff;
  border: solid 1px #999;
  border-radius: 6px;
  z-index: 999999 !important;
  margin-left: 300px;
  /* overflow-y: scroll; */
}

.title-layer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: -4px;
}

.title {
  /* position: absolute; */
  z-index: 80;
  width: 220px;
  height: 20px;
  text-align: left;
  padding-left: 10px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-attr {
  margin-right: 30px;
}

#close-icon {
  /* margin-top: 2px; */
  margin-right: 10px;
  font-size: 24px;
  color: #999;
}
#close-icon:hover {
    color: #333;
    cursor: pointer;
}

.infor-header {
  display: flex;
  /* justify-content: space-around; */
  align-items: center;
  width: 1460px;
}

.tiles-block {
  width: 1600px;
  height: 78px;
  display: flex;
  /* justify-content: space-between; */
  align-items: center;
  flex-wrap: wrap;
  padding-left: 4px;
  padding-right: 4px;
  font-size: 11px;
  overflow-y: scroll;
}

.attr-title {
  font-weight: 700;
}
.attr-val {
  color: #1a73e8;
}

.ins-seq-block {
  width: 1600px;
  height: 728px;
  overflow-y: scroll;
}
</style>