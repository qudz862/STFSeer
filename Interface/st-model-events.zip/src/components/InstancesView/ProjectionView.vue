<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'
import {lasso} from "d3-lasso"

const inforStore = useInforStore()

let dr_method = ref('MDS')
let cur_point_color_attr = ref('time-id')
let point_color_attrs = ref(['time-id', 'failure num'])

const instance_proj = ref({
  width: 240,
  height: 240
})

let selectedDots = []
let lasso_func, zoom_func
let lasso_flag = ref(false)

let proj_svg, instance_g, circles
let scale_x, scale_y

function draw_instance_proj() {
  d3.selectAll("#instance-proj-view").selectAll('*').remove()
  proj_svg = d3.select('#instance-proj-view')
  instance_g = proj_svg.append('g').attr('id', 'instance-g')
  let instance_locs = inforStore.cur_data_items.reduced_data
  let item_failure_cnts = inforStore.cur_data_items.item_failure_num
  let instance_locs_x = instance_locs.map(item => item[0])
  let instance_locs_y = instance_locs.map(item => item[1])
  scale_x = d3.scaleLinear()
    .domain([d3.min(instance_locs_x), d3.max(instance_locs_x)])
    .range([0.1 * instance_proj.value.width, 0.9 * instance_proj.value.width])
  scale_y = d3.scaleLinear()
    .domain([d3.min(instance_locs_y), d3.max(instance_locs_y)])
    .range([0.9 * instance_proj.value.height, 0.1 * instance_proj.value.height])
  let failure_scale = d3.scaleLinear()
    .domain([d3.min(item_failure_cnts), d3.max(item_failure_cnts)])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
  let time_scale = d3.scaleLinear()
    .domain([0, item_failure_cnts.length])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
  circles = instance_g.selectAll('circle')
    .data(instance_locs)
    .join('circle')
      .attr("id", (d,i) => "dot-" + i.toString())
      .attr('cx', (d,i) => scale_x(instance_locs_x[i]))
      .attr('cy', (d,i) => scale_y(instance_locs_y[i]))
      .attr('r', 1)
      .attr('stroke', 'red')
      .attr('stroke-width', 0)
      // .attr('fill', (d,i) => failure_scale(item_failure_cnts[i]))
      .attr('fill', (d,i) => {
        if (cur_point_color_attr.value == 'time-id')
          return time_scale(i)
        else if (cur_point_color_attr.value == 'failure num')
          return failure_scale(item_failure_cnts[i])
      })
      .attr('opacity', 0.5)
  
  zoom_func = add_proj_zoom()
  proj_svg.call(zoom_func)
}

function add_proj_zoom() {
  let zoom = d3.zoom()
	  .on('zoom', handleZoom);
  function handleZoom(e) {    
    instance_g.attr('transform', e.transform)
  }
  return zoom
}

function add_proj_lasso_plugin(proj_svg) {
  const proj_lasso = lasso()
    .closePathSelect(true)
    .closePathDistance(100)
    .items(proj_svg.selectAll("circle"))
    .targetArea(proj_svg);
  // Define event handlers
  proj_lasso.on("start", () => {
    proj_lasso.items()
      .attr("r", 1)
      .classed("selected", false);
  });

  proj_lasso.on("draw", () => {
    proj_lasso.items().filter(lasso.selected())
      .attr("r", 1.5)
      .classed("selected", true);
  });

  proj_lasso.on("end", () => {
    proj_lasso.items().filter(lasso.notSelected())
      .attr("r", 1)
      .classed("selected", false);
  });

  // Call lasso on the SVG element
  proj_svg.call(proj_lasso);
}

function add_proj_lasso(xScale, yScale) {
  // lasso selection based on the drag events
  let coords = [];
  const lineGenerator = d3.line();

  const pointInPolygon = function (point, vs) {
      // console.log(point, vs);
      // ray-casting algorithm based on
      // https://wrf.ecse.rpi.edu/Research/Short_Notes/pnpoly.html/pnpoly.html

      var x = point[0],
          y = point[1];

      var inside = false;
      for (var i = 0, j = vs.length - 1; i < vs.length; j = i++) {
          var xi = vs[i][0],
              yi = vs[i][1];
          var xj = vs[j][0],
              yj = vs[j][1];

          var intersect =
              yi > y != yj > y &&
              x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
          if (intersect) inside = !inside;
      }

      return inside;
  };

  function drawPath() {
      d3.select("#lasso")
          .style("stroke", "black")
          .style("stroke-width", 0.7)
          .style("fill", "#cecece54")
          .attr("d", lineGenerator(coords));
  }

  function dragStart() {
    coords = [];
    circles.attr("stroke-width", 0);
    d3.select("#lasso").remove();
    selectedDots = [];
    d3.select("#instance-proj-view")
        .append("path")
        .attr("id", "lasso");
  }

  function dragMove(event) {
    let mouseX = event.sourceEvent.offsetX;
    let mouseY = event.sourceEvent.offsetY;
    coords.push([mouseX, mouseY]);
    drawPath();
  }

  function dragEnd() {
    let tmp_selectedDots = [];
    let transformMatrix = d3.zoomTransform(d3.select('#instance-g').node());
    circles.each((d, i) => {
      // 原始坐标
      const originalX = xScale(d[0]);
      const originalY = yScale(d[1]);
      // 应用变换矩阵以获取变换后的坐标
      const transformedX = (originalX) * transformMatrix.k + transformMatrix.x
      const transformedY = (originalY) * transformMatrix.k + transformMatrix.y
      let point = [
        transformedX,
        transformedY
      ];
      if (pointInPolygon(point, coords)) {
          d3.select("#dot-" + i.toString()).attr("stroke-width", 1);
          tmp_selectedDots.push(i);
      }
    });
    selectedDots = tmp_selectedDots
  }

  const drag = d3
      .drag()
      .on("start", dragStart)
      .on("drag", dragMove)
      .on("end", dragEnd);

  // d3.select("#instance-proj-view").call(drag);
  return drag
}

watch (() => inforStore.cur_data_items, (oldVlaue, newValue) => {
  draw_instance_proj()
})

watch (() => cur_point_color_attr.value, (oldVlaue, newValue) => {
  draw_instance_proj()
})

const on_lasso_mode = () => {
  lasso_flag.value = !lasso_flag.value
  if (lasso_flag.value) {
    lasso_func = add_proj_lasso(scale_x, scale_y)
    d3.select('#instance-proj-view').call(lasso_func)
    d3.select('#instance-proj-view').on(".zoom", null);
  } else {
    d3.select('#instance-proj-view').on('mousedown.drag', null);
    d3.select('#instance-proj-view').call(zoom_func)
  }
    
}

const onColorAttrClick = item => {
  cur_point_color_attr.value = item
}

</script>

<template>
  <div class="projection-container">
    <div>
      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_point_color_attr }}</button>
      <ul class="dropdown-menu" id="dropdown-choose-task">
        <!-- <li @click="onDataCardClick(-1)" class='dropdown-item'>
            <div class="li-data-name">Choose inspected data</div>
        </li> -->
        <li v-for="(item, index) in point_color_attrs" :value="item" @click="onColorAttrClick(item)" :key="index" class='dropdown-item'>
          <div class="li-data-name">{{ item }}</div>
        </li>
      </ul>
    </div>
    <svg id='instance-proj-view' shape-rendering="geometricPrecision" :width="instance_proj.width" :height="instance_proj.height"></svg>
    <button @click="on_lasso_mode">Lasso</button>
  </div>
</template>

<style scoped>
.dropdown-toggle {
  width: 64px !important;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.4em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

</style>