<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

import ProjectionView from './ProjectionView.vue'

const inforStore = useInforStore()

const dr_methods = ref(['MDS', 't-SNE', 'UMAP'])
let cur_dr_method = ref('MDS')

const get_instances = () => {
  getData(inforStore, 'data_items', cur_dr_method.value)
}

// watch (() => inforStore.cur_data_items, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_data_items);
// })

const onDrMethodClick = item => {
  cur_dr_method.value = item
  getData(inforStore, 'data_items', cur_dr_method.value)
}

</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      Instances View
      <div>
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_dr_method }}</button>
        <ul class="dropdown-menu" id="dropdown-choose-task">
          <!-- <li @click="onDataCardClick(-1)" class='dropdown-item'>
              <div class="li-data-name">Choose inspected data</div>
          </li> -->
          <li v-for="(item, index) in dr_methods" :value="item" @click="onDrMethodClick(item)" class='dropdown-item'>
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div>
      <span id="get-instance-button" @click="get_instances()">Get instances</span>
    </div>
    <ProjectionView />
  </div>
</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 860px;
  height: 346px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 320px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

#get-instance-button {
  font-size: 14px;
  font-weight: 700;
  color: #999;
  text-decoration: underline;
}

#get-instance-button:hover {
  color: #1a73e8;
  cursor: pointer;
}

.dropdown-toggle {
  width: 64px !important;
  /* width: 120px; */
  padding: 0px 2px 0 4px !important;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.4em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 480px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}
</style>