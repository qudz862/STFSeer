<script setup>
import { ref, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

</script>

<template>
  <div class="legend_row">

    
  </div>
</template>

<style scoped>
.legend_row {
  height: 30px;
  /* background-color: aquamarine; */
  border-bottom: solid 1px #cecece;
}
</style>