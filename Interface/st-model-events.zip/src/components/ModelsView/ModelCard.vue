<script setup>
import { ref, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const props = defineProps({
  range_index: Number,
  model_index: Number,
  model_name: String,
  err_hist_max_cnt: Number
})

let model_type = ref(props.model_name.split('-')[0])

let hits_color = ref('#4292c6')
let misses_color = ref('#bcbcbc')

const view_id = (view_str, range_i, model_i) => {
  return view_str + '-' + range_i.toString() + '-' + model_i.toString()
}

const inforStore = useInforStore()
let err_indicators = inforStore.cur_model_infor[props.range_index][props.model_name].error_indicators
let failure_indicators = inforStore.cur_model_infor[props.range_index][props.model_name].failure_indicators

let err_dis_width = ref(90)
let err_dis_height = ref(64)

let err_dis_svg

onMounted(() => {
  let err_dis_svg_id = '#' + view_id('err-dis', props.range_index, props.model_index)
  d3.selectAll(err_dis_svg_id).selectAll('*').remove()
  err_dis_svg = d3.select(err_dis_svg_id)
  drawErrorDisPlot(err_dis_svg)
})

function drawErrorDisPlot(error_dis_view) {
  let err_th = inforStore.cur_sel_failure_rules[props.range_index].err_th
  // console.log(err_th)
  const err_histogram = d3.bin()
    .domain([-err_th, err_th])
    .thresholds(100)
  const err_bins = err_indicators.all_error_bins
  const err_bins_cnt = err_indicators.all_error_hist

  let top_white_rate = 0.05
  let fail_part_rate = 0.12
  let hist_h_rate = 0.76
  let text_h_rate = 0.94
  let scale_x = d3.scaleLinear()
    .domain([-err_th, err_th])
    .range([fail_part_rate * err_dis_width.value, (1-fail_part_rate) * err_dis_width.value])
  let hist_scale_y = d3.scaleLinear()
    .domain([0, props.err_hist_max_cnt])
    .range([hist_h_rate * err_dis_height.value, top_white_rate * err_dis_height.value])
  let hist_plot = error_dis_view.append('g').attr('class', 'hist-plot')
  let axis_x = d3.axisBottom(scale_x)
  let axis_y = d3.axisLeft(hist_scale_y)

  let hist_area = d3.area()
      .curve(d3.curveMonotoneX)
      .x((d,index) => scale_x(err_bins[index]))
      .y0(hist_h_rate * err_dis_height.value)
      .y1((d,index) => hist_scale_y(d))
  let hist_line = d3.line()
      .curve(d3.curveMonotoneX)
      .x((d,index) => scale_x(err_bins[index]))
      .y((d,i) => hist_scale_y(d))
  hist_plot.append('path')
      .datum(err_bins_cnt)
      .attr("d", hist_area)
      .attr('fill', hits_color.value)
      .attr('opacity', 0.5)
  hist_plot.append('path')
      .datum(err_bins_cnt)
      .attr("d", hist_line)
      .attr('fill', 'none')
      .attr('stroke', '#2171b5')
      .attr('stroke-width', 0.5)
  
  hist_plot.append('line')
    .attr('x1', scale_x(0))
    .attr('x2', scale_x(0))
    .attr('y1', top_white_rate * err_dis_height.value)
    .attr('y2', hist_h_rate * err_dis_height.value)
    .attr('stroke', '#ef6548')
    .attr('stroke-width', 0.5)
    .attr('stroke-dasharray', '5,5')

  hist_plot.append('line')
    .attr('x1', scale_x(-err_th))
    .attr('x2', scale_x(-err_th))
    .attr('y1', top_white_rate * err_dis_height.value)
    .attr('y2', hist_h_rate * err_dis_height.value)
    .attr('stroke', '#ef6548')
    .attr('stroke-width', 0.5)
    .attr('stroke-dasharray', '5,5')
  hist_plot.append('line')
    .attr('x1', scale_x(err_th))
    .attr('x2', scale_x(err_th))
    .attr('y1', top_white_rate * err_dis_height.value)
    .attr('y2', hist_h_rate * err_dis_height.value)
    .attr('stroke', '#ef6548')
    .attr('stroke-width', 0.5)
    .attr('stroke-dasharray', '5,5')

  let neg_failures_num = failure_indicators.neg_failures_num
  let pos_failures_num = failure_indicators.pos_failures_num

  hist_plot.append('rect')
        .attr('x', 0)
        .attr('y', hist_scale_y(neg_failures_num))
        .attr('width', fail_part_rate * err_dis_width.value)
        .attr('height', hist_h_rate * err_dis_height.value - hist_scale_y(neg_failures_num))
        .attr('fill', misses_color.value)
    
  hist_plot.append('rect')
      .attr('x', (1-fail_part_rate) * err_dis_width.value)
      .attr('y', hist_scale_y(pos_failures_num))
      .attr('width', fail_part_rate * err_dis_width.value)
      .attr('height', hist_h_rate * err_dis_height.value - hist_scale_y(pos_failures_num))
      .attr('fill', misses_color.value)
  
  hist_plot.append('text')
      .attr('x', scale_x(0))
      .attr('y', text_h_rate * err_dis_height.value)
      .attr('text-anchor', 'middle')
      .style('font-size', '10px')
      .text('0')
  hist_plot.append('text')
      .attr('x', fail_part_rate * err_dis_width.value)
      .attr('y', text_h_rate * err_dis_height.value)
      .attr('text-anchor', 'middle')
      .style('font-size', '10px')  
      .text(() => (-inforStore.cur_sel_failure_rules[props.range_index].err_th).toString())
  hist_plot.append('text')
      .attr('x', (1-fail_part_rate) * err_dis_width.value)
      .attr('y', text_h_rate * err_dis_height.value)
      .attr('text-anchor', 'middle')
      .style('font-size', '10px')
      .text(() => (inforStore.cur_sel_failure_rules[props.range_index].err_th).toString())
}

</script>

<template>
  <div class="model-card">
    <div class="model-card-head">
      <div class="model-card-title">
        <span class="iconfont model-icon">&#xe612;</span>
        <Popper placement="right">
          <span class="model_name" :id="view_id('model-name', range_index, model_index)">{{ model_name }}</span>
          <template #content>
            <div class="model-tooltip-title">{{ model_name }}</div>
            <div>Year: <span class="model-tooltip-text">{{ inforStore.model_infor[model_type].Year }}</span></div>
            <div>Publication: <span class="model-tooltip-text">{{ inforStore.model_infor[model_type].Publication }}</span></div>
            <div>Introduction: <span class="model-tooltip-text">{{ inforStore.model_infor[model_type].Introduction }}</span></div>
            <div>Spatial_module: <span class="model-tooltip-text">{{ inforStore.model_infor[model_type].Modules.Spatial_module }}</span></div>
            <div>Temporal_module: <span class="model-tooltip-text">{{ inforStore.model_infor[model_type].Modules.Temporal_module }}</span></div>
          </template>
        </Popper>
        
      </div>
      <div class="model-card-control">control</div>
    </div>
    <div class="model-card-body">
      <div>

      </div>
      <div class="hits-misses-block">
        <div class="focus-indicators">
          <div>POD: {{ inforStore.cur_model_infor[range_index][model_name].failure_indicators.POD }}</div>
          <div class="hits-misses-line">
            <div class="hits-icon" :style="{backgroundColor: hits_color}"></div>
            <div>hits: {{ inforStore.cur_model_infor[range_index][model_name].failure_indicators.hits }}</div>
          </div>
          <div class="hits-misses-line">
            <div class="misses-icon" :style="{backgroundColor: misses_color}"></div>
            <div>misses: {{ inforStore.cur_model_infor[range_index][model_name].failure_indicators.misses }}</div>
          </div>
          <!-- <span>CSI: {{ inforStore.cur_model_infor[range_index][model_name].focus_indicators.CSI }}</span>
          <span>POD: {{ inforStore.cur_model_infor[range_index][model_name].focus_indicators.POD }}</span>
          <span>FAR: {{ inforStore.cur_model_infor[range_index][model_name].focus_indicators.FAR }}</span> -->
        </div>
        <div class="seg-line"></div>
        <svg :id="view_id('err-dis', range_index, model_index)" class="err-dis-view" :width='err_dis_width' :height='err_dis_height'></svg>
      </div>

    </div>
  </div>
  
  <!-- <div class="model-card">
    {{ model_name }}
  </div> -->
</template>

<style scoped>
.model-card {
  width: 220px;
  height: 114px;
  margin: 6px 6px;
  border: solid 1px #dcdee2;
  border-radius: 4px;
  font-size: 13px;
  -webkit-transition: all .2s ease-in-out;
  transition: all .2s ease-in-out;
}

.model-card:hover {
  border: solid 1px #bbb;
}

.model-card-head {
  height: 30px;
  border-bottom: solid 1px #dcdee2; 
  padding: 0 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.model-card-title {
  display: flex;
  align-items: center;
}

.model-icon {
  /* margin-right: 6px; */
  font-size: 22px;
  font-weight: 100;
}

.model_name {
  text-decoration-line: underline;
}

.model_name:hover {
  cursor: pointer;
  color: dodgerblue;
}

.hits-misses-block {
  display: flex;
  justify-content: space-around;
  align-items: center;
  height: 80px;
}

.hits-misses-line {
  display: flex;
  /* justify-content: center; */
  align-items: center;
}

.hits-icon,
.misses-icon {
  width: 10px;
  height: 10px;
  margin-right: 3px;
}

.focus-indicators {
  display: flex;
  flex-direction: column;
  justify-content: center;
  font-size: 12px;
  /* width: 100px; */
  /* border-right: solid 1px #cecece; */
}

.seg-line {
  height: 70px;
  width: 1px;
  background-color: #cecece;
}

.tooltip {
  background-color: #333;
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 13px;
  z-index: 1024;
}

.model-tooltip-title {
  font-weight: 700;
}

.model-tooltip-text {
  color: #1a73e8;
}

</style>