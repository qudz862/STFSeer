<script setup>
import { ref, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const props = defineProps({
  rule_num: Number,
  range_index: Number,
  loc_coords_x: Array,
  loc_coords_y: Array
})

let space_cnts_view = ref({
  width: 80,
  height: 80
})
let time_cnts_view = ref({
  width: 80,
  height: 80,
  innerRadius: 24,
  outerRadius: 36,
})

let range_num_view = ref({
  width: 10,
  height: 200,
  interval: 3
})

const inforStore = useInforStore()

const view_id = (view_str, range_i) => {
  return view_str + '-' + range_i.toString()
}

onMounted(() => {
  draw_range_space_dis()
  draw_range_time_dis()
  draw_range_num_dis()
})

const draw_range_num_dis = () => {
  let svg_id = '#' + view_id('range-num-dis', props.range_index)
  d3.selectAll(svg_id).selectAll('*').remove()
  let range_num_svg = d3.select(svg_id)
  let range_cnts = inforStore.cur_range_infor.range_cnts
  let range_cnts_scale = d3.scaleLinear()
    .domain([0, d3.sum(range_cnts)])
    .range([0, range_num_view.value.height - range_num_view.value.interval * (props.rule_num-1)])
  range_num_svg.selectAll('rect')
    .data(range_cnts)
    .join('rect')
      .attr('x', 0)
      .attr('y', (d,i) => {
        if (i == 0) return 0
        else {
          let pre_height = 0
          for (let index = 0; index < i; ++index) {
            pre_height += range_cnts_scale(range_cnts[index]) + range_num_view.value.interval
          }
          return pre_height
        }
      })
      .attr('width', range_num_view.value.width)
      .attr('height', (d,i) => range_cnts_scale(d))
      .attr('fill', (d,i) => {
        if (i == props.range_index) return '#4292c6'
        else return "#cecece"
      })
      .attr('opacity', 0.8)
}

const draw_range_time_dis = () => {
  let svg_id = '#' + view_id('range-time-dis', props.range_index)
  d3.selectAll(svg_id).selectAll('*').remove()
  let time_cnts_svg = d3.select(svg_id)
  let time_cnts = inforStore.cur_range_infor.time_cnts[props.range_index]
  let time_segs = new Array(time_cnts.length).fill(1)
  const pie = d3.pie().value(d => d)
  const pieData = pie(time_segs)
  const range_index_scale = d3.scaleLinear()
    .domain([d3.min(time_cnts), d3.max(time_cnts)])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
  const arc = d3.arc()
    .innerRadius(time_cnts_view.value.innerRadius)
    .outerRadius(time_cnts_view.value.outerRadius)
  const paths = time_cnts_svg.selectAll("path")
    .data(pieData)
    .enter()
    .append("path")
      .attr('transform', `translate(${time_cnts_view.value.width / 2}, ${time_cnts_view.value.height / 2})`)
      .attr("d", arc)
      .attr("fill", (d, i) => range_index_scale(time_cnts[i]))
      // .attr("stroke", '#cecece')
      // .attr("stroke-width", 0.5)

}

const draw_range_space_dis = () => {
  let svg_id = '#' + view_id('range-space-dis', props.range_index)
  d3.selectAll(svg_id).selectAll('*').remove()
  let loc_points_g = d3.select(svg_id)
    .append('g')
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...props.loc_coords_x), Math.max(...props.loc_coords_x)])
        .range([space_cnts_view.value.width*0.1, space_cnts_view.value.width*0.9])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...props.loc_coords_y), Math.max(...props.loc_coords_y)])
        .range([space_cnts_view.value.height*0.9, space_cnts_view.value.height*0.1])
  let range_space_cnts = inforStore.cur_range_infor.space_cnts[props.range_index]
  // console.log(range_space_cnts)
  let space_cnts_colormap = d3.scaleLinear()
        .domain([Math.min(...range_space_cnts), Math.max(...range_space_cnts)])
        .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])

  loc_points_g.append('rect')
    .attr('x', 0)
    .attr('y', 0)
    .attr('width', space_cnts_view.value.width)
    .attr('height', space_cnts_view.value.height)
    .attr('fill', 'none')
    .attr('stroke', '#cecece')
    .attr('stroke-width', 1)
  loc_points_g.selectAll('circle')
    .data(range_space_cnts)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(props.loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(props.loc_coords_y[i]))
      .attr('r', 1.8)
      .attr('fill', (d,i) => space_cnts_colormap(d))
      .attr('stroke', 'none')
}

</script>

<template>
  <div class="range_bar">
    <svg class="range-num-dis" :id="view_id('range-num-dis', range_index)" :width="range_num_view.width" :height="range_num_view.height"></svg>
    <div class="range-block">
      <div>min: <span>{{ inforStore.cur_sel_failure_rules[range_index].val_min }}</span></div>
      <div>max: <span>{{ inforStore.cur_sel_failure_rules[range_index].val_max }}</span></div>
      <svg class="range-space-dis" :id="view_id('range-space-dis', range_index)" :width="space_cnts_view.width" :height="space_cnts_view.height"></svg>
      <svg class="range-time-dis" :id="view_id('range-time-dis', range_index)" :width="time_cnts_view.width" :height="time_cnts_view.height"></svg>
    </div>
  </div>
</template>

<style scoped>
.range_bar {
  display: flex;
  width: 120px;
  height: 200px;
  justify-content: space-around;
  align-items: center;
  border-right: solid 1px #bbb;
  padding: 0 5px;
  /* margin-right: 10px; */
}

.range-block {
  width: 90px;
  /* height: 24px; */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  line-height: 16px;
}

.range-space-dis {
  display: block;
  margin-top: 6px;
  margin-bottom: 6px;
}

</style>