<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

import ModelCard from './ModelCard.vue'
import RangeBar from "./RangeBar.vue"
import LegendRow from "./LegendRow.vue"

const inforStore = useInforStore()

let err_hist_max_cnts = ref([])

let loc_coords_x
let loc_coords_y

watch (() => inforStore.cur_data_infor, (oldVlaue, newValue) => {
  loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
})

watch (() => inforStore.cur_model_infor, (oldVlaue, newValue) => {
  for (let i = 0; i < inforStore.cur_model_infor.length; ++i) {
    let cur_max_cnts = Object.values(inforStore.cur_model_infor[i]).map(item => {
      return item.error_indicators.hist_max_cnt
    })
    let cur_neg_fail_cnt = Object.values(inforStore.cur_model_infor[i]).map(item => {
      return item.failure_indicators.neg_failures_num
    })
    let cur_pos_fail_cnt = Object.values(inforStore.cur_model_infor[i]).map(item => {
      return item.failure_indicators.pos_failures_num
    })
    let max_cnt_in_all = Math.max(...cur_max_cnts, ...cur_neg_fail_cnt, ...cur_pos_fail_cnt)
    err_hist_max_cnts.value.push(max_cnt_in_all)
  }
})

</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      Model Cards
      <!-- <span id="get-instance-button" @click="get_instances()">Get instances</span> -->
    </div>
    <div class="out_range_region">
      <div class="out_range_row" v-for="(item, index) in inforStore.cur_model_infor">
        <LegendRow />
        <div class="range_model_row">
          <RangeBar :rule_num="inforStore.cur_model_infor.length" :range_index="index" :loc_coords_x="loc_coords_x" :loc_coords_y="loc_coords_y" />
          <div class="model_list">
            <ModelCard v-for="(key, i) in Object.keys(inforStore.cur_model_infor[index])" :range_index="index" :model_index="i" :model_name="key" :err_hist_max_cnt="err_hist_max_cnts[index]" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 876px;
  height: 346px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 288px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
}

.out_range_region {
  height: 300px;
  overflow-y: scroll;
}

.out_range_row {
  /* width: 900px; */
  /* height: 100px; */
  margin: 10px 12px;
  margin-top: 0;
  border: solid 1px #cecece;
}

.range_model_row {
  padding: 4px 6px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.model_list {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}

</style>