<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import testOne from './test.vue';

const inforStore = useInforStore()

onMounted(() => {
  // getData(inforStore, 'attr_distributions', inforStore.cur_sel_data, JSON.stringify(inforStore.attrs_bins))
  getData(inforStore, 'new_test', 'aaa', 'bbb')
})

let show_ab = ref(false)
watch (() => inforStore.new_test_data, (oldVlaue, newValue) => {
  console.log(inforStore.new_test_data);
  console.log(inforStore.new_test_data.a_b);
  show_ab.value = true
})

</script>

<template>
  <testOne v-for="(item, index) in inforStore.new_test_data.list" :key="index" :view_id="index" :view_str="item"/>
  aaaa
  <div>{{ inforStore.new_test_data }}</div>

  <div v-for="(item, index) in inforStore.new_test_data.list" :key="index">
    {{index}} -- {{item}}
  </div>

  <div v-for="(value, key, index) in inforStore.new_test_data" :key="index">
    <span>{{key}}</span> --- {{ value }}
  </div>

<div v-if="show_ab">{{ inforStore.new_test_data.a_b }}</div>
</template>

<style scoped>

</style>