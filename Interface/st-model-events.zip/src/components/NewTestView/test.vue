<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'

const props = defineProps({
  view_id: Number,
  view_str: String
})

const inforStore = useInforStore()

const view_name = (str, id) => `${str}-${id}`
const colors = ['red', 'green', 'blue']

onMounted(() => {
  drawStr()
})

function drawStr() {
  let svg_id = view_name('view', props.view_id)
  let svg = d3.select(`#${svg_id}`)
    .attr('width', 100)
    .attr('height', 100)
  svg.append('text')
    .attr('x', 12)
    .attr('y', 24)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', colors[props.view_id])
    .text(props.view_str)
}

</script>

<template>
  <svg :id="view_name('view', view_id)"></svg>
</template>

<style scoped>

</style>