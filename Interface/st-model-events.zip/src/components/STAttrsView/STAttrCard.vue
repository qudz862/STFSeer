<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'
import { Login } from "view-ui-plus"

const inforStore = useInforStore()

const props = defineProps({
  attr_name: String,
  attr_cnts: Array,
  attr_bin_edges: Array,
  tree_dict: Object,
  global_resi_max: Number
})

const dis_plot_id = (attr_name) => ('dis-' + attr_name)
const tree_plot_id = (attr_name) => ('tree-' + attr_name)
onMounted(() => {
  // 树节点包含哪些信息：属性范围(文字描述？)、范围的支持度/(如果有分布图，那么其实已经解决了？)、范围内样本的误差情况
  // drawAttrDisPLot()
  // drawNodeLinkPLot()
  // drawIciclePLot()
  drawIndentedChart()
})

const disPlotConfig = {
  width: 276,
  height: 160
}
const treePlotConfig = {
  width: 178,
  height: 380
}

const drawAttrDisPLot = () => {
  let svg_id = dis_plot_id(props.attr_name)
  let err_dis_svg = d3.select('#'+svg_id)
    .attr('width', disPlotConfig.width)
    .attr('height', disPlotConfig.height)
  d3.select('#'+ svg_id).selectAll('*').remove()
  let err_dis_bins = props.attr_bin_edges
  let err_dis_cnts = props.attr_cnts
  let text_h = 14
  let slider_h = 18
  let text_slider_h = text_h + slider_h
  inforStore.focus_err_range = [err_dis_bins[0],err_dis_bins[err_dis_bins.length-1]]
  // x轴和y轴比例尺
  let xScale = d3.scaleLinear()
    .domain([0, err_dis_bins.length-1])
    .range([0, disPlotConfig.width])
  let yScale = d3.scaleLinear()
    .domain([d3.max(err_dis_cnts), 0])
    .range([0, disPlotConfig.height-text_slider_h])
  let xAxis = d3.axisBottom(xScale)
    .ticks(err_dis_bins.length)
    .tickFormat((d) => err_dis_bins[d])
  
  // let yAxis = d3.axisLeft(yScale)

  let brush = d3.brushX()
    .extent([[0, 0], [disPlotConfig.width, disPlotConfig.height-text_slider_h]])
    // .handleSize(xScale(inforStore.step_len))
    .on('brush', brushMove)
    .on("end", brushEnded);
  let brush_g = err_dis_svg.append("g")
    .call(brush)
    // .call(brush.move, defaultExtent);
  let brushing = false; // 添加一个标志位

  function brushMove(e) {
    // console.log(e);
    if (e && !brushing) {
      brushing = true; // 设置标志位，防止递归调用
      let selection = e.selection;
      let step = xScale(1)
      let x0 = Math.floor(selection[0] / step) * step;
      let x1 = Math.ceil(selection[1] / step) * step;
      // 更新选择框的位置
      brush_g.call(brush.move, [x0, x1]);
      brushing = false;
    }
  }
  
  function brushEnded(e) {
    let selection = e.selection;
    if (selection) {
      let x0 = xScale.invert(selection[0]);
      let x1 = xScale.invert(selection[1]);
      let x0_int = parseInt(Math.round(x0))
      let x1_int = parseInt(Math.round(x1))

      inforStore.focus_err_range = [err_dis_bins[x0_int], err_dis_bins[x1_int]]
      // 在这里可以执行你的操作，例如根据范围重新渲染图表等
    } else {
      inforStore.focus_err_range = [err_dis_bins[0],err_dis_bins[err_dis_bins.length-1]]
    }
  }

  let hist_plot = err_dis_svg.append('g').attr('class', 'hist-plot')
  let xAxis_g = hist_plot.append("g")
    // .attr("class", "axis")
    .attr("transform", `translate(0, ${disPlotConfig.height-text_slider_h})`) // 将X轴移至底部
    .call(xAxis);
  let text_y = xAxis_g.select("text").attr('y')

  xAxis_g.selectAll("text")
    .attr("transform", "translate(8,6) rotate(45)")
    .style("text-anchor", "middle"); // 设置文本锚点位置
  // hist_plot.append("g")
  //   .call(yAxis);
  
  // 定义斜条纹图案
  err_dis_svg.append("defs")
    .append("pattern")
    .attr("id", "stripes")
    .attr("patternUnits", "userSpaceOnUse")
    .attr("width", 5)
    .attr("height", 5)
    .append("line")
    .attr("x1", 0)
    .attr("y1", 5)
    .attr("x2", 5)
    .attr("y2", 0)
    .attr("stroke", "#3182bd")
    .attr("stroke-width", 1.5);

  // let binColor = d3.scaleQuantize()
  //   .domain([1, 6])
  //   .range(valColorScheme_blue)

  hist_plot.selectAll('rect')
    .data(err_dis_cnts)
    .join('rect')
      .attr('x', (d,i) => xScale(i)+0.5)
      .attr('y', (d,i) => yScale(d))
      .attr('width', (d,i) => xScale(i+1) - xScale(i)-0.5)
      .attr('height', (d,i) => disPlotConfig.height-text_slider_h-yScale(d))
      .attr('fill', (d,i) => {
        let cur_range = err_dis_bins[i+1] - err_dis_bins[i]
        // let range_size = cur_range / inforStore.range_params.step_len
        // console.log(range_size);
        // return binColor(range_size)
        if (cur_range > inforStore.range_params.step_len) {
          // return "url(#stripes)"
          return "#bcbcbc"
        } else {
          return '#3182bd'
        }
      })
      .attr('opacity', 0.8)
  hist_plot.append('line')
    .attr('x1', 0)
    .attr('y1', disPlotConfig.height-text_slider_h+0.5)
    .attr('x2', disPlotConfig.width)
    .attr('y2', disPlotConfig.height-text_slider_h+0.5)
    .attr('stroke', '#333')
  let zero_bin_id = err_dis_bins.indexOf(0)
  hist_plot.append('line')
    .attr('x1', xScale(zero_bin_id))
    .attr('y1', 0)
    .attr('x2', xScale(zero_bin_id))
    .attr('y2', disPlotConfig.height-text_slider_h)
    .attr('stroke', '#ef6548')
    .attr('stroke-width', 0.5)
    // .attr('stroke-dasharray', '5,5')
}

// 利用节点连接图展示范围树
const drawNodeLinkPLot = () => {
  var margin = { top: 0, right: 0, bottom: 0, left: 0 };
  var innerWidth = treePlotConfig.width - margin.left - margin.right;
  var innerHeight = treePlotConfig.height - margin.top - margin.bottom;

  let svg_id = tree_plot_id(props.attr_name)
  d3.select('#'+ svg_id).selectAll('*').remove()
  let tree_svg = d3.select('#'+svg_id)
    .attr('width', treePlotConfig.width)
    .attr('height', treePlotConfig.height)
  let tree_data = props.tree_dict

  // 创建一个树状图布局
  const tree_layout = d3.tree().size([innerWidth, innerHeight]);
  // 将树状结构数据转换为层次结构
  const root = d3.hierarchy(tree_data);
  // 应用树状图布局
  let tree_content = tree_layout(root);
  let tree_g = tree_svg.append('g')
    .attr('transform', `translate(0, 0)`);
  // 添加链接线
  tree_g.selectAll('.link')
    .data(root.links())
    .enter().append('path')
    .attr('class', 'link')
    .attr('d', d3.linkVertical()
      .x(d => d.x)
      .y(d => d.y))
    .attr('fill', 'none')
    .attr('stroke', '#333')
  // 添加节点
  const nodes = tree_g.selectAll('.node')
    .data(tree_content.descendants())
    .enter().append('g')
    .attr('class', 'node')
    .attr('transform', d => `translate(${d.x},${d.y})`);
  nodes.append("rect")
    .attr("width", 60)
    .attr("height", 40)
    .attr("x", -30) // 更改矩形框的位置
    .attr("y", 0) // 更改矩形框的位置
    .attr("fill", "lightblue");
  // nodes.append('circle')
  //   .attr('r', 20);

  nodes.append("text")
    .attr("dy", "0.3em") // 调整初始位置
    .attr("text-anchor", "middle")
    .selectAll("tspan")
    .data(function (d) {
      return [
        "[" + d.data.range[0] + ", " + d.data.range[1] + "]",
        "sup: " + d.data.sup,
        "div: " + d.data.div
      ];
    })
    .enter()
    .append("tspan")
    .attr("x", 0)
    .attr("dy", "1.2em")
    .style("font-size", "10px") // 设置字体大小
    .text(function (d) {
      return d;
    });

  
}

// 利用冰柱图展示范围树
const drawIciclePLot = () => {
  let svg_id = tree_plot_id(props.attr_name)
  d3.select('#'+ svg_id).selectAll('*').remove()
  let tree_svg = d3.select('#'+svg_id)
    .attr('width', treePlotConfig.width)
    .attr('height', treePlotConfig.height)
  let tree_data = props.tree_dict

  // 创建一个树状图布局
  const icicle_layout = d3.partition()
    .size([treePlotConfig.width, treePlotConfig.height])
    .padding(1)

  // 将树状结构数据转换为层次结构
  const root = d3.hierarchy(tree_data)
    .sum(d => d.range_size)
    // .sort((a, b) => b.height - a.height || b.value - a.value)
  // 应用树状图布局
  icicle_layout(root)
  let tree_g = tree_svg.append('g')
    // .attr('transform', `translate(50, ${-treePlotConfig.height/12})`);
  // 添加矩形元素表示 Icicle plot
  tree_g.selectAll('rect')
    .data(root.descendants())
    .enter().append('rect')
    .attr('x', d => d.x0)
    .attr('y', d => d.y0)
    .attr('width', d => d.x1 - d.x0)
    .attr('height', d => d.y1 - d.y0)
    .attr('fill', 'steelblue');

  // 添加节点文字
  tree_g.selectAll('text')
    .data(root.descendants())
    .enter().append('text')
    .attr('x', d => (d.x0 + d.x1) / 2)
    .attr('y', d => (d.y0 + d.y1) / 2)
    .attr('dy', '0.35em')
    .attr('text-anchor', 'middle')
    .text(d => d.data.range);

}

const drawIndentedChart = () => {
  let tree_data = props.tree_dict
  const breadthOffset = 30
  const depthOffset = 10
  const minHeight = 6
  const root = d3.hierarchy(tree_data)
  root.dx = breadthOffset
  root.dy = depthOffset || width / Math.max((root.height + 1), minHeight)
  d3.tree().nodeSize([root.dx, root.dy])(root)

  const nodes = root.descendants();
  const height = (nodes.length + 1) * breadthOffset;

  let svg_id = tree_plot_id(props.attr_name)
  d3.select('#'+ svg_id).selectAll('*').remove()
  let tree_svg = d3.select('#'+svg_id)
    .attr('width', treePlotConfig.width)
    .attr("height", height)
  let index = 0
  root.eachBefore(d => {
    d.x = index * breadthOffset
    index += 1
  })

  let x0 = Infinity
  let x1 = -x0
  root.each(d => {
    if (d.x > x1) x1 = d.x
    if (d.x < x0) x0 = d.x
  })

  const g = tree_svg
    .append("g")
    .attr("font-family", "sans-serif")
    .attr("font-size", 10)
    .attr("transform", `translate(${root.dy / 3}, ${root.dx - x0})`)

  const linkShape = d => `M${d.source.y},${d.source.x}V${d.target.x}H${d.target.y}`
  const link = g
    .append("g")
    .attr("fill", "none")
    .attr("stroke", "#ccc")
    .attr("stroke-opacity", 1)
    .attr("stroke-width", 1.5)
    .selectAll("path")
    .data(root.links())
    .join("path")
    .attr("d", linkShape)
  const node = g
    .append("g")
    .attr("stroke-linejoin", "round")
    .attr("stroke-width", 3)
    .selectAll("g")
    .data(root.descendants())
    .join("g")
      .attr("transform", d => `translate(${d.y}, ${d.x})`)
      .style('cursor', 'pointer')
      .on('click', (e,d) => {
        let target = e.target;
        if (d3.select(target).attr('selected') == 'false') {
          d3.select(target)
            .attr('selected', 'true')
          d3.select(`#highlight-${d.data.range_str}`)
            .attr('stroke', '#000')
            .attr('stroke-width', 2)
          if (inforStore.select_ranges == '') inforStore.select_ranges = []
          inforStore.select_ranges.push(d.data.range_str)
          // console.log(inforStore.select_ranges);
        } else {
          d3.select(target)
            // .attr('stroke', '#999')
            // .attr('stroke-width', 1)
            .attr('selected', 'false')
          d3.select(`#highlight-${d.data.range_str}`)
            .attr('stroke', 'none')
          let cur_str = d.data.range_str
          let cur_index = inforStore.select_ranges.indexOf(cur_str)
          if (cur_index !== -1) inforStore.select_ranges.splice(cur_index, 1)
          // if (inforStore.select_ranges == []) inforStore.select_ranges = ''
          // console.log(inforStore.select_ranges);
        }
      })
  // node.append("circle")
  //   .attr("fill", d => (d.children ? "#555" : "#999"))
  //   .attr("r", 2.5)
  let node_block_w = 120
  let node_block_h = 24
  let err_rect_w = 10
  node.append('rect')
    .attr('selected', 'false')
    .attr('x', 0).attr('y', -12)
    .attr('width', node_block_w)
    .attr('height', node_block_h)
    .attr('fill', '#fff')
    .attr('stroke', '#999')
    .attr('stroke-width', 1)
    
  let coverScale = d3.scaleLinear()
    .domain([0,1])
    .range([0, node_block_w-err_rect_w])
  // let errColorScale = d3.scaleSequential(d3.interpolateRdBu)
  //   .domain(inforStore.global_err_range
  // console.log(root.descendants());
  // let abs_residual = root.descendants().map(item => item.data.abs_residual)
  let errColorScale = d3.scaleQuantize()
    // .domain([0, inforStore.global_err_range[1]])
    .domain([0, props.global_resi_max])
    .range(valColorScheme_fire)
  node.append('rect')
    .attr('x', err_rect_w).attr('y', -node_block_h/2+0.5)
    .attr('width', node_block_w-err_rect_w-0.5)
    .attr('height', 6)
    .attr('fill', '#cecece')
    .attr('stroke', 'none')
  node.append('rect')
    .attr('x', err_rect_w).attr('y', -node_block_h/2+0.5)
    .attr('width', d => coverScale(d.data.focus_cover))
    .attr('height', 6)
    .attr('fill', valColorScheme_blue[3])
    .attr('stroke', 'none')
  
  node.append('rect')
    .attr('x', 0.5).attr('y', -11.5)
    .attr('width', err_rect_w-0.5)
    .attr('height', node_block_h-1)
    .attr('fill', d => errColorScale(d.data.abs_residual))
    .attr('stroke', 'none')
  // node.append('rect')
  //   .attr('x', err_rect_w).attr('y', -12)
  //   .attr('width', err_rect_w)
  //   .attr('height', node_block_h)
  //   .attr('fill', 'blue')
  
  node.append('rect')
    .attr('id', (d,i) => `highlight-${d.data.range_str}`)
    .attr('x', 0).attr('y', -12)
    .attr('width', node_block_w)
    .attr('height', node_block_h)
    .attr('fill', 'none')
    .attr('stroke', 'none')

  node.append("text")
    .attr("dy", "0.65em")
    .attr("x", d => (d.children ? 42 : 42))
    .attr("text-anchor", d => (d.children ? "start" : "start"))
    .text(d => `[${d.data.range[0]}, ${d.data.range[1]}]`)
    .clone(true)
    .lower()
    .attr("stroke", "white")
  
}

</script>

<template>
  <!-- 每个属性包含一个分布视图、 树视图，做成卡片-->
  <div class="st-attr-card">
    <div class="attr_name_block">{{ attr_name }}</div>
    <!-- <svg :id="dis_plot_id(attr_name)"></svg> -->
    <svg class="range-tree-svg" :id="tree_plot_id(attr_name)"></svg>
  </div>

</template>

<style scoped>
.attr_name_block {
  font-weight: 700;
  margin-bottom: -10px;
}

.range-tree-svg {
  max-height: 600px;
}
</style>