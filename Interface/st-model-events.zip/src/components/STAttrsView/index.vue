<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire } from '@/data/index.js'
import STAttrCard from './STAttrCard.vue';


const inforStore = useInforStore()

function findMax(tree, property) {
  let max = -Infinity;

  function traverse(node) {
    if (node[property] > max) {
      max = node[property];
    }

    if (node.children && node.children.length > 0) {
      node.children.forEach(child => traverse(child));
    }
  }

  traverse(tree);

  return max;
}

let global_resi_max = ref(0)
watch (() => inforStore.cur_range_infor, (oldVlaue, newValue) => {
  let attrs = Object.keys(inforStore.cur_range_infor)
  for (let i = 0; i < attrs.length; ++i) {
    let cur_max = findMax(inforStore.cur_range_infor[attrs[i]].tree_dict, 'abs_residual')
    if (cur_max > global_resi_max.value) global_resi_max.value = cur_max
  }
  drawErrLegend()
})

function drawErrLegend() {
  d3.select('#attr-err-legend').selectAll('*').remove()
  let margin_left = 20, margin_right = 40, margin_top = 0, margin_bottom = 0
  let main_w = 120, main_h = 12
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legend_svg = d3.select('#attr-err-legend')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legend = legend_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let legendScale = d3.scaleQuantize()
    .domain([0, main_w])
    .range(valColorScheme_fire)
  legend.selectAll('rect')
    .data(Array(main_w).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => legendScale(i))
  legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  legend.append('text')
    .attr('x', main_w+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${parseFloat(global_resi_max.value.toFixed(2))}`)
}

</script>

<template>
  <div class="st-attrs-container">
    <div class="title-layer">
      <div class="title">Meta Attributes View</div>
      <!-- <div class="bulid-button">Bulid Subgroup</div> -->
      <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Residual_abs: </span></label><svg class="phase-legend" id="attr-err-legend" width="10" height="10"></svg>
      </div>
      <!-- <div class="sel-ranges"><span style="font-weight: 700;">Selected: </span>{{ inforStore.select_ranges }}</div> -->
    </div>
    <!-- 每个属性包含一个分布视图、 树视图，做成卡片-->
    <div class="attr-block">
      <STAttrCard v-for="(key, index) in Object.keys(inforStore.cur_range_infor)" :key="index" :attr_name="key" :attr_cnts="inforStore.cur_range_infor[key].attr_cnts" :attr_bin_edges="inforStore.cur_range_infor[key].seg_points" :tree_dict="inforStore.cur_range_infor[key].tree_dict" :global_resi_max="global_resi_max" />
    </div>
  </div>

</template>

<style scoped>
.st-attrs-container {
  /* width: 1600px; */
  width: 740px;
  height: 468px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 700px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  /* font: 700 20px "Arial"; */
  /* letter-spacing: 1px; */
  /* color: #333; */
  display: flex;
  align-items: center;
  /* justify-content: space-between; */
}

.title {
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
}

.bulid-button {
  font: 700 16px "Arial";
  margin-left: 20px;
  text-decoration-line: underline;
  color: #999;
  font-style: italic;
}

.form-label {
  margin-bottom: 0;
  font-weight: 700;
}

.data-dropdown {
  margin-left: 20px;
}

.bulid-button:hover {
  color: #1a73e8;
  cursor: pointer;
}

.sel-ranges {
  font-size: 14px;
  margin-left: 20px;
}

.attr-block {
  padding-left: 12px;
  display: flex;
}
</style>