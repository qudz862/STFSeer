<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire, valColorScheme_double} from '@/data/index.js'

const props = defineProps({
  tile_id: Number,
  loc_coords_x: Array,
  loc_coords_y: Array,
  tile_data: Array,
  tile_type: String
})

const inforStore = useInforStore()

const pattern_tile = {
  width: 80,
  height: 80
}

const view_id = (view_str, tile_i) => {
  return view_str + '-tile-' + tile_i.toString()
}

function drawPatternTile() {
  let svg_id = '#' + view_id(props.tile_type, props.tile_id)
  d3.selectAll(svg_id).selectAll('*').remove()
  let svg = d3.select(svg_id)
    .attr('width', pattern_tile.width)
    .attr('height', pattern_tile.height)
  let loc_g = svg.append('g')
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...props.loc_coords_x), Math.max(...props.loc_coords_x)])
        .range([pattern_tile.width*0.1, pattern_tile.width*0.9])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...props.loc_coords_y), Math.max(...props.loc_coords_y)])
        .range([pattern_tile.height*0.9, pattern_tile.height*0.1])
  let colormap 
  if (props.tile_type == 'pattern') {
    colormap = d3.scaleOrdinal()
      .domain([0,1,2,3,4,5,6,7,8,9,10,11])
      .range(d3.schemePaired)
  } else if (props.tile_type == 'raw_data') {
    colormap = d3.scaleQuantize()
      // .domain([inforStore.cur_data_infor.threshold.output_range.min, inforStore.cur_data_infor.threshold.output_range.max])
      .domain([0, 500])
      .range(valColorScheme_fire)
  }

  loc_g.append('rect')
    .attr('x', 0)
    .attr('y', 0)
    .attr('width', pattern_tile.width)
    .attr('height', pattern_tile.height)
    .attr('fill', 'none')
    .attr('stroke', '#cecece')
    .attr('stroke-width', 1)
  loc_g.selectAll('circle')
    .data(props.tile_data)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(props.loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(props.loc_coords_y[i]))
      .attr('r', 1.8)
      .attr('fill', (d,i) => colormap(d))
      .attr('stroke', 'none')
      // .attr('opacity', (d,i) => {
      //   if (d > 150) return 1.0
      //   else return 0
      // })
}

onMounted(() => {
  drawPatternTile()
})

</script>

<template>
  <div>
    <div>{{ tile_id }}</div>
    <svg :id="view_id(tile_type, tile_id)"></svg>
  </div>
    
</template>

<style scoped>

</style>