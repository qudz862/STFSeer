<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

import PatternTile from "./PatternTile.vue"
import SankeyView from "./SankeyView.vue"

const inforStore = useInforStore()

let loc_coords_x
let loc_coords_y

watch (() => inforStore.cur_data_infor, (oldVlaue, newValue) => {
  loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
})

// watch (() => inforStore.cur_event_series, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_event_series);
// })

</script>

<template>
  <div class="models-container">
    <div class="title-layer">Pattern View</div>
    <div class="tiles-block">
      <SankeyView />
      <!-- <PatternTile v-for="(item, index) in inforStore.cur_st_patterns" :tile_id="index" :loc_coords_x="loc_coords_x" :loc_coords_y="loc_coords_y" :tile_data="item" tile_type='pattern'/> -->
      <!-- <PatternTile v-for="(item, index) in inforStore.cur_data_infor['raw_data']" :key="index" :tile_id="index" :loc_coords_x="loc_coords_x" :loc_coords_y="loc_coords_y" :tile_data="item" tile_type='raw_data'/> -->
    </div>
  </div>

</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 860px;
  height: 546px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 820px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.tiles-block {
  display: flex;
  flex-wrap: wrap;
}
</style>