<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const inforStore = useInforStore()

// watch (() => inforStore.cur_sel_model, (oldVlaue, newValue) => {
//     getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), 3, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_abs_th)
// })

// watch (() => inforStore.cur_ranges, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_ranges);
//   getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), inforStore.cur_sel_scope_th, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_diff_th, inforStore.subset_params.err_abs_th)
// })

watch (() => inforStore.phase_ins_subsets, (oldVlaue, newValue) => {
  drawSubsetsRadviz()
})

watch (() => inforStore.filtered_subsets, (oldVlaue, newValue) => {
  drawSubsetsRadviz()
})

function starCoordinates(anchors, hist_data) {
  let coords = []
  for (let k = 0; k < hist_data.length; ++k) {
    let p = [0, 0]
    for (let i = 0; i < anchors.length; ++i) {
      p[0] += anchors[i][0] * hist_data[k][i]
      p[1] += anchors[i][1] * hist_data[k][i]
    }
    let hist_sum = d3.sum(hist_data[k])
    p[0] /= hist_sum
    p[1] /= hist_sum
    p[0] *= 0.95
    p[1] *= 0.95
    coords.push(p)
  }
  
  return coords
}

function radvizCoordinates(anchors, hist_data) {
  let coords = []
  for (let k = 0; k < hist_data.length; ++k) {
    let p = [0, 0]
    for (let i = 0; i < anchors.length; ++i) {
      p[0] += anchors[i][0] * hist_data[k][i]
      p[1] += anchors[i][1] * hist_data[k][i]
    }
    let hist_sum = d3.sum(hist_data[k])
    p[0] /= hist_sum
    p[1] /= hist_sum
    p[0] *= 0.95
    p[1] *= 0.95

    coords.push(p)
  }
  
  return coords
}

function getDistance(p1, p2) {
  let dx = p2[0] - p1[0];
  let dy = p2[1] - p1[1];
  return Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
}
function findNeighbors(points, targetPointIndex, distanceThreshold) {
    const neighbors = [];
    const targetPoint = points[targetPointIndex];
    for (let i = 0; i < points.length; i++) {
        if (i !== targetPointIndex && getDistance(points[i], targetPoint) <= distanceThreshold) {
            neighbors.push(i);
        }
    }
    return neighbors;
}

function expandCluster(points, targetPointIndex, clusterIndices, distanceThreshold, minPts) {
    const neighbors = findNeighbors(points, targetPointIndex, distanceThreshold);
    for (const neighborIndex of neighbors) {
        if (!points[neighborIndex].visited) {
            points[neighborIndex].visited = true;
            const neighborNeighbors = findNeighbors(points, neighborIndex, distanceThreshold);
            if (neighborNeighbors.length >= minPts) {
                expandCluster(points, neighborIndex, clusterIndices, distanceThreshold, minPts);
            }
        }
        if (!points[neighborIndex].clustered) {
            clusterIndices.push(neighborIndex);
            points[neighborIndex].clustered = true;
        }
    }
}
function DBSCAN(points, targetPointIndex, distanceThreshold, minPts) {
    for (let i = 0; i < points.length; i++) {
        points[i].visited = false;
        points[i].clustered = false;
    }
    const clusterIndices = [targetPointIndex];
    expandCluster(points, targetPointIndex, clusterIndices, distanceThreshold, minPts);
    return clusterIndices;
}

function isArraySuperset(superset, subset) {
  return subset.every(value => superset.includes(value));
}

const filterSubsets = () => {
  // 进行radviz中选中的匹配
  let filtered_points
  if (inforStore.sel_subset_points.length == 0) {
    filtered_points = inforStore.phase_ins_subsets.slice()
  } else {
    filtered_points = inforStore.phase_ins_subsets.filter((value, index) => inforStore.sel_subset_points.includes(index))
  }
  
  // 再进行字符串匹配筛选
  let matched_subsets = []
  if (inforStore.select_ranges.length == 0) matched_subsets = filtered_points
  else {
    for (let i = 0; i < filtered_points.length; ++i) {
      let isSuperset = isArraySuperset(filtered_points[i].subset_attrs, inforStore.select_ranges);
      if (isSuperset) matched_subsets.push(filtered_points[i])
    }
    // inforStore.filtered_subsets = matched_subsets
  }
  // 先进行阈值筛选
  let err_th = inforStore.organize_params.err_abs_th
  let cur_filtered_subsets = matched_subsets.filter((obj) => obj.residual_abs >= err_th)
  inforStore.filtered_subsets = cur_filtered_subsets
}

function drawSubsetsRadviz() {
  d3.select('#subsets-radviz').selectAll('*').remove()
  // 需要获取的数据信息：误差范围段数据数目、子集在各误差范围段的分布、子集自身的误差、样本数目等信息
  let val_bins = inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins  // 误差范围bins
  // console.log(val_bins);
  // 设置svg
  let margin_left = 10, margin_right = 10, margin_top = 10, margin_bottom = 34
  let main_w = 690, main_h = 190
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let radius = 340
  let svg = d3.select('#subsets-radviz')
    .attr('width', svg_w)
    .attr('height', svg_h)
  svg.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', svg_w).attr('height', svg_h)
    .attr('fill', '#fff')
    .on('click', (e) => {
      // d3.selectAll('.subset-point').attr('fill', '#666')
      inforStore.sel_subset_points = []
      filterSubsets()
      // drawSubsetsRadviz()
    })
  let arc = d3.arc()
    .innerRadius(radius-2)
    .outerRadius(radius+2)
    .startAngle(-Math.PI/3)
    .endAngle(Math.PI/3); // Math.PI 表示半圆
  let arc_g = svg.append('g')
    .attr("transform", `translate(${svg_w/2},${margin_top+main_h*1.9})`)
  let arc_line = arc_g.append("path")
    .attr("d", arc)
    .attr("fill", "#cecece"); // 可以设置填充颜色
  let arc_anchors_g = arc_g.append('g')
  let anchor_angles = d3.range(-Math.PI/3, Math.PI/3+0.1, Math.PI*2/3 / (val_bins.length-2));
  // console.log(anchor_angles);
  let arc_anchors = arc_anchors_g.selectAll('g')
    .data(anchor_angles)
    .join('g')
      .attr("transform", (d,i) => `translate(${radius * Math.sin(d)},${-radius * Math.cos(d)})`)
  arc_anchors.append('circle')
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 4)
    .attr('fill', '#999')
  arc_anchors.append('circle')
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 6)
    .attr('fill', 'none')
    .attr('stroke-width', 1)
    .attr('stroke', '#333')
  arc_anchors.append('text')
    .attr('transform', (d,i) => `rotate(${(i*2/3)/(val_bins.length-2)*180-90*2/3})`)
    .attr('x', 0)
    .attr('y', 0)
    .attr('dy', -10)
    // .attr('text-anchor', (d,i) => {
    //   if (i == 0) return 'start'
    //   else if (i == val_bins.length-2) return 'end'
    //   else return 'middle'
    // })
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .text((d,i) => `[${val_bins[i]},${val_bins[i+1]}]`)
  
  // 绘制子集点
  let subsets_g = svg.append('g')
    .attr("transform", `translate(${svg_w/2},${margin_top+main_h*1.9})`)
  let anchor_locs = anchor_angles.map(item => [radius*Math.sin(item), -radius * Math.cos(item)])
  // console.log(anchor_locs);
  let resi_hist_rate = inforStore.phase_ins_subsets.map(item => item.residual_hist_normalize)
  let radviz_coords = radvizCoordinates(anchor_locs, resi_hist_rate)
  let star_coords = starCoordinates(anchor_locs, resi_hist_rate)
  // console.log(radviz_coords);
  let subsets_glyphs = subsets_g.selectAll('g')
    .data(radviz_coords)
    .join('g')
      .attr("transform", d => `translate(${d[0]},${d[1]})`)
  subsets_glyphs.append('circle')
    .attr('class', 'subset-point')
    .attr('id', (d,i) => `subset-${i}`)
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 3.5)
    .attr('fill', (d,i) => {
      // console.log(inforStore.sel_subset_points);
      if (inforStore.filtered_subsets.length == inforStore.phase_ins_subsets.length) return '#666'
      let sel_points = inforStore.filtered_subsets.map((item,index) => item['subset_id'])
      if (sel_points.includes(i)) return valColorScheme_red[1]
      else return '#666'
    })
    .attr('opacity', 0.5)
    .on('click', (e, d) => {
      // d3.selectAll('.subset-point').attr('fill', '#666')
      let subset_id = parseInt(d3.select(e.target).attr('id').split('-')[1])
      // console.log(d, radviz_coords[subset_id], getDistance(d, radviz_coords[subset_id]));
      inforStore.sel_subset_points = DBSCAN(radviz_coords, subset_id, main_h*0.06, 1)
      filterSubsets()
      // let sel_points = inforStore.filtered_subsets.map((item,index) => item['subset_id'])
      // for (let i = 0; i < sel_points.length; ++i) {
      //   d3.select(`#subset-${sel_points[i]}`).attr('fill', valColorScheme_red[1])
      // }
      // drawSubsetsRadviz()
      // inforStore.filtered_subsets = inforStore.phase_ins_subsets.filter((value, index) => sel_points.includes(index))
    })

}

</script>

<template>
  <svg id="subsets-radviz"></svg>
</template>

<style scoped>
#subsets-radviz {
  display: block;
  margin: 0 auto;
  margin-top: -24px;
}
</style>