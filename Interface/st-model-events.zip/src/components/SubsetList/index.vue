<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'
import SubSetsRadviz from './SubSetsRadviz.vue'
// import SubSetsProjection from './SubSetsProjection.vue'
import RangeAttrs from './RangeAttrs.vue';

const inforStore = useInforStore()
// watch (() => inforStore.cur_sel_model, (oldVlaue, newValue) => {
//     getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), 3, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_abs_th)
// })

// watch (() => inforStore.cur_ranges, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_ranges);
//   getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), inforStore.cur_sel_scope_th, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_diff_th, inforStore.subset_params.err_abs_th)
// })

const hist_view_id = (attr, id) => `hist-${attr}-${id}`
const attr_axis_id = attr => `table-axis-${attr}`

watch (() => inforStore.phase_ins_subsets, (oldVlaue, newValue) => {
  // 处理范围字符串
  for (let i = 0; i < inforStore.phase_ins_subsets.length; ++i) {
    inforStore.phase_ins_subsets[i].range_val = {}
    for (let j = 0; j < inforStore.phase_ins_subsets[i].subset_attrs.length; ++j) {
      let cur_attr_str_split = inforStore.phase_ins_subsets[i].subset_attrs[j].split('=')
      let cur_attr_type = cur_attr_str_split[0]
      // console.log(cur_attr_str_split[1]);
      let cur_attr_range = JSON.parse(cur_attr_str_split[1])
      // console.log(cur_attr_type, cur_attr_id);
      // console.log(inforStore.cur_range_infor);
      // console.log(inforStore.cur_range_infor[cur_attr_type]);
      inforStore.phase_ins_subsets[i].range_val[cur_attr_type] = cur_attr_range
    }
  }
  inforStore.filtered_subsets = inforStore.phase_ins_subsets.slice()
})

watch (() => inforStore.select_ranges.length, (oldVlaue, newValue) => {
  // console.log(inforStore.select_ranges);
  filterSubsets()
})

const onSubsetClick = (subset_id, subset) => {
  // inforStore.cur_sel_subset_id = subset_id
  // getData(inforStore, 'subset_data_ids', item.id)
  // getData(inforStore, 'subset_details', subset_id, JSON.stringify(inforStore.cur_val_bins))
  if (subset_id == inforStore.cur_sel_subset_id) {
    inforStore.cur_sel_subset_id = -1
    // 清楚phase选中框和phase details
    $('.subset-row').removeClass('subset-selected')
    d3.select('#join-dist-space').selectAll('*').remove()
    $('.select-config-row').css('display', 'none')
    // data_id等为空
    inforStore.cur_subset_st_indices = []
  } else {
    inforStore.cur_sel_subset_id = subset_id
    // getData(inforStore, 'subset_details', subset_id, inforStore.cur_x_attr, inforStore.cur_y_attr, JSON.stringify(inforStore.cur_x_bin_edges), JSON.stringify(inforStore.cur_y_bin_edges))
    // 清楚旧选中框
    $('.subset-row').removeClass('subset-selected')
    // 添加新选中框
    $(`.subset-row:eq(${subset_id})`).addClass('subset-selected')
    $('.select-config-row').css('display', 'flex')
    // 设置data_id相关
    // 获取indices
    inforStore.cur_subset_st_indices = subset.st_indices
  }

}


const onFilterErrTHChange = () => {
  filterSubsets()
}

function isArraySuperset(superset, subset) {
  return subset.every(value => superset.includes(value));
}

const filterSubsets = () => {
  // 进行radviz中选中的匹配
  let filtered_points
  if (inforStore.sel_subset_points.length == 0) {
    filtered_points = inforStore.phase_ins_subsets.slice()
  } else {
    filtered_points = inforStore.phase_ins_subsets.filter((value, index) => inforStore.sel_subset_points.includes(index))
  }
  
  // 再进行字符串匹配筛选
  let matched_subsets = []
  if (inforStore.select_ranges.length == 0) matched_subsets = filtered_points
  else {
    for (let i = 0; i < filtered_points.length; ++i) {
      let isSuperset = isArraySuperset(filtered_points[i].subset_attrs, inforStore.select_ranges);
      if (isSuperset) matched_subsets.push(filtered_points[i])
    }
    // inforStore.filtered_subsets = matched_subsets
  }
  // 先进行阈值筛选
  let err_th = inforStore.organize_params.err_abs_th
  let cur_filtered_subsets = matched_subsets.filter((obj) => obj.residual_abs >= err_th)
  inforStore.filtered_subsets = cur_filtered_subsets
}

onUpdated(() => {
  // console.log('up~~');
  for (let attr of inforStore.cur_st_attrs) {
    drawAttrAxis(attr)
  }
  drawErrHistAxis()
  d3.selectAll('.err-hist-svg').selectAll('*').remove()
  for (let i = 0; i < inforStore.filtered_subsets.length; ++i) {
    drawErrHist(i)
    drawSupRateIcon(i)
    drawPosNegIcon(i)
  }
  d3.selectAll('.subset-hist-view').selectAll('*').remove()
  for (let i = 0; i < inforStore.filtered_subsets.length; ++i) {
    let cur_range_val = inforStore.filtered_subsets[i].range_val
    for (let attr of inforStore.cur_st_attrs) {
      if (!cur_range_val.hasOwnProperty(attr)) {
        drawSubsetHist(i, attr)
      }
    }
  }
})

const bin_width = 10

const drawErrHistAxis = () => {
  let val_bins = inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins
  let width = (val_bins.length+1) * bin_width
  let height = 20
  let main_width = (val_bins.length-1) * bin_width
  let svg = d3.select('#err-hist-svg-axis')
    .attr('width', width)
    .attr('height', height)
  svg.selectAll('*').remove()

  let xScale = d3.scaleLinear()
    .domain([0, val_bins.length-1])
    .range([0, main_width])
  let xAxis = d3.axisTop(xScale)
    .ticks(val_bins.length)
    .tickFormat(d => val_bins[d])
    .tickSize(2.5)
  let axis_g = svg.append('g')
    .attr('id',  `axis_err_hist`)
    .attr('transform', `translate(${bin_width}, 19)`)
    .call(xAxis)
    .selectAll("text")
      .style("text-anchor", "middle")
      .style('font-size', '8px')
      .attr("dx", ".8em")
      .attr("dy", ".1em")
      .attr("transform", "rotate(-45)");
}

const drawAttrAxis = attr => {
  let bin_edges = inforStore.meta_attr_objs[attr].bin_edges
  let main_width = (bin_edges.length-1) * bin_width
  let svg_id = attr_axis_id(attr)
  let svg = d3.select(`#${svg_id}`)
  svg.selectAll('*').remove()

  let xScale = d3.scaleLinear()
    .domain([0, bin_edges.length-1])
    .range([0, main_width])
  let xAxis = d3.axisTop(xScale)
    .ticks(bin_edges.length)
    .tickFormat(d => bin_edges[d])
    .tickSize(2.5)
  let axis_g = svg.append('g')
    .attr('id',  `axis_${attr}`)
    .attr('transform', `translate(${bin_width}, 19)`)
    .call(xAxis)
    .selectAll("text")
      .style("text-anchor", "middle")
      .style('font-size', '8px')
      .attr("dx", ".8em")
      .attr("dy", ".1em")
      .attr("transform", "rotate(-45)");

}

const drawSubsetHist = (subset_id, attr) => {
  // let cur_indices = inforStore.filtered_subsets[subset_id].indices
  // let cur_attr_data = inforStore.meta_attr_objs[attr].clean
  // let cur_attr_subset = cur_attr_data.filter((value, index) => cur_indices.includes(index))
  let cur_attr_hist = inforStore.filtered_subsets[subset_id].other_hist[attr]
  let bin_edges = inforStore.meta_attr_objs[attr].bin_edges
  let width = (bin_edges.length-1)*bin_width
  let height = 24
  const margin = { top: 0, right: 0, bottom: 0, left: 0 };
  const main_width = width - margin.left - margin.right
  const main_height = height - margin.top - margin.bottom
  let svg_id = hist_view_id(attr, subset_id)
  let svg = d3.select(`#${svg_id}`)
    .attr('width', width)
    .attr('height', height)
  // svg.selectAll('*').remove()
  if (inforStore.meta_attr_objs[attr].important_bins.length == 0) return
  const subset_hist_g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const xScale = d3.scaleLinear()
    .domain([0, bin_edges.length-1])
    .range([0, main_width]);
  const yScale = d3.scaleLinear()
    .domain([0, d3.max(cur_attr_hist)])
    // .nice()
    .range([main_height, 0])
  // const bin_width = xScale(1) - xScale(0)
  subset_hist_g.selectAll("rect")
    .data(cur_attr_hist)
    .join("rect")
    .attr("x", (d,i) => xScale(i) + bin_width*0.1)
    .attr("y", d => yScale(d))
    .attr("width", bin_width*0.8)
    .attr("height", d => main_height-yScale(d))
    .attr("fill", "#cecece")
}

const drawErrHist = index => {
  let val_bins = inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins
  let width = (val_bins.length-1) * bin_width
  let height = 24
  let margin_l = 0, margin_r = 0, margin_t = 0, margin_b = 0
  let main_w = width - margin_l - margin_r
  let main_h = height - margin_t - margin_b
  let cur_subset = inforStore.filtered_subsets[index]
  let svg_id = errHistSvgID(index)
  let svg = d3.select('#' + svg_id)
    .attr('width', width)
    .attr("height", height)
  // 定义x，y轴的scale
  let xScale = d3.scaleLinear()
    .domain([0, val_bins.length-1])
    .range([0, main_w])
  let yScale = d3.scaleLinear()
    .domain([0, 1])
    .range([0, main_h])
  let err_hist = svg.append('g')
    .attr("transform", `translate(${margin_l},${margin_t})`);
  // let bin_w = xScale(1) - xScale(0)
  // console.log(cur_subset.residual_hist_rate)
  // console.log(cur_subset);
  err_hist.selectAll('rect')
    .data(cur_subset.residual_hist_normalize)
    .join('rect')
      .attr('x', (d,i) => xScale(i)+bin_width*0.1)
      .attr('y', (d,i) => main_h - yScale(d))
      .attr('width', bin_width*0.8)
      .attr('height', (d,i) => yScale(d))
      .attr('fill', '#999')
      .attr('stroke', 'none')
  let zero_line = err_hist.append('line')
    .attr('x1', xScale(val_bins.indexOf(0)))
    .attr('x2', xScale(val_bins.indexOf(0)))
    .attr('y1', 0)
    .attr('y2', main_h)
    .attr('stroke', valColorScheme_red[1])
    .attr('stroke-dasharray', '4,4')
}

const drawSupRateIcon = index => {
  const width = 24
  const height = 24
  const radius = Math.min(width, height) / 2;
  const margin_l = 0, margin_r = 0, margin_t = 0, margin_b = 0
  let main_w = width - margin_l - margin_r
  let main_h = height - margin_t - margin_b
  let cur_subset = inforStore.filtered_subsets[index]
  let svg_id = hist_view_id('sup_rate', index)
  d3.select('#' + svg_id).selectAll('*').remove()
  let svg = d3.select('#' + svg_id)
    .attr('width', width)
    .attr("height", height)
  let icon = svg.append('g')
    .attr('transform', `translate(${margin_l+main_w/2},${margin_t+main_h/2})`)
  // 定义x，y轴的scale
  const arc = d3.arc()
    .innerRadius(5)
    .outerRadius(radius)
    .startAngle(0);
  const background = icon.append('path')
    .datum({endAngle: Math.PI * 2})
    .attr('d', arc)
    .attr('fill', '#e0e0e0');
  const foreground = icon.append('path')
    .datum({endAngle: Math.PI * 2 * cur_subset.sup_rate})
    .attr('d', arc)
    .attr('fill', '#007bff'); // 前景颜色
}
const drawPosNegIcon = index => {
  const width = 24
  const height = 24
  const radius = Math.min(width, height) / 2;
  const margin_l = 0, margin_r = 0, margin_t = 0, margin_b = 0
  let main_w = width - margin_l - margin_r
  let main_h = height - margin_t - margin_b
  let cur_subset = inforStore.filtered_subsets[index]
  const pos_neg_data = [
    {label: 'pos', value: cur_subset.pos_res_num},
    {label: 'neg', value: cur_subset.neg_res_num}
  ];
  let svg_id = hist_view_id('pos_neg', index)
  d3.select('#' + svg_id).selectAll('*').remove()
  let svg = d3.select('#' + svg_id)
    .attr('width', width)
    .attr("height", height)
  let icon = svg.append('g')
    .attr('transform', `translate(${margin_l+main_w/2},${margin_t+main_h/2})`)
  const pie = d3.pie()
    .value(d => d.value)
    .sort(null);
  const colorScale = d3.scaleOrdinal()
    .domain(pos_neg_data.map(d => d.label))
    .range(['#0000ff', '#ff0000']);
  const arc = d3.arc()
    .innerRadius(5)
    .outerRadius(radius)
  const arcs = icon.selectAll('.arc')
    .data(pie(pos_neg_data))
    .join('g')
    .attr('class', 'arc');
  arcs.append('path')
    .attr('d', arc)
    .attr('fill', (d, i) => {
      return colorScale(d.data.label);
    });
}

const errHistSvgID = index => `err-hist-${index}`
const col_width = attr => {
  let bin_edges = inforStore.meta_attr_objs[attr].bin_edges
  return (bin_edges.length+1) * bin_width
}
</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      <div class="title">Subgroup Module</div>
      <!-- <div class="params-control">
        <label class="form-label">Example range</label>
        <input class="form-range" type="range">
      </div> -->
    </div>
    <div class="main-region">
      <div class="subset-filter-region">
        <SubSetsRadviz />
        <!-- <SubSetsProjection /> -->
        <div>
          <RangeAttrs />
          <div class="table-param-row">
            <span><span style="color: #515a6e; font-weight: 700;">Mean_Residual_Abs:</span> <span style="color: #1a73e8;">{{ inforStore.phase_clean_res_abs_mean }}</span></span>
            <div class="params-control">
              <label class="form-label"><span class="attr-title">Filter_Residual_TH: </span></label>
              <input class="form-control" type="text" v-model="inforStore.organize_params.err_abs_th" @change="onFilterErrTHChange">
            </div>
          </div>
        </div>
      </div>
      <div class="table-region">
        <table v-if="inforStore.filtered_subsets.length > 0" class="table table-fixed-header subset-list">
          <thead>
            <tr>
              <th scope="col">
                <div><span class="iconfont">&#xe618;</span> V</div>
                <svg class="attr-axis" :id="attr_axis_id('target_val')" :width="col_width('target_val')"></svg>
              </th>
              <th scope="col">
                <span class="iconfont">&#xe634;</span> T
                <svg class="attr-axis" :id="attr_axis_id('temporal_state_vals')" :width="col_width('temporal_state_vals')"></svg>
              </th>
              <th scope="col">
                <span class="iconfont">&#xe647;</span> SC
                <svg class="attr-axis" :id="attr_axis_id('space_comp_state_vals')" :width="col_width('space_comp_state_vals')"></svg>
              </th>
              <th scope="col">
                <span class="iconfont">&#xe647;</span> SD
                <svg class="attr-axis" :id="attr_axis_id('space_diff_state_vals')" :width="col_width('space_diff_state_vals')"></svg>
              </th>
              <th scope="col">subset_size</th>
              <!-- <th scope="col">sup_rate</th> -->
              <th scope="col">error_abs</th>
              <th scope="col">
                error_hist
                <svg class="attr-axis" id="err-hist-svg-axis"></svg>
              </th>
              <!-- <th scope="col">error_pos</th>
              <th scope="col">error_neg</th> -->
              <!-- error_abs
              error_pos
              error_neg -->
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in inforStore.filtered_subsets" :key="index" class="subset-row" @click="onSubsetClick(index, item)">
              <td v-if="item.range_val.hasOwnProperty('target_val')" class="">{{ item.range_val['target_val'] }}</td>
              <td v-else class=""><svg class="subset-hist-view" :id="hist_view_id('target_val', index)"></svg></td>
              <td v-if="item.range_val.hasOwnProperty('temporal_state_vals')" class="">{{ item.range_val['temporal_state_vals'] }}</td>
              <td v-else class=""><svg class="subset-hist-view" :id="hist_view_id('temporal_state_vals', index)"></svg></td>
              <td v-if="item.range_val.hasOwnProperty('space_comp_state_vals')" class="">{{ item.range_val['space_comp_state_vals'] }}</td>
              <td v-else class=""><svg class="subset-hist-view" :id="hist_view_id('space_comp_state_vals', index)"></svg></td>
              <td v-if="item.range_val.hasOwnProperty('space_diff_state_vals')" class="">{{ item.range_val['space_diff_state_vals'] }}</td>
              <td v-else class=""><svg class="subset-hist-view" :id="hist_view_id('space_diff_state_vals', index)"></svg></td>
              <!-- <td>{{ item.neg_res_num }}/{{ item.pos_res_num }}</td> -->
              <!-- <td>{{ item.sup_rate }}</td> -->
              <td>
                <svg class="sup_rate-svg" :id="hist_view_id('sup_rate', index)"></svg>
                <svg class="pos_neg-svg" :id="hist_view_id('pos_neg', index)"></svg>
              </td>
              <td>{{ item.residual_abs }}</td>
              <td><svg class="err-hist-svg" :id="errHistSvgID(index)"></svg></td>
              <!-- <td>{{ item.error_pos }}</td>
              <td>{{ item.error_neg }}</td> -->
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
  </div>

</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 1610px;
  height: 622px !important;
  border: solid 1px #c2c5c5;
  padding: 0;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 0;
}

.table-region {
  margin-top: -16px;
  overflow-y: auto;
  height: 386px;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 720px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  display: flex;
  align-items: center;
  /* justify-content: space-between; */
}

.title {
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  z-index: 99999999999;
}

.main-region {
  /* display: flex; */
}

.subset-filter-region {
  display: flex;
}

.params-control {
  display: flex;
  margin-left: 20px;
}

.params-control .form-control {
  width: 50px;
  height: 20px !important;
  /* width: 120px; */
  padding: 0px 0px !important;
  margin-left: 4px;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
  color:#1a73e8;
  /* text-align: left; */
  /* overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis; */
}

.form-label {
  margin-bottom: 0;
  font-weight: 700;
}

/* .subset-list tr{
  display: flex;
  justify-content: center;
} */

.subset-row {
  width: 100px;
}

.subset-selected {
  /* background-color: #cad8e5 !important; */
  border: solid 2px #333;
}

.table td, .table th {
  text-align: center; /* 水平居中 */
  vertical-align: middle; /* 垂直居中 */
  padding: 8px 4px 8px 6px;
}

.table-fixed-header thead {
  position: sticky;
  top: 0;
  background-color: white;
  z-index: 1000;
}

.table-param-row {
  display: flex;
  align-items: center;
}

.err-hist-svg {
  display: block;
  margin: 0 auto;
}

.subset-hist-view {
  display: block;
  margin: 0 auto;
  height: 24px;
}

.attr-axis {
  display: block;
  margin: 0 auto;
  height: 20px;
}

.sup_rate-svg {
  margin-right: 6px;
}
.pos_neg-svg {
  margin-left: 6px;
}
/* .table-param-row {
  margin-left: 10px;
} */
</style>