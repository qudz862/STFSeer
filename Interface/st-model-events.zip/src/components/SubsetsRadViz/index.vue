<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red } from '@/data/index.js'

const inforStore = useInforStore()

// watch (() => inforStore.cur_sel_model, (oldVlaue, newValue) => {
//     getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), 3, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_abs_th)
// })

// watch (() => inforStore.cur_ranges, (oldVlaue, newValue) => {
//   console.log(inforStore.cur_ranges);
//   getData(inforStore, 'subsets', inforStore.cur_sel_data, inforStore.cur_sel_model, JSON.stringify(inforStore.range_params), inforStore.cur_sel_scope_th, inforStore.subset_params.frequent_sup_th, inforStore.subset_params.err_diff_th, inforStore.subset_params.err_abs_th)
// })

watch (() => inforStore.cur_subsets, (oldVlaue, newValue) => {
  drawSubsetsRadviz()
})

function starCoordinates(anchors, hist_data) {
  let coords = []
  for (let k = 0; k < hist_data.length; ++k) {
    let p = [0, 0]
    for (let i = 0; i < anchors.length; ++i) {
      p[0] += anchors[i][0] * hist_data[k][i]
      p[1] += anchors[i][1] * hist_data[k][i]
    }
    coords.push(p)
  }
  
  return coords
}

function radvizCoordinates(anchors, hist_data) {
  let coords = []
  for (let k = 0; k < hist_data.length; ++k) {
    let p = [0, 0]
    for (let i = 0; i < anchors.length; ++i) {
      p[0] += anchors[i][0] * hist_data[k][i]
      p[1] += anchors[i][1] * hist_data[k][i]
    }
    let hist_sum = d3.sum(hist_data[k])
    p[0] /= hist_sum
    p[1] /= hist_sum
    coords.push(p)
  }
  
  return coords
}

function drawSubsetsRadviz() {
  d3.select('#subsets-radviz').selectAll('*').remove()
  // 需要获取的数据信息：误差范围段数据数目、子集在各误差范围段的分布、子集自身的误差、样本数目等信息
  let val_bins = inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins  // 误差范围bins
  // 设置svg
  let margin_left = 10, margin_right = 10, margin_top = 10, margin_bottom = 34
  let main_w = 800, main_h = 400
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let radius = 380
  let svg = d3.select('#subsets-radviz')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let arc = d3.arc()
    .innerRadius(radius-2)
    .outerRadius(radius+2)
    .startAngle(-Math.PI/2)
    .endAngle(Math.PI/2); // Math.PI 表示半圆
  let arc_g = svg.append('g')
    .attr("transform", `translate(${svg_w/2},${margin_top+main_h})`)
  let arc_line = arc_g.append("path")
    .attr("d", arc)
    .attr("fill", "#cecece"); // 可以设置填充颜色
  let arc_anchors_g = arc_g.append('g')
  let anchor_angles = d3.range(-Math.PI/2, Math.PI/2+0.1, Math.PI / (val_bins.length-2));
  let arc_anchors = arc_anchors_g.selectAll('g')
    .data(anchor_angles)
    .join('g')
      .attr("transform", (d,i) => `translate(${radius * Math.sin(d)},${-radius * Math.cos(d)})`)
  arc_anchors.append('circle')
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 4)
    .attr('fill', '#999')
  arc_anchors.append('circle')
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 6)
    .attr('fill', 'none')
    .attr('stroke-width', 1)
    .attr('stroke', '#333')
  arc_anchors.append('text')
    .attr('transform', (d,i) => `rotate(${i/(val_bins.length-2)*180-90})`)
    .attr('x', 0)
    .attr('y', 0)
    .attr('dy', -10)
    // .attr('text-anchor', (d,i) => {
    //   if (i == 0) return 'start'
    //   else if (i == val_bins.length-2) return 'end'
    //   else return 'middle'
    // })
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .text((d,i) => `[${val_bins[i]},${val_bins[i+1]}]`)
  
  // 绘制子集点
  let subsets_g = svg.append('g')
    .attr("transform", `translate(${svg_w/2},${margin_top+main_h})`)
  let anchor_locs = anchor_angles.map(item => [radius*Math.sin(item), -radius * Math.cos(item)])
  let resi_hist_rate = inforStore.cur_subsets.map(item => item.residual_hist_rate)
  let radviz_coords = radvizCoordinates(anchor_locs, resi_hist_rate)
  let star_coords = starCoordinates(anchor_locs, resi_hist_rate)
  let subsets_glyphs = subsets_g.selectAll('g')
    .data(radviz_coords)
    .join('g')
      .attr("transform", d => `translate(${d[0]},${d[1]})`)
  subsets_glyphs.append('circle')
    .attr('id', (d,i) => `subset-${i}`)
    .attr('cx', 0)
    .attr('cy', 0)
    .attr('r', 2)
    .attr('fill', '#999')
    .attr('opacity', 0.5)
    .on('click', (e, d) => {
      let subset_id = d3.select(e.target).attr('id').split('-')[1]
    })

}

</script>

<template>
  <div class="models-container">
    <div class="title-layer">Subsets Overview</div>
    <svg id="subsets-radviz"></svg>
  </div>

</template>

<style scoped>
.models-container {
  /* width: 1600px; */
  width: 840px;
  height: 568px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 4px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 720px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>