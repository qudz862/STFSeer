<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import * as d3 from 'd3'
import { valColorScheme_blue, valColorScheme_red, valColorScheme_fire, valColorScheme_double} from '@/data/index.js'

const props = defineProps({
  phase_id: Number,
  phase_data: Object,
})

const inforStore = useInforStore()

const view_id = (view_str, model_name) => `${view_str}_${model_name}`

onMounted(() => {
  drawPhases()
})

onUpdated(() => {
  drawPhases()
  // drawStepErrBoxPlot()
})

let svg_h = 92
let svg_w = 150
let time_h = 14
let dist_h = 78
let dist_h_pure = 50

const drawPhases = () => {
  let colorScale = d3.scaleLinear()
    .domain([0, inforStore.cur_data_infor.space.loc_list.length])
    .range(["#e7fbff","#08306b"])
  // let colorScale = d3.scaleQuantize()
  //   .domain([0, inforStore.cur_data_infor.space.loc_list.length])
  //   .range(valColorScheme_blue)
  let cntScale = d3.scaleLinear()
      .domain([0, inforStore.cur_data_infor.space.loc_list.length])
      .range([0, dist_h_pure])
  let binScale = d3.scaleLinear()
    .domain([0, inforStore.cur_val_bins.length-1])
    .range([20, svg_w/2-20])
  let binAxis = d3.axisBottom(binScale)
    .ticks(inforStore.cur_val_bins.length)
    .tickSize(3)
    .tickFormat((d) => inforStore.cur_val_bins[d])
  let timeScale = d3.scaleLinear()
    .domain([0, inforStore.st_phase_events.time_strs.length])
    .range([0, svg_w])
  
  let phase_infor = props.phase_data
  // console.log(phase_infor);
  let cur_svg_id = '#' + view_id('phase', props.phase_id)
  d3.select(cur_svg_id).selectAll('*').remove()
  let cur_svg = d3.select(cur_svg_id)
    .attr('width', svg_w).attr('height', svg_h)
  // 绘制time-bar
  let time_bar = cur_svg.append('g')
    .attr('class', 'phase-time-bar')
  time_bar.append('rect')
    .attr('x', 0).attr('y', 0)
    .attr('width', svg_w)
    .attr('height', time_h)
    .attr('fill', 'none')
    .attr('stroke', '#333')
    .attr('stroke-width', 1)
  time_bar.append('text')
    .attr('x', svg_w/2)
    .attr('y', 12)
    .attr('text-anchor', 'middle')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${phase_infor['start_date']} to ${phase_infor['end_date']}`)

  cur_svg.append('rect')
    .attr('x', 0).attr('y', time_h)
    .attr('width', svg_w)
    .attr('height', dist_h)
    .attr('fill', 'none')
    .attr('stroke', '#333')
    .attr('stroke-width', 1)

  // 绘制target_val直方图
  let hist_block = cur_svg.append('g')
    .attr('class', 'phase-hist-block')
    .attr('transform', `translate(0, ${time_h+4})`)

  hist_block.append('g').selectAll('rect')
    .data(phase_infor.hist)
    .join('rect')
      .attr('x', (d,i) => binScale(i))
      .attr('y', (d,i) => dist_h_pure - cntScale(d))
      .attr('width', binScale(1)-binScale(0))
      .attr('height', (d,i) => cntScale(d))
      .attr('fill', (d,i) => {
        if (inforStore.cur_val_bins[i] < inforStore.phase_params.focus_th)
          return '#cecece'
        else return valColorScheme_blue[3]
      })
  let hist_x_axis = hist_block.append("g")
    .attr("class", "hist-axis")
    .attr("transform", `translate(0, ${dist_h_pure})`) // 将X轴移至底部
    .call(binAxis);
  // 展示空间污染
  let loc_g = cur_svg.append('g')
    .attr('transform', `translate(${svg_w/2}, ${time_h+2})`)
  let loc_coords_x = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[0])
  let loc_coords_y = inforStore.cur_data_infor.space.loc_list.map(item => item.geometry.coordinates[1])
  let white_rate = 0.1
  let loc_x_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_x), Math.max(...loc_coords_x)])
        .range([svg_w/2*(white_rate), svg_w/2*(1-white_rate)])
  let loc_y_scale = d3.scaleLinear()
        .domain([Math.min(...loc_coords_y), Math.max(...loc_coords_y)])
        .range([svg_w/2*(1-white_rate), svg_w/2*white_rate])
  let colormap = d3.scaleLinear()
    .domain([0, 1])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length -1]])
  let opacityScale = d3.scaleLinear()
    .domain([0, 1])
    .range([0.2, 1])
  // loc_g.append('rect')
  //   .attr('x', 0)
  //   .attr('y', 0)
  //   .attr('width', svg_w/2)
  //   .attr('height', svg_w/2)
  //   .attr('fill', 'none')
  //   .attr('stroke', '#cecece')
  //   .attr('stroke-width', 1)
  cur_svg.append('line')
    .attr('x1', svg_w/2)
    .attr('y1', time_h + 8)
    .attr('x2', svg_w/2)
    .attr('y2', time_h + svg_w/2-6)
    .attr('stroke', '#cecece')
    .attr('stroke-width', 1)
  loc_g.selectAll('circle')
    .data(phase_infor.space_pollution_cnt)
    .join('circle')
      .attr('cx', (d,i) => loc_x_scale(loc_coords_x[i]))
      .attr('cy', (d,i) => loc_y_scale(loc_coords_y[i]))
      .attr('r', 1.8)
      .attr('fill', (d,i) => {
        if (d == 0) return '#cecece'
        else return colormap(d)
      })
      .attr('stroke', 'none')
      // .attr('opacity', (d,i) => {
      //   if (d == 0) return 0.5
      //   else return opacityScale(d)
      // })

  // 绘制时序污染情况
  let time_g = cur_svg.append('g')
    .attr('transform', `translate(0, ${time_h+2})`)
  let time_segs = new Array(phase_infor.time_pollution_cnt.length).fill(1)
  const pie = d3.pie().value(d => d)
  const pieData = pie(time_segs)
  const range_index_scale = d3.scaleLinear()
    .domain([0, 1])
    .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length-1]])
  const arc = d3.arc()
    .innerRadius(svg_w*0.20*(1-white_rate))
    .outerRadius(svg_w*0.25*(1-white_rate))
  const paths = time_g.selectAll("path")
    .data(pieData)
    .enter()
    .append("path")
      .attr('transform', `translate(${svg_w * 0.25}, ${0.25*svg_w})`)
      .attr("d", arc)
      .attr("fill", (d, i) => range_index_scale(phase_infor.time_pollution_cnt[i]))
      // .attr("stroke", '#cecece')
      // .attr("stroke-width", 0.5)
  d3.selectAll('.hist-axis > .tick > text').remove()
}

</script>

<template>
  <div>
    <svg :id="view_id('phase', phase_id)"></svg>
  </div>
  
</template>

<style scoped>

</style>