<script setup>
import { ref, reactive, computed, watch, onMounted, onUpdated } from "vue"
import { useInforStore } from '@/stores/infor.js'
import getData from '@/services/index.js'
import * as d3 from 'd3'
import $ from 'jquery'
import { valColorScheme_blue, valColorScheme_fire, valColorScheme_red } from '@/data/index.js'
import PhasesPCP from './PhasesPCP.vue'
import EventsPCP from './EventsPCP.vue'
import PhaseCard from './PhaseCard.vue'
import PhasePredCard from './PhasePredCard.vue'
import EventsTest from './EventsTest.vue'
import PhaseEventSeq from './PhaseEventSeq.vue';

const inforStore = useInforStore()

let show_indicators = ref(false)
function deepCopyArray(arr) {
  return JSON.parse(JSON.stringify(arr));
}

let sorted_phase_ids = ref([])
watch (() => inforStore.cur_filtered_phases_indices, (oldVlaue, newValue) => {
  let tmp_indices = deepCopyArray(inforStore.cur_filtered_phases_indices)
  sorted_phase_ids.value = sortPhases(cur_sort_attr.value, cur_order.value, tmp_indices)
  // sorted_phase_ids.value = tmp_indices
  // sorted_phase_ids.value = Array.from({ length: inforStore.cur_filtered_phases.length }, (_, index) => index);
  // inforStore.cur_filtered_events = inforStore.cur_filtered_phases.reduce((accu, obj) => accu.concat(obj.evolution_events), [])
  drawCntLegend()
})


let global_space_mae_range = [0, 0]
watch (() => inforStore.cur_phase_indicators, (oldVlaue, newValue) => {
  global_space_mae_range = inforStore.cur_phase_indicators[0].global_space_mae_range
  drawErrLegend()
})

const phaseSvgID = (index) => `phase-${index}`

const onPhaseSelect = (phase_id) => {
  inforStore.sel_subset_points = []
  inforStore.select_ranges = []
  inforStore.organize_params.err_abs_th = 0
  if (inforStore.cur_phase_id == phase_id) {
    inforStore.cur_phase_id = -1
    inforStore.cur_phase_sorted_id = -1
    // 清楚phase选中框和phase details
    $('.phase-block').removeClass('selected')
    d3.select('#st-layout-phase').selectAll('*').remove()
    d3.select('#time-event-bar').selectAll('*').remove()
    $('.feature-panel').css('display', 'none')
  } else {
    inforStore.cur_phase_id = phase_id
    inforStore.cur_phase_sorted_id = sorted_phase_ids.value[phase_id]
    getData(inforStore, 'phase_ins_subsets', inforStore.cur_sel_data, JSON.stringify(inforStore.cur_model_names), inforStore.cur_sel_model, inforStore.cur_phase_sorted_id, JSON.stringify(inforStore.cur_st_attrs), inforStore.cur_sel_fore_step, inforStore.cur_range_mode, JSON.stringify(inforStore.range_params), JSON.stringify(inforStore.subset_params), JSON.stringify(inforStore.organize_params), JSON.stringify(inforStore.multi_step_err_infor[inforStore.cur_sel_model].val_bins), JSON.stringify(inforStore.cur_focused_scope))
    // 清楚旧选中框
    $('.phase-block').removeClass('selected')
    // 添加新选中框
    let phase_block_id = '#' + view_id('phase-block', phase_id)
    $(phase_block_id).addClass('selected')
    $('.feature-panel').css('display', 'block')
    getData(inforStore, 'phase_data', sorted_phase_ids.value[phase_id])
    
    getData(inforStore, 'phase_details', inforStore.cur_sel_model, sorted_phase_ids.value[phase_id], JSON.stringify(inforStore.cur_val_bins), inforStore.phase_params.focus_th, JSON.stringify(inforStore.cur_focused_scope))
  }
}

const sort_attrs = ref(['Temporal', 'life_span', 'mean_intensity', 'max_intensity', 'mean_pollution_grids', 'move_speed', 'POD', 'FAR', 'Multi_Accuracy', 'RMSE', 'Pollution_Level'])
const cur_sort_attr = ref('Temporal')
const orders = ref(['Ascending', 'Descending'])
const cur_order = ref('Ascending')
// const temporal_attrs = ref(['Pollution_cnt', 'Temporal_intensity'])
// const cur_temporal_attr = ref(['time_pollution_cnt'])

const sortPhases = (attr, order, cur_ids) => {
  let attr_data
  if (attr == 'POD' || attr == 'FAR' || attr == 'RMSE')
    attr_data = inforStore.cur_phase_indicators.map(item => item[attr])
  else if (attr == 'Temporal')
    attr_data = inforStore.st_phase_events.phases_list.map(item => item.t_id)
  else if (attr == 'Multi_Accuracy')
    attr_data = inforStore.cur_phase_indicators.map(item => item.multi_accuracy)
  else if (attr == 'Pollution_Level')
    attr_data = inforStore.cur_phase_indicators.map(item => item.mean_level)

  let pollution_attrs = ['life_span', 'mean_intensity', 'max_intensity', 'mean_pollution_grids', 'move_speed']
  if (pollution_attrs.includes(attr)) {
    attr_data = inforStore.st_phase_events.phases_list.map(item => item[attr])
  }

  cur_ids.sort(function (a, b) {
    if (order == 'Ascending')
      return attr_data[a] - attr_data[b]
    else 
      return attr_data[b] - attr_data[a]
  })
  
  // for (let i = 0; i < inforStore.st_phase_events.phases_list.length; ++i) {
  //   let svg_id = '#' + phaseSvgID(i)
  //   d3.select(svg_id).selectAll("*").remove()
  // }
  return cur_ids
}

const onSortAttrChange = (index) => {
  cur_sort_attr.value = sort_attrs.value[index]
  sorted_phase_ids.value = sortPhases(cur_sort_attr.value, cur_order.value, sorted_phase_ids.value)
}
const onOrderChange = (index) => {
  cur_order.value = orders.value[index]
  sorted_phase_ids.value = sortPhases(cur_sort_attr.value, cur_order.value, sorted_phase_ids.value)
}

function drawCntLegend() {
  d3.select('#cnt-legend').selectAll('*').remove()
  let margin_left = 20, margin_right = 10, margin_top = 0, margin_bottom = 0
  let main_w = 120, main_h = 12
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legend_svg = d3.select('#cnt-legend')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legend = legend_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let legendScale = d3.scaleLinear()
      .domain([0, main_w])
      .range([valColorScheme_blue[0], valColorScheme_blue[valColorScheme_blue.length - 1]])
  legend.selectAll('rect')
    .data(Array(main_w).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => legendScale(i))
  legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('0')
  legend.append('text')
    .attr('x', main_w+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text('1')
}

function drawErrLegend() {
  d3.select('#err-legend').selectAll('*').remove()
  let margin_left = 20, margin_right = 40, margin_top = 0, margin_bottom = 0
  let main_w = 120, main_h = 12
  let svg_w = main_w + margin_left + margin_right
  let svg_h = main_h + margin_top + margin_bottom
  let legend_svg = d3.select('#err-legend')
    .attr('width', svg_w)
    .attr('height', svg_h)
  let legend = legend_svg.append('g')
    .attr('transform', `translate(${margin_left}, ${margin_top})`)
  let legendScale = d3.scaleQuantize()
    .domain([0, main_w])
    .range(valColorScheme_fire)
  legend.selectAll('rect')
    .data(Array(main_w).fill(1))
    .join('rect')
      .attr('x', (d,i) => i)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 12)
      .attr('fill', (d,i) => legendScale(i))
  legend.append('text')
    .attr('x', -4)
    .attr('y', 11)
    .attr('text-anchor', 'end')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${global_space_mae_range[0]}`)
  legend.append('text')
    .attr('x', main_w+4)
    .attr('y', 11)
    .attr('text-anchor', 'start')
    .style('font-size', '12px')
    .attr('fill', '#333')
    .text(`${parseFloat(global_space_mae_range[1].toFixed(2))}`)
}

const view_id = (view_str, view_id) => `${view_str}_${view_id}`

const phase_update_flag = (item) => {
  if (inforStore.cur_phase_indicators.length > 0) {
    return inforStore.cur_phase_indicators[item].ACC
  } else {
    return 0.000001
  }
}
</script>

<template>
  <div class="models-container">
    <div class="title-layer">
      <div class="title">Phases View</div>
      <div class="params-control">
        <label class="form-label"><span class="attr-title">Min_Length: </span></label>
        <input class="form-control" type="text" v-model="inforStore.phase_params.min_length"> 
      </div>
      <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Sorted by: </span></label>
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_sort_attr }}</button>
        <ul class="dropdown-menu">
          <li v-for="(item, index) in sort_attrs" :value="item" @click="onSortAttrChange(index)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div>
      <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Order: </span></label>
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_order }}</button>
        <ul class="dropdown-menu">
          <li v-for="(item, index) in orders" :value="item" @click="onOrderChange(index)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div>
      <!-- <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Temporal_Attr: </span></label>
        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">{{ cur_order }}</button>
        <ul class="dropdown-menu">
          <li v-for="(item, index) in orders" :value="item" @click="onOrderChange(index)" class='dropdown-item' :key="index">
            <div class="li-data-name">{{ item }}</div>
          </li>
        </ul>
      </div> -->

      <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Pollution Count: </span></label><svg class="phase-legend" id="cnt-legend" width="10" height="10"></svg>
      </div>
      <div class="data-dropdown">
        <label class="form-label"><span class="attr-title">Residual_abs: </span></label><svg class="phase-legend" id="err-legend" width="10" height="10"></svg>
      </div>
    </div>
    <div class="phases-module">
      <PhasesPCP />
      <div class="phases-container">
        <div v-for="(item, index) in sorted_phase_ids" class="phase-block" :id="view_id('phase-block', index)" :key="index" @click="onPhaseSelect(index)" >
          <PhaseCard :phase_id="item" :phase_data="inforStore.st_phase_events.phases_list[item]" />
          <PhasePredCard v-if="inforStore.cur_phase_indicators.length > 0" :phase_id="item" />
        </div>
      </div>
    </div>
    
    <!-- <EventsPCP /> -->
    <!-- <PhaseEventSeq /> -->
    <!-- <EventsTest /> -->
  </div>

</template>

<style scoped>
.models-container {
  width: 1610px;
  /* width: 1580px; */
  height: 232px;
  border: solid 1px #c2c5c5;
  border-radius: 6px;
  /* padding: 1px; */
  margin: 2px;
  overflow-y: auto;
}

.title-layer {
  /* position: absolute; */
  z-index: 80;
  width: 1580px;
  height: 20px;
  text-align: left;
  padding-left: 12px;
  /* background-color: #6c757d; */
  /* color: #fff; */
  margin-top: 10px;
  margin-bottom: 10px;
  /* font: 700 16px "Microsort Yahei"; */
  display: flex;
  align-items: center;
  /* justify-content: space-between; */
}

.title {
  font: 700 20px "Arial";
  /* letter-spacing: 1px; */
  color: #333;
}

.params-control {
  display: flex;
  margin-left: 20px;
}

.params-control .form-control {
  width: 40px;
  height: 20px !important;
  /* width: 120px; */
  padding: 0px 0px !important;
  margin-left: 4px;
  border: none;
  border-bottom: solid 1px #9c9c9c;
  border-radius: 0;
  font-size: 14px;
  text-align: center;
  color:#1a73e8;
  /* text-align: left; */
  /* overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis; */
}

.form-label {
  margin-bottom: 0;
  font-weight: 700;
}

.data-dropdown {
  margin-left: 20px;
}

.data-dropdown .dropdown-toggle {
  width: 140px !important;
  height: 30px;
  padding: 0px 2px -30px 0px !important;
  margin-bottom: 10px;
  border-bottom: solid 1px #9c9c9c;
  color:#1a73e8;
  border-radius: 0;
  font-size: 14px;
  /* text-align: left; */
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.dropdown-toggle::after {
    margin-left: 0.6em !important;
}

.dropdown-item {
  border-bottom: solid 1px #cecece;
  font-size: 14px;
  max-width: 280px;
  cursor: pointer;
  white-space: normal;
}

.dropdown-item:hover {
  background-color: #cecece;
}

.li-data-name {
    font-size: 14px;
}

.li-data-description {
    font-size: 12px;
    color: #777;
}

.phases-module {
  display: flex;
  /* align-items: center; */
}

.phases-container {
  /* margin-left: 10px; */
  margin-top: -2px;
  white-space: nowrap;
  overflow-x: auto;
}

.phase-block {
  display: inline-block;
  margin: 2px;
  /* border: solid 1px #999; */
}

.phase-block:hover {
  cursor: pointer;
}

.selected {
  border: solid 2px #1a73e8;
}
</style>