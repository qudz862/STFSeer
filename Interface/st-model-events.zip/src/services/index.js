import {
  getExistedTaskDataModel,
  getPointLocs,
  getCurDataInfor,
  getModelInfor,
  getModelParameters,
  getDataItems,
  saveErrorConfig,
  getTrajectories,
  getGridBorders,
  getOverviewIndicators,
  getSTPatterns,
  getEventSeries,
  getSTPhaseEvents,
  getPhasesIndicators,
  getPhaseDetails,
  getSubsetDetails,
  getErrDistribution,
  getMultiStepErrInfor,
  getSubsets,
  getRanges,
  getSubsetDataIds,
  getAttrDistributions,
  getInstanceDetail_subset,
  getInstanceSeqs,
  getLocFeatures,
  getPhaseData,
  getEventSubsets,
  getPhaseInsSubsets,
  getNewTest
} from './request'

import { cityGroup } from '@/data'

import { strToJson } from '@/libs/utils'
import { json } from 'd3-fetch'
import * as d3 from 'd3'

export default async (store, field, ...args) => {
  let data = null
  let res = null
  switch (field) {
    case 'new_test':
      data = await getNewTest(...args)
      res = data
      // console.log(res);
      store.$patch((state) => {
        state.new_test_data = res
        // console.log(state.new_test_data);
      })
      break
    case 'existed_task_data_model':
      data = await getExistedTaskDataModel(...args)
      res = data
      store.$patch((state) => {
        state.existed_task_data_model = res.existed_task_data_model
        state.dataset_infor = res.dataset_infor
        state.model_infor = res.model_infor
        state.error_configs = res.error_configs
      })
      break
    case 'point_loc':
      data = await getPointLocs(...args)
      // 构建为geojson的feature格式
      res = []
      data.forEach((item,index,array)=>{
        let feature = {
          "type": "Feature",
          "geometry": {
            "type": "Point",
            "coordinates": [item['lng'], item['lat']]
          },
          "properties": {
            "loc_id": item['loc_id'],
            "focused": false,
            "elevation": item['elevation']
          }
        }
        res.push(feature)
      })
      break
    case 'grid_borders':
      data = await getGridBorders(...args)
      res = []
      data.forEach((item,index,array)=>{
        let feature = {
          "type": "Feature",
          "geometry": {
            "type": "LineString",
            "coordinates": item['border_points']
          },
          "properties": {
            "loc_id": item['loc_id']
          }
        }
        res.push(feature)
      })
      break
    case 'trajectories':
      data = await getTrajectories(...args)
      // 构建为geojson的feature格式
      res = []
      // data = strToJson(data)
      if (data.mode == 'single') {
        data.trajs.forEach((item,index,array)=>{
          let feature = {
            "type": "Feature",
            "geometry": {
              "type": "LineString",
              "coordinates": item.traj.map(point=>point.coords)
            },
            "properties": {
              "loc_id": item.loc_id,
              "altitudes": item.traj.map(point=>point.altitudes),
              "pressure": item.traj.map(point=>point.pressure),
              "time_step": item.traj.map(point=>point.time_step)
            }
          }
          res.push(feature)
        })
      }
      if (data.mode == 'ensemble') {
        data.trajs.forEach((item,index,array)=>{
          for (let i = 0; i < item.length; ++i) {
            let feature = {
              "type": "Feature",
              "geometry": {
                "type": "LineString",
                "coordinates": item[i].traj.map(point=>point.coords)
              },
              "properties": {
                "loc_id": item[i].loc_id,
                "altitudes": item[i].traj.map(point=>point.altitudes),
                "pressure": item[i].traj.map(point=>point.pressure),
                "time_step": item[i].traj.map(point=>point.time_step),
                "ens_member": item[i].ens_member
              }
            }
            res.push(feature)
          }
        })  
      }
      break
    case 'cur_data_infor':
      data = await getCurDataInfor(...args)
      let loc_geojson = []
      let grid_border_geojson = []
      let loc_region_list = []
      data.space.loc_list.forEach((item,index,array)=>{
        let feature = {
          "type": "Feature",
          "geometry": {
            "type": "Point",
            "coordinates": [item.coordinates[0], item.coordinates[1]]
          },
          "properties": {
            "loc_id": item.geo_id,
            "focused": false,
            "type": item.type
            // "elevation": item['elevation']
          }
        }
        loc_geojson.push(feature)
        const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${item.coordinates[0]},${item.coordinates[1]}.json?access_token=pk.eyJ1IjoiZGV6aGFudmlzIiwiYSI6ImNraThnYWoxcDA1aXkycnMzMGxhcDcxeGgifQ.pbnOr8oKR894OJ3seHIayg`
        fetch(url)
          .then(response => response.json())
          .then(data => {
            if (data.features && data.features.length > 0) {
              let address = data.features[1].place_name
              if (!isNaN(address[0]) && address[0] !== ' ') address = address.slice(8, address.length)
              loc_region_list.push(address)
            } else {
              console.log("No results found");
            }
          })
          .catch(error => {
            console.error("Error fetching data:", error)
          })
      })
      data.space.grid_borders.forEach((item,index,array)=>{
        let feature = {
          "type": "Feature",
          "geometry": {
            "type": "LineString",
            "coordinates": item['border_points']
          },
          "properties": {
            "loc_id": item['loc_id']
          }
        }
        grid_border_geojson.push(feature)
      })

      res = data
      res.space.loc_list = loc_geojson
      res.space.grid_border_geojson = grid_border_geojson
      store.$patch((state) => {
        state.cur_data_infor = res
        state.loc_regions = loc_region_list
      })
      // console.log(store.cur_data_infor);
      break
    case 'model_infor':
      data = await getModelInfor(...args)
      res = data
      store.$patch((state) => {
        state.model_infor = res.models_infor
        state.range_infor = res.ranges_infor
      })
      break
    case 'model_parameters':
      data = await getModelParameters(...args)
      res = data
      store.$patch((state) => {
        state.model_parameters = res
      })
      break
    case 'data_items':
      data = await getDataItems(...args)
      res = data
      store.$patch((state) => {
        state.cur_data_items = res
      })
      break
    case 'save_error_config':
      data = await saveErrorConfig(...args)
      res = data
      store.$patch((state) => {
        state.config_save_state = res
      })
      break
    case 'overview_indicators':
      data = await getOverviewIndicators(...args)
      res = data
      store.$patch((state) => {
        const merged_indicators = Object.assign({}, state.cur_overview_indicators, res);
        state.cur_overview_indicators = merged_indicators
      })
      break
    case 'st_patterns':
      data = await getSTPatterns(...args)
      res = data
      store.$patch((state) => {
        state.cur_st_patterns = res
      })
      break
    case 'event_series':
      data = await getEventSeries(...args)
      res = data
      store.$patch((state) => {
        state.cur_event_series = res
      })
      break
    case 'st_phase_events':
      data = await getSTPhaseEvents(...args)
      res = data
      store.$patch((state) => {
        state.st_phase_events = res
        state.cur_filtered_phases = res.phases_list
        // state.cur_filtered_events = res.events_clean
        state.cur_filtered_phases_indices = state.cur_filtered_phases.map((item,index) => index)
        // state.cur_filtered_events = res.events_outliers
        // state.cur_filtered_events = res.events_list
        // console.log(state.cur_filtered_events.length);
        // state.cur_filtered_events = state.cur_filtered_phases.reduce((accu, obj) => accu.concat(obj.evolution_events), [])
      })
      break
    case 'phases_indicators':
      data = await getPhasesIndicators(...args)
      res = data
      store.$patch((state) => {
        state.error_indicators = res
        // state.events_indicators = res.events_indicators
        for (let key in res.phases_indicators) {
          let tmp_space_mae_range = [0, 0]
          for (let i = 0; i < res.phases_indicators[key].length; ++i) {
            let space_mae = res.phases_indicators[key][i].space_abs_residual
            let space_mae_max = d3.max(space_mae)
            if (space_mae_max > tmp_space_mae_range[1]) {
              tmp_space_mae_range[1] = space_mae_max
            }
          }
          for (let i = 0; i < res.phases_indicators[key].length; ++i) {
            res.phases_indicators[key][i]['global_space_mae_range'] = tmp_space_mae_range
          }
        }
        state.phases_indicators = res.phases_indicators
      })
      break
    case 'event_subsets':
      data = await getEventSubsets(...args)
      res = data
      store.$patch((state) => {
        // state.event_subsets = res
        state.event_attr_objs = res
      })
      break
    case 'phase_ins_subsets':
      data = await getPhaseInsSubsets(...args)
      res = data
      store.$patch((state) => {
        state.phase_clean_res_abs_mean = res.clean_residual_abs_mean
        let tmp_range_infor = {}
        for (const attr of state.cur_st_attrs) {
          tmp_range_infor[attr] = res.range_infor[attr]
          if (attr == "target_val") tmp_range_infor[attr].simple_str = 'V'
          if (attr == "temporal_state_vals") tmp_range_infor[attr].simple_str = 'T'
          if (attr == "space_comp_state_vals") tmp_range_infor[attr].simple_str = 'SC'
          if (attr == "space_diff_state_vals") tmp_range_infor[attr].simple_str = 'SD'
        }
        state.cur_range_infor = tmp_range_infor
        state.meta_attr_objs = res.meta_attr_objs
        // console.log(state.cur_range_infor);
        state.phase_ins_subsets = res.phase_ins_subsets
        // state.phase_subsets_proj = res.subsets_proj
        // state.phase_subsets_links = res.subset_links
      })
      break
    case 'phase_details':
      data = await getPhaseDetails(...args)
      res = data
      store.$patch((state) => {
        state.sel_phase_details = res
      })
      break
    case 'subset_details':
      data = await getSubsetDetails(...args)
      res = data
      store.$patch((state) => {
        state.sel_subset_details = res
      })
      break
    case 'err_distribution':
      data = await getErrDistribution(...args)
      res = data
      store.$patch((state) => {
        state.cur_err_dis = res
      })
      break
    case 'multi_step_err_infor':
      data = await getMultiStepErrInfor(...args)
      res = data
      store.$patch((state) => {
        state.multi_step_err_infor = res
      })
      break
    case 'phase_data':
      data = await getPhaseData(...args)
      res = data
      store.$patch((state) => {
        state.cur_phase_data = res
      })
      break
    case 'subsets':
      data = await getSubsets(...args)
      res = data
      store.$patch((state) => {
        state.cur_range_infor = res.range_infor
        state.cur_subsets = res.subsets_list
        for (let i = 0; i < state.cur_subsets.length; ++i) {
          state.cur_subsets[i].range_val = {}
          for (let j = 0; j < state.cur_subsets[i].subset_attrs.length; ++j) {
            let cur_attr_str_split = state.cur_subsets[i].subset_attrs[j].split('-')
            let cur_attr_type = cur_attr_str_split[0]
            let cur_attr_id = parseInt(cur_attr_str_split[1])
            if (cur_attr_type != 'scope')
            state.cur_subsets[i].range_val[cur_attr_type] = state.cur_range_infor[cur_attr_type].preorder_tree[cur_attr_id]
            else {
              let scope_range = [cur_attr_id * state.cur_sel_scope_th+1, (cur_attr_id+1) * state.cur_sel_scope_th]
              state.cur_subsets[i].range_val[cur_attr_type] = scope_range
            }
          }
        }
      })
      break
    case 'ranges':
      data = await getRanges(...args)
      res = data
      store.$patch((state) => {
        state.cur_ranges = res
      })
      break
    case 'subset_data_ids':
      data = await getSubsetDataIds(...args)
      res = data
      store.$patch((state) => {
        state.cur_subset_data_ids = res
      })
      break
    case 'attr_distributions':
      data = await getAttrDistributions(...args)
      res = data
      store.$patch((state) => {
        state.attrs_hists = res
      })
      break
    case 'instance_details_subset':
      data = await getInstanceDetail_subset(...args)
      res = data
      store.$patch((state) => {
        state.cur_instance_details = res
        state.cur_sel_stamp_objs = res.timestamp_objs
      })
      break
    case 'instance_seqs':
      data = await getInstanceSeqs(...args)
      res = data
      store.$patch((state) => {
        state.cur_instance_seqs = res
      })
      break
    case 'loc_features':
      data = await getLocFeatures(...args)
      res = data
      store.$patch((state) => {
        let show_features = ["PM2.5", "PM10", "SO2", "NO2", "CO", "O3", "U", "V", "TEMP", "RH", "PSFC"]
        let reorderedObject = {};
        show_features.forEach(function(key) {
            if (res.hasOwnProperty(key)) {
                reorderedObject[key] = res[key];
            }
        });
        state.cur_loc_features = reorderedObject
      })
      break
      
    default:
      break
  }
  
  return 0
}