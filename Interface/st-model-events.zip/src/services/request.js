import { axiosGet, axiosPost } from '@/libs/http'

const ip_address = "http://192.168.1.2:1024"
const trajectory_process_ip = "http://192.168.1.2:1036"

function getExistedTaskDataModel() {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/task_data_model_infor`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getPointLocs() {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/point_locs`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getCurDataInfor(task, data_name) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/cur_data_infor/${task}/${data_name}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getInputOutputData(task, data_name) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/input_output_data/${data_name}/${input_step}/${output_step}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}


function getModelParameters(data_name, model_names, focus_th, bin_edges) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/model_parameters/${data_name}/${model_names}/${focus_th}/${bin_edges}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getModelInfor(data_name, model_name, failure_rules, scope_seg_th) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/model_infor/${data_name}/${model_name}/${failure_rules}/${scope_seg_th}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getPhaseData(phase_id) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/phase_data/${phase_id}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时没用到
function getOverviewIndicators(task, data_name, sel_time, failure_rules, scope_seg_th, required_indicators) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/overview_indicators/${task}/${data_name}/${sel_time}/${failure_rules}/${scope_seg_th}/${required_indicators}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时没用到
function getEventSeries(data_name, model_name, failure_rules, scope_seg_th) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/event_series/${data_name}/${model_name}/${failure_rules}/${scope_seg_th}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getSTPhaseEvents(data_name, focus_th, min_length, bin_list, event_params) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/st_phase_events/${data_name}/${focus_th}/${min_length}/${bin_list}/${event_params}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getPhasesIndicators(data_name, model_names, bin_edges, event_params, focused_scope) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/phases_indicators/${data_name}/${model_names}/${bin_edges}/${event_params}/${focused_scope}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getEventSubsets(model_names, model_name, fore_step, range_mode, params) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/event_subsets/${model_names}/${model_name}/${fore_step}/${range_mode}/${params}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getPhaseInsSubsets(data_name, model_names, model_name, phase_id, attrs, fore_step, range_mode, range_params, subset_params, organize_params, val_bins, focused_scope) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/phase_ins_subsets/${data_name}/${model_names}/${model_name}/${phase_id}/${attrs}/${fore_step}/${range_mode}/${range_params}/${subset_params}/${organize_params}/${val_bins}/${focused_scope}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getPhaseDetails(model_name, phase_id, bin_edges, focused_val, focused_scope) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/phase_details/${model_name}/${phase_id}/${bin_edges}/${focused_val}/${focused_scope}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getSubsetDetails(subset_id, x_axis, y_axis, x_bin_edges, y_bin_edges) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/subset_details/${subset_id}/${x_axis}/${y_axis}/${x_bin_edges}/${y_bin_edges}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getDataItems(dr_method) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/data_items/${dr_method}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function saveErrorConfig(cur_task, config_name, config_description, failure_rules, scope_seg_th) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/save_error_config/${cur_task}/${config_name}/${config_description}/${failure_rules}/${scope_seg_th}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getTrajectories(loc_ids, sel_locs, date, data_name, ensemble_flag, horizontal_offset) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/get_trajectories/${loc_ids}/${sel_locs}/${date}/${data_name}/${ensemble_flag}/${horizontal_offset}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getGridBorders(loc_ids) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/grid_borders/${loc_ids}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getSTPatterns(data_name, corr_th) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/st_patterns/${data_name}/${corr_th}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getRanges(data_name, model_name, sup_th, div_th, scope_size, metric) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/ranges/${data_name}/${model_name}/${sup_th}/${div_th}/${scope_size}/${metric}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getErrDistribution(data_name, model_name, step_len, sup_th) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/err_distribution/${data_name}/${model_name}/${step_len}/${sup_th}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getMultiStepErrInfor(data_name, model_names, step_len) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/multi_step_err_infor/${data_name}/${model_names}/${step_len}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getSubsets(data_name, model_name, scope_size, attrs, analysis_type, range_params, subset_params, organize_params, focus_err_range, val_bins) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/subsets/${data_name}/${model_name}/${scope_size}/${attrs}/${analysis_type}/${range_params}/${subset_params}/${organize_params}/${focus_err_range}/${val_bins}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getSubsetDataIds(subset_id) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/subset_data_ids/${subset_id}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getAttrDistributions(data_name, attrs_bins) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/attr_distributions/${data_name}/${attrs_bins}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

// 暂时用不到
function getInstanceDetail_subset(data_name, model_name, subset_id, x_condition, y_condition, loc_id) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/instance_details_subset/${data_name}/${model_name}/${subset_id}/${x_condition}/${y_condition}/${loc_id}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getInstanceSeqs(model_names, stamp_id, loc_id, focused_scope) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/instance_seqs/${model_names}/${stamp_id}/${loc_id}/${focused_scope}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getLocFeatures(loc_id, stamp_id) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/loc_features/${loc_id}/${stamp_id}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

function getNewTest(a, b) {
  return new Promise((resolve, reject) => {
    axiosGet({
      url: `${ip_address}/new_test/${a}/${b}`,
      success (data) {
        resolve(data)
      },
      error (err) {
        reject(err)
      }
    })
  })
}

export {
  getExistedTaskDataModel,
  getPointLocs,
  getCurDataInfor,
  getInputOutputData,
  getModelInfor,
  getEventSeries,
  getSTPhaseEvents,
  getPhasesIndicators,
  getPhaseDetails,
  getSubsetDetails,
  getDataItems,
  saveErrorConfig,
  getOverviewIndicators,
  getTrajectories,
  getGridBorders,
  getSTPatterns,
  getModelParameters,
  getErrDistribution,
  getMultiStepErrInfor,
  getSubsets,
  getRanges,
  getSubsetDataIds,
  getAttrDistributions,
  getInstanceDetail_subset,
  getInstanceSeqs,
  getLocFeatures,
  getPhaseData,
  getEventSubsets,
  getPhaseInsSubsets,
  getNewTest
}