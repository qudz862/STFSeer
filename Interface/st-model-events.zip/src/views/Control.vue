<template>
  <ControlPanel />
</template>

<script setup>
import ControlPanel from "@/components/ControlPanel/index.vue";
</script>

<style>

</style>
