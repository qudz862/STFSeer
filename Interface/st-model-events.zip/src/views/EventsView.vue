<template>
    <EventsView />
</template>

<script setup>
import EventsView from "@/components/EventsView/index.vue";
</script>

<style>

</style>
  