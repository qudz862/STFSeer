<template>
    <ExplorationView />
</template>

<script setup>
import ExplorationView from "@/components/ExplorationView/index.vue";
</script>

<style>

</style>
  