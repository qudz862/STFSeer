<template>
    <ExtremesPanel />
</template>

<script setup>
import ExtremesPanel from "@/components/ExtremesPanel/index.vue";
</script>

<style>

</style>
  