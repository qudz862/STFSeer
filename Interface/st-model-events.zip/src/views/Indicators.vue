<template>
  <IndicatorsView />
</template>

<script setup>
import IndicatorsView from "@/components/IndicatorsView/index.vue";
</script>

<style>

</style>
