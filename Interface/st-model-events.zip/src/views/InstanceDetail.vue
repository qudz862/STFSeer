<template>
    <InstanceDetailView />
  </template>
  
  <script setup>
  import InstanceDetailView from "@/components/InstanceDetailView/index.vue";
  </script>
  
  <style>
  
  </style>
  