<template>
  <InstancesView />
</template>

<script setup>
import InstancesView from "@/components/InstancesView/index.vue";
</script>

<style>

</style>
