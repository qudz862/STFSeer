<script setup>
import Control from "./Control.vue"
import Overview from "./Overview.vue"
import Models from "./Models.vue"
import Instances from "./Instances.vue"
import Indicators from "./Indicators.vue"
import Subsets from "./Subsets.vue"
import TemporalPhases from "./TemporalPhases.vue"
import STAttrs from './STAttrs.vue'
import STContext from './STContext.vue'
import Exploration from "./Exploration.vue"
import SubsetsOverview from "./SubsetsOverview.vue"
import ExtremesPanel from './Extremes.vue'
import InstanceDetail from './InstanceDetail.vue'
import EventsView from './EventsView.vue'
import NewTest from './NewTest.vue';

document.addEventListener('contextmenu', function(e){
	e.preventDefault();
})
</script>

<template>
  <div>
    <NewTest />
  </div>
  <div class="global-container">
    <Control />
    <div>
      <!-- <ExtremesPanel /> -->
      <!-- <SubsetsOverview />  -->
      <TemporalPhases />
      <div class="local-container">
        <Exploration />
        <div>
          <!-- <STAttrs /> -->
          <!-- <EventsView /> -->
          <!-- <Subsets /> -->
        </div>
      </div>
      <!-- <STContext /> -->
      <!-- <Overview /> -->
      <!-- <Indicators /> -->
      <!-- <Models /> -->
      <!-- <Instances /> -->
    </div>
    <!-- <div>
      
      <STPattern />
    </div> -->
    <InstanceDetail />
  </div>
</template>


<style>
.global-container {
  display: flex;
}

.local-container {
  display: flex;
}
</style>
