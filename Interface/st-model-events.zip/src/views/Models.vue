<template>
  <ModelsView />
</template>

<script setup>
import ModelsView from "@/components/ModelsView/index.vue";
</script>

<style>

</style>
