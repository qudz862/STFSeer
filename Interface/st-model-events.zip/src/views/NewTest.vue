<template>
  <NewTestView />
</template>

<script setup>
import NewTestView from "@/components/NewTestView/index.vue";
</script>

<style>

</style>
