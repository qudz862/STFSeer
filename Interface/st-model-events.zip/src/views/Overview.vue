<template>
    <OverviewModule />
</template>

<script setup>
import OverviewModule from "@/components/OverviewModule/index.vue";
</script>

<style>

</style>
  