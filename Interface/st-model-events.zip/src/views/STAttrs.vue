<template>
    <STAttrsView />
</template>

<script setup>
import STAttrsView from "@/components/STAttrsView/index.vue";
</script>

<style>

</style>
  