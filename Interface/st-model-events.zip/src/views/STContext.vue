<template>
    <STContextView />
</template>

<script setup>
import STContextView from "@/components/STContextView/index.vue";
</script>

<style>

</style>
