<template>
    <STPatternView />
</template>

<script setup>
import STPatternView from "@/components/STPatternView/index.vue";
</script>

<style>

</style>
