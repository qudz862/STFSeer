<template>
    <SubsetList />
</template>

<script setup>
import SubsetList from "@/components/SubsetList/index.vue";
</script>

<style>

</style>
  