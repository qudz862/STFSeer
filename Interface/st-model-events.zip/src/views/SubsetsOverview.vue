<template>
    <SubsetsRadViz />
</template>

<script setup>
import SubsetsRadViz from "@/components/SubsetsRadViz/index.vue";
</script>

<style>

</style>
  