<template>
  <TemporalPhaseView />
</template>

<script setup>
import TemporalPhaseView from "@/components/TemporalPhaseView/index.vue";
</script>

<style>

</style>
